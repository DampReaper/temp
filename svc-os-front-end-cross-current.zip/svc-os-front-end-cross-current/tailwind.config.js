module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}", "./public/index.html"],
  theme: {
    extend: {
      colors: {
        "ctz-teal": "hsl(180, 100%, 30%)",
        "ctz-green": {
          40: "#f5faf8",
          50: "#49B649",
          100: "#008555",
          300: "#03774d",
        },
        "ctz-red": {
          100: "#ef4444",
        },
        "ctz-orange": "#d93d00",
        "ctz-gold": "#dac500",
        "ctz-blue": "#044da2",
        "ctz-grey": "#353e51",
        "ctz-white": "#F3F3F3",
      },
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
};
