import { BrowserRouter, Route, Routes } from "react-router-dom";

import AddApplication from "pages/AddApplication";
import DashBoard from "pages/DashBoard";
import { Provider } from "react-redux";
import React from "react";
import SearchApplication from "pages/SearchApplication";
import { createRoot } from "react-dom/client";
import registerFontAwesomeIcons from "./utils/fontAwesomeHelper";
import { storeInstance } from "reduxStore/store";

// import DashBoard from 'pages/DashBoard';
//import Search from "./pages/Search";
//import ViewContactTicket from "./pages/ViewContactTicket";

// import "styles/tailwind.scss";
// import "./styles/global.scss";
// import 'bootstrap/dist/css/bootstrap.min.css'






registerFontAwesomeIcons();

function App() {
  console.debug("App-TrackIt");
  return (
    <BrowserRouter basename="/trackit">
      <Routes>
          <Route path='/' element={<DashBoard />} />
          <Route path='/DashBoard' element={<DashBoard />} />
          <Route path='/AddApplication' element={<AddApplication />} />
          <Route path='/SearchApplication' element={<SearchApplication />} />
      </Routes>
    </BrowserRouter>
  );
}

createRoot(document.getElementById("root") as HTMLElement).render(
  <React.StrictMode>
      <Provider store={storeInstance}>
    <App />
    </Provider>
  </React.StrictMode>
);

export default App;
