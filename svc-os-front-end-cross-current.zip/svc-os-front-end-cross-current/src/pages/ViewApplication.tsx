import React, { useEffect, useState } from 'react';

import { LOG_STYLE } from 'utils';

/**
 * Renders a 'ViewApplication' Component.
 */
export default function ViewApplication() {
  console.debug(...LOG_STYLE.RENDER1, 'ViewApplication');

 

  useEffect(() => {
    console.debug(...LOG_STYLE.EFFECT1, 'ViewApplication');
  }, []);

  return (
    <>
 
    </>
  );
}
