import React, { useEffect, useState } from 'react';

import ApplicationInformation from 'components/AddApplication/ApplicationInformation';
import BankInformation from 'components/AddApplication/BankInformation';
import { LOG_STYLE } from 'utils';
import LoanInformation from 'components/AddApplication/LoanInformation';
import OtherInformation from 'components/AddApplication/OtherInformation';
import ResidenceInformation from 'components/AddApplication/ResidenceInformation';
import ReviewInformation from 'components/AddApplication/ReviewInformation';
import SubmissionStatus from 'components/AddApplication/SubmissionStatus';

/**
 * Renders a 'AddApplication' Component.
 */
export default function AddApplication() {
  console.debug(...LOG_STYLE.RENDER1, 'AddApplication');

  const [step, setStep] = useState(1);

  const nextStep = () => {
    setStep(step + 1);
  };

  const prevStep = () => {
    setStep(step - 1);
  };

  useEffect(() => {
    console.debug(...LOG_STYLE.EFFECT1, 'AddApplication');
  }, []);

  switch (step) {
    case 1:
      return <BankInformation nextStep={nextStep} prevStep={prevStep} />;
    case 2:
      return <LoanInformation nextStep={nextStep} prevStep={prevStep} />;
    case 3:
      return <ApplicationInformation nextStep={nextStep} prevStep={prevStep} />;
    case 4:
      return <ResidenceInformation nextStep={nextStep} prevStep={prevStep} />;
    case 5:
      return <OtherInformation nextStep={nextStep} prevStep={prevStep} />;
    case 6:
      return <ReviewInformation nextStep={nextStep} prevStep={prevStep} />;
    case 6:
      return <SubmissionStatus nextStep={nextStep} />;
    default:
      return null;
  }
}
