import React, { useEffect, useState } from 'react';

import { LOG_STYLE } from 'utils';

/**
 * Renders a 'SearchApplication' Component.
 */
export default function SearchApplication() {
  console.debug(...LOG_STYLE.RENDER1, 'SearchApplication');

 

  useEffect(() => {
    console.debug(...LOG_STYLE.EFFECT1, 'SearchApplication');
  }, []);

  return (
    <>
 <div>Search</div>
    </>
  );
}
