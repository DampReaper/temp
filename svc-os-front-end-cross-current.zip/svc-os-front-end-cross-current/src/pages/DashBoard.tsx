import 'styles/tailwind.scss';
import 'styles/global.scss';

import React, { useEffect, useState } from 'react';

import { LOG_STYLE } from 'utils';
import Menu from 'components/Menu/Menu';
import { Provider } from 'react-redux';
import { storeInstance } from 'reduxStore/store';

// import 'bootstrap/dist/css/bootstrap.min.css';







/**
 * Renders a 'DashBoard' Component.
 */
export default function DashBoard() {
  console.debug(...LOG_STYLE.RENDER1, 'DashBoard');

  useEffect(() => {
    console.debug(...LOG_STYLE.EFFECT1, 'DashBoard');
  }, []);

  return (
    <>
      <Provider store={storeInstance} >
        <Menu />
      </Provider>
    </>
  );
}
