import { Agent, Branch } from "services";

export interface EmployeeSearchResult {
    options: EmployeeSearchResultItem[];
    totalCount: number;
  }
 
  export interface EmployeeSearchResultItem {
    id: number;
    name: string;
  }

  export interface AgentSearchResult {
    options:Agent[];
    totalCount: number;
  }


  export interface BranchSearchResult {
    options:Branch[];
    totalCount: number;
  }


 

 
  