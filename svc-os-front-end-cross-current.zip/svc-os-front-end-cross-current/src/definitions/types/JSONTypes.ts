export type JSONPrimitive = string | number | boolean | JSONObject | null | undefined;
export type JSONObject = { [key: string]: JSONPrimitive } | JSONObject[];
export type JSONArray = JSONObject[];

export type DropDownOption = { value: string| any, label: string }

export type KeyValuePair = { value: string| any, key: string }