import { columnProps, dateFormatter } from "definitions";

import { ColumnDescription } from "react-bootstrap-table-next";

export const ticketSearchColumns: ColumnDescription[] = [
  {
    dataField: 'ticketId',
    text: 'Ticket',
    sort: true,
    ...columnProps
  },
  {
    dataField: 'ticketType.description',
    text: 'Type',
    sort: true,
    ...columnProps
  },
  {
    dataField: 'ownerAgent.employeeNum',
    text: 'Agent',
    sort: true,
    ...columnProps
  },
  {
    dataField: 'status',
    text: 'Status',
    sort: true,
    ...columnProps
  },
  {
    dataField: 'closedDate',
    text: 'ClosedDt',
    formatter: dateFormatter,
    sort: true,
    ...columnProps
  },
  {
    dataField: 'workflowStatus',
    text: 'Wf Status',
    sort: true,
    ...columnProps
  },
  {
    dataField: 'workflowExternalId',
    text: 'Wf Case#',
    sort: true,
    ...columnProps
  }
];
