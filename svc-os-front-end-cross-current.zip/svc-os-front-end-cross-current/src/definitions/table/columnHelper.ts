import { pageButtonRenderer, sizePerPageRenderer } from 'utils/TablePageRender';

 //import { DateTime } from 'luxon';

const formatAddress = (cell: any) => {
  return (
    cell.addr1 +
    ', ' +
    // cell.addr2 +
    // ", " +
    // cell.addr3 +
    // " " +
    cell.city +
    ', ' +
    cell.state +
    ', ' +
    cell.zip +
    ' ' +
    cell.country
  );
};

export const dateFormatter = (cell: any) => {
  console.log('dateFormatter')
  if (!cell) {
    return '';
  }
  return  cell;// `${DateTime.fromISO(cell).toFormat('MM-dd-yy h:mm a')}`;
  // `${DateTime.fromFormat(cell, 'MM-dd-yyyy')}`;
};





export const columnProps = {
  align: 'left',
  headerAlign: 'left'
};

export const sizePerPageList = [
  {
    text: '10',
    value: 10
  },
  {
    text: '25',
    value: 25
  },
  {
    text: '50',
    value: 50
  },
  {
    text: '100',
    value: 100
  }
];

export const defaultPaginationOptions = {
  pageStartIndex: 1,
  disablePageTitle: true,
  paginationSize: 3,
  sizePerPageList: sizePerPageList,
  showTotal: true,
  pageButtonRenderer: pageButtonRenderer,
  sizePerPageRenderer: sizePerPageRenderer
};
