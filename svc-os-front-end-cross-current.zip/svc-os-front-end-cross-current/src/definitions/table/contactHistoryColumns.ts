import { columnProps, dateFormatter } from "definitions";

import { ColumnDescription } from "react-bootstrap-table-next";
import { ownerAgentFormatter } from "utils/TablePageRender";

export const contactHistoryColumns: ColumnDescription[] = [
   {
      dataField: 'ticketId',
      text: 'Ticket',
      sort: true,
      ...columnProps,
      hidden: true
    },
    {
      dataField: 'createdDate',
      text: 'Created On',
      formatter: dateFormatter,
      headerStyle: { width: '125px', textAlign: 'left' },
      sort: true,
      ...columnProps
    },
    {
      dataField: 'ownerAgent.lastName',
      formatter: ownerAgentFormatter,
      text: 'Agent',
      sort: true,
      ...columnProps
    },
    {
      dataField: 'ticketType.description',
      text: 'Type',
      sort: true,
      headerStyle: { width: '400px', textAlign: 'left' },
      ...columnProps,
   
    },
    {
      dataField: 'status',
      text: 'Status',
      sort: true,
      headerStyle: { width: '60px', textAlign: 'left' },
      ...columnProps
    },
    {
      dataField: 'closedDate',
      text: 'ClosedDt',
      formatter: dateFormatter,
      sort: true,
      ...columnProps
    },
    {
      dataField: 'workflowStatus',
      text: 'Comments',
      headerStyle: { width: '400px', textAlign: 'left' },
      sort: true,
      ...columnProps
    }
  
    // {
    //   dataField: 'workflowStatus',
    //   text: 'Wf Status',
    //   sort: true,
    //   ...columnProps
    // },
    // {
    //   dataField: 'workflowExternalId',
    //   text: 'Wf Case#',
    //   sort: true,
    //   ...columnProps
    // }
  ];
  