import { columnProps, dateFormatter } from 'definitions';

import { ColumnDescription } from 'react-bootstrap-table-next';

export const customerSearchColumns: ColumnDescription[] = [
  {
    dataField: 'fullName',
    text: 'fullName',
    sort: true,
    ...columnProps
  },
  {
    dataField: 'taxId',
    text: 'taxId',
    sort: true,
    ...columnProps
  },
  {
    dataField: 'birthDate',
    text: 'birthDate',
    sort: true,
    ...columnProps
  }
];
