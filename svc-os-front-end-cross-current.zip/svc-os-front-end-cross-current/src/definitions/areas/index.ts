export const areas = {
    searchCustomer: "searchCustomer"
  };
  