export const SHOW_TICKET = {
  HISTORY: 'HISTORY',
  DETAIL: 'DETAIL'
};
export declare type SHOW_TICKET = typeof SHOW_TICKET.HISTORY | typeof SHOW_TICKET.DETAIL;

export const CONTACT_TYPE = {
  EMPLOYEE: 'Employee',
  CUSTOMER: 'Customer',
  COMPANY: 'Company'
};

export declare type CONTACT_TYPE = typeof CONTACT_TYPE.EMPLOYEE | typeof CONTACT_TYPE.CUSTOMER | typeof CONTACT_TYPE.COMPANY;

export const TICKET_STATUS_TYPE = {
  OPEN: 'Open',
  CLOSED: 'Closed'
};

export const AUTHENTICATION_METHOD = {
  UNKNOWN: 'Unknown',
  IVR: 'IVR',
  AGENT: 'Agent'
};
export declare type AUTHENTICATION_METHOD = typeof AUTHENTICATION_METHOD.UNKNOWN | typeof AUTHENTICATION_METHOD.IVR | typeof AUTHENTICATION_METHOD.AGENT;

export const STATUS = {
  OPEN: 'Open',
  CLOSED: 'Closed'
};

export const WORKFLOW_STATUS = {
  OPEN: 'Open',
  CLOSED: 'Closed'
};

export const SEARCH_TYPE = {
  EMPLOYEE: 'Employee',
  CUSTOMER: 'Customer',
  COMPANY: 'Company',
  BY_TICKET_ID: 'By Ticket Id',
  BY_WORKFLOW_CASE: 'By Workflow Case#',
  BY_TICKET_EMPLOYEE: 'Ticket By Employee',
  BY_TICKET_BRANCH: 'Ticket By Branch',
  BY_TICKET_AGENT: 'Ticket By Agent',

  BY_TICKET_CUSTOMER: 'Ticket By Customer',
  BY_TICKET_COMPANY: 'Ticket By Company',
  MY_OPEN_ISSUES: 'My Open Issues',
  MY_TICKETS: 'My Tickets'
};

export const errors = {
  SUCCESS: 200,
  NOT_FOUND: 404,
  SERVER_ERROR: 500
};


export const DASHBOARD_TABS = {
  SEARCH_EXISTING: 'Search Existing Ticket',
  CREATE_NEW: 'Create New Ticket'
};
