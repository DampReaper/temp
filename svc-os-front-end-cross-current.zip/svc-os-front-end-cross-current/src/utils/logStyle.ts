export const LOG_STYLE =  {
  REDIRECT: ';background: rgb(241, 131, 157)',
  ERROR1: ['%c:%s:%o', ';background: red; border: 1px solid yellow ;font-style: bold; color: #444; padding: 3px; border-radius: 5px;'],
  SAGA: ';background: rgb(211, 148, 200);; border: 1px solid black ;font-style: bold; color: #444; padding: 3px; border-radius: 5px;',
  SAGA_STEP: ';background: rgb(230, 177, 221); border: 1px solid dashed ;font-style: bold; color: #444; padding: 3px; border-radius: 5px;',
  SAVE: ';background:rgb(178, 230, 214); border: 1px solid dashed ;font-style: bold; color: #444; padding: 3px; border-radius: 5px;',
  DEBUG1: ['%c:%s:%o', ';background: lightYellow; border: 1px solid black ;font-style: italic; color: #444; padding: 3px; border-radius: 5px;'],
  RENDER1: ['%cRender:%s', ';background: lightBlue'],
  EFFECT1: ['%cUseEffect:%s %o', ';background: aquamarine'],
  ACTION1: ['%cAction:%s  %o', ';background: rgb(241, 131, 57); border: 1px solid black;color: #444; padding: 3px; border-radius: 5px;'],
  SERVICE: ['%cRender:%s', ';background: lightGreen'],
  REDUX: ['%cRender:%s', ';background: lightgrey']
} ;// as const;


export const SHOW_TICKET = {
  HISTORY: 'HISTORY',
  DETAIL: 'DETAIL'
}
/**
 * Sample
 
import { LOG_STYLE } from 'utils';
console.debug(...LOG_STYLE.RENDER1 ,'XXXX');
console.debug(...LOG_STYLE.EFFECT1 ,'EmployeeHistory');
console.debug(...LOG_STYLE.DEBUG1 ,'XXXX',{name:"sss"});


*/

export const ticketTypeData = [
  {
    ticketTypeId: '1',
    ticketTypeNm: 'A1',
    organization: 'C2C',
    sortOrderNum: 1,
    children: [
      {
        ticketTypeNm: 'A1:B1',
        organization: 'C2C',
        sortOrderNum: 1,
        children: [
          {
            ticketTypeNm: 'A1:B1:C1',
            dynamicQuestionId: 'Question1',
            organization: 'C2C',
            emailId: 0,
            workflow: 'SOME VALUE',
            commentRequired: true,
            sortOrderNum: 1
          },
          {
            ticketTypeNm: 'A1:B1:C2',
            dynamicQuestionId: 'Question2',
            organization: 'C2C',
            emailId: 'XYZ',
            workflow: 'SOME VALUE2',
            commentRequired: true,
            sortOrderNum: 1
          }
        ]
      },
      {
        ticketTypeNm: 'A1:B2',
        organization: 'C2C',
        sortOrderNum: 2,
        children: []
      }
    ]
  },
  {
    ticketTypeNm: 'A2',
    organization: 'C2C',
    sortOrderNum: 1,
    children: [
      {
        ticketTypeNm: 'A2:B3',
        organization: 'C2C',
        sortOrderNum: 1,
        children: []
      },
      {
        ticketTypeNm: 'A2:B4',
        organization: 'C2C',
        sortOrderNum: 2,
        children: []
      }
    ]
  }
];


