/**
 *
 * @returns a unique id to pass with each api call
 */
// export const generateUUID = () => {
//   return uuid();
// };

import { TicketTypeDto } from 'services';

/**
 *
 * @param field Field to do the validations for
 * @param value Current value of the field to be validated
 * @returns Error message if the field is invalid
 */
export const validateInputs = (field: string, value: string) => {
  switch (field) {
    case 'firstName':
    case 'lastName':
    case 'userId':
    case 'branchNumber':
      return value.length > 20 ? 'Should be less than 20 characters' : '';

    case 'taxId':
      const taxIdRegex = /^[0-9]{0,9}$/;

      return value.length > 9 ? 'Should only contain 9 digits' : taxIdRegex.test(value) ? '' : 'Can only contain digits between 0-9';

    case 'occupation':
    case 'city':
    case 'desc':
      const occRegex = /^[a-zA-Z\s]{0,35}$/;
      return value.length > 35 ? 'Should be less than 35 characters' : occRegex.test(value) ? '' : 'Can only contain characters like a-z, A-Z';

    case 'addr1':
    case 'addr2':
    case 'addr3':
      return value.length > 40 ? 'Should be less than 40 characters' : '';

    case 'zip':
      const zipRegex = /^[0-9]{0,5}$/;
      return value.length > 5 ? 'Maximum limit 5 digits' : zipRegex.test(value) ? '' : 'Can only contain digits between 0-9';

    case 'extendedZipCode':
      const zipExtRegex = /^[0-9]{0,4}$/;
      return value.length > 4 ? 'Maximum limit 4 digits' : zipExtRegex.test(value) ? '' : 'Can only contain digits between 0-9';

    case 'idNum':
      const idRegex = /^[0-9]{0,15}$/;
      return value.length > 15 ? 'Maximum limit 15 digits' : idRegex.test(value) ? '' : 'Can only contain digits between 0-9';

    default:
      return '';
  }
};

export const validateDate = (date: any) => {
  const dateRegex = /^\d{2}\/\d{2}\/\d{4}$/;

  if (date) {
    if (!dateRegex.test(date)) {
      return 'Date should be in mm/dd/yyyy format';
    }
  }
  return '';
};

/**
 *
 * @param field Field to be mapped to null if empty or undefined
 * @returns null if field is empty
 */
export const mapToNullIfEmpty = (field: string | undefined) => {
  return field ? field : null;
};

/**
 *
 * @param taxId taxId to be formatted
 * @returns Formatted taxId as xxx-xx-xxxx
 */
export const formatTaxId = (taxId: string) => {
  return `${taxId.substring(0, 3)}-${taxId.substring(3, 5)}-${taxId.substring(5)}`;
};

export const formatDate = (date: string) => {
  return new Date(date + 'T00:00:00').toLocaleDateString();
};

export const createOption = (label: string | undefined) => {
  return { value: label || '', label: label || '' };
};

/**
 * Build an array of @param key from a ticket's selected ticketType node.
 *
 * @param data: TicketTypeDto. Ticket selection.
 * @param key: string. field to use to build array ex. ticketTypeId.
 * @returns array of @param key ex[1,3,6] or ['A1':'A1:B1','A1:B1:C1']
 */
export const getPathFromSelection = (data: TicketTypeDto, key: string) => {
  if (data === null || data === undefined) return [];
  let nextNode: TicketTypeDto = JSON.parse(JSON.stringify(data)) as TicketTypeDto;

  const root: any[] = [];
  root.push(nextNode[key]);

  while (nextNode.children && nextNode.children.length > 0) {
    nextNode = nextNode.children.pop() as TicketTypeDto;
    root.push(nextNode[key]);
  }
  return root;
};

/**
 * Build a TicketType Selection based off of a path.
 *
 * @param data: TicketTypeDto[].
 * @param key: string. field to use to build array ex. 'ticketTypeId'.
 * @param path:number[]|string[]: string. field to use to build array ex. ticketTypeId.
 * @returns Ticket selection. ex { ticketTypeId:1 name:A children:[{ticketTypeId:2 name:A:B children:[]}]}. or Null if path does not exist
 */
export const expandPathToSelection = (data: TicketTypeDto[], key: string, path: number | string) => {
  return expandPathToSelections(data, key, path).pop();
};

export const expandPathToSelections = (data: TicketTypeDto[], key: string, path: number | string) => {
  const result: TicketTypeDto[] = [];

  if (data) {
    data.forEach((o) => {
      let children: TicketTypeDto[] = [];
      if (path === (o[key] as never)) {
        result.push(o);
        return;
      }
      if (o.children) {
        children = expandPathToSelections(o.children, key, path);
        if (children.length && children.length > 0) {
          result.push(Object.assign({}, o, { children }));
        }
      }
    });
  }
  return result;
};

/**
 * Returns the last valid value for a key while walking down TicketTypeDto.
 *
 * @param selectedTicketTypeData: TicketTypeDto.
 * @param key: string. field to use to build array ex. 'ticketTypeId'.
 * @returns Last valid value. ex { ticketTypeId:1 name:A children:[{ticketTypeId:2 name:A:B children:[]}]}. or Null if path does not exist
 *           getLastKeyValue (selectedTicketTypeData,'Name')  => 'A:B'
 */
export const getLastKeyValue = (selectedTicketTypeData: TicketTypeDto, key: string) => {
  if (selectedTicketTypeData === null || selectedTicketTypeData === undefined) {
    return undefined;
  }
  let nextNode = JSON.parse(JSON.stringify(selectedTicketTypeData));
  let returnValue = nextNode[key];

  while (nextNode.children && nextNode.children.length > 0) {
    nextNode = nextNode.children.pop();
    if (nextNode[key] !== null && nextNode[key] !== undefined) {
      returnValue = nextNode[key];
    }
  }

  return returnValue;
};


export const concatName = (lastNm: string | undefined, firstNm: string | undefined): string => {
  if (lastNm) return lastNm + ', ' + firstNm;
  return '';
};
export const concatAgentName = (eNumber: string | undefined, lastNm: string | undefined, firstNm: string | undefined): string => {
  return eNumber +'-'+ concatName(lastNm ,firstNm);
};

export const isEmpty = (obj) => {
  return Object.keys(obj).length === 0 && obj.constructor === Object;
};



 