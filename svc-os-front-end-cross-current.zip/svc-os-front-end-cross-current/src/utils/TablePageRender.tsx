import React from 'react';

export const ownerAgentFormatter = (cell, row) => {
  console.log('nameFormatter');
  console.log(row);
  return (<div>{`${row.ownerAgent.firstName} ${row.ownerAgent.lastName}`}</div>);
}

export const pageButtonRenderer = ({ page, active, onPageChange }: any) => {
    const handleClick = (e: any) => {
      e.preventDefault();
      onPageChange(page);
    };
  
    return (
      <li
        key={page}
        onClick={handleClick}
        className={active ? "pageButtonActive" : ""}
      >
        {page}
      </li>
    );
  };
  
  // size-per-page component design and logic
  export const sizePerPageRenderer = ({
    options,
    currSizePerPage,
    onSizePerPageChange,
  }: any) => {
    return (
      <div className="size-per-page" role="group">
        {options.map((option: any) => (
          <button
            key={option.text}
            type="button"
            onClick={() => onSizePerPageChange(option.page)}
            className={
              currSizePerPage === option.text
                ? "size-per-page__button active"
                : "size-per-page__button"
            }
          >
            {option.text}
          </button>
        ))}
      </div>
    );
  };