import { library } from "@fortawesome/fontawesome-svg-core";
import { fas } from "@fortawesome/free-solid-svg-icons";
import { faFontAwesome } from "@fortawesome/free-solid-svg-icons";

export default function registerFontAwesomeIcons() {
  library.add(fas, faFontAwesome);
}
