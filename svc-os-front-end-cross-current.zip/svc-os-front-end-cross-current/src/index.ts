//@ts-ignore
import("./App");