import { fireEvent, render, screen } from "@testing-library/react";
import React from "react";
import Tooltip from ".";

const ButtonWithTooltip = ({
  position,
  width,
}: {
  position: string;
  width?: string;
}) => {
  return (
    <button
      id={"button"}
      aria-describedby="buttontooltip"
      className="relative flex items-center justify-center"
    >
      Hello World
      {width ? (
        <Tooltip id="button" position={position} width={width}>
          <p>Hello World Tooltip</p>
        </Tooltip>
      ) : (
        <Tooltip id="button" position={position}>
          <p>Hello World Tooltip</p>
        </Tooltip>
      )}
    </button>
  );
};

describe("Test the tooltip component", () => {
  test("should render the tooltip", () => {
    render(<ButtonWithTooltip position="top" />);
    const button = screen.getByText("Hello World");
    expect(button).toBeInTheDocument();

    const tooltip = screen.getByText("Hello World Tooltip");
    expect(tooltip).toBeInTheDocument();
  });

  test("should show/hide the tooltip on hover of parent", () => {
    render(<ButtonWithTooltip position="top" />);
    const button = screen.getByText("Hello World");
    const tooltip = screen.getByText("Hello World Tooltip");

    fireEvent.mouseEnter(button);
    expect(tooltip).toHaveStyle("visibility: visible");
    fireEvent.mouseLeave(button);
    expect(tooltip).toHaveStyle("visibility: hidden");
  });

  test("should hide the tooltip when esc key is pressed", () => {
    render(<ButtonWithTooltip position="top" />);
    const button = screen.getByText("Hello World");
    const tooltip = screen.getByText("Hello World Tooltip");

    fireEvent.mouseEnter(button);
    expect(tooltip).toHaveStyle("visibility: visible");

    fireEvent.keyDown(window, {
      key: "Enter",
      code: "Enter",
      keyCode: 13,
      charCode: 13,
    });
    expect(tooltip).toHaveStyle("visibility: visible");

    fireEvent.keyDown(window, {
      key: "Escape",
      code: "Escape",
      keyCode: 27,
      charCode: 27,
    });
    expect(tooltip).toHaveStyle("visibility: hidden");
  });

  test("should render tooltip in all 4 positions and apply width prop", () => {
    const { rerender } = render(<ButtonWithTooltip position="top" />);
    const tooltip = screen.getByText("Hello World Tooltip");

    expect(tooltip.parentElement).toHaveClass("tooltipTop");

    rerender(<ButtonWithTooltip position="right" />);
    expect(tooltip.parentElement).toHaveClass("tooltipRight");

    rerender(<ButtonWithTooltip position="bottom" />);
    expect(tooltip.parentElement).toHaveClass("tooltipBottom");

    rerender(<ButtonWithTooltip position="left" />);
    expect(tooltip.parentElement).toHaveClass("tooltipLeft");

    rerender(<ButtonWithTooltip position="wrong" />);
    expect(tooltip.parentElement).toHaveClass("tooltipRight");

    rerender(<ButtonWithTooltip position="top" width="100px" />);
    expect(tooltip.parentElement).toHaveClass("tooltipTop");
  });
});
