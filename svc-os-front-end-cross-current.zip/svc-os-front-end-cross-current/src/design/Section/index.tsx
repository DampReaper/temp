import React from "react";
import styles from "./section.module.scss";

type sectionType = "regular" | "borderedWithBg";

type SectionProps = {
  children: React.ReactNode;
  type?: sectionType;
  name: string;
};

/**
 *
 * @param children: react children to be rendered in the section
 * @param type: regular | borderedWithBg
 * @returns a wrapper component that wraps the children in a bordered box
 */
function Section({
  children,
  type = "regular",
  name,
}: SectionProps): JSX.Element {
  return (
    <div className={styles[type]} data-testid={`${name}-section`}>
      {children}
    </div>
  );
}

export default Section;
