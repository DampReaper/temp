import React from "react";
import { render, screen } from "@testing-library/react";
import ErrorMessage from ".";

describe("Test the ErrorMessage component", () => {
  test("should render an error message", () => {
    render(<ErrorMessage message="Error" />);

    const errorMessage = screen.getByText("Error");
    expect(errorMessage).toBeInTheDocument();
  });
});
