import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import styles from "./errormessage.module.scss";

type ErrorMessageProps = {
  message: string;
};

/**
 *
 * @returns A component with a failure message and an action button(only if type="add")
 */
function ErrorMessage({ message }: ErrorMessageProps): JSX.Element {
  return (
    <div className={styles.errorMessage}>
      <FontAwesomeIcon icon="exclamation-circle" />
      <h1>{message}</h1>
    </div>
  );
}

export default ErrorMessage;
