import React from "react";
import { render, screen } from "@testing-library/react";
import SuccessMessage from ".";

describe("Test the ErrorMessage component", () => {
  test("should render an error message", () => {
    render(<SuccessMessage message="Success" />);

    const successMessage = screen.getByText("Success");
    expect(successMessage).toBeInTheDocument();
  });
});
