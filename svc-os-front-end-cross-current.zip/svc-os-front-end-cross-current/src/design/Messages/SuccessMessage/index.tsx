import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import styles from "./successmessage.module.scss";

type SuccessMessageProps = {
  message: string;
};

/**
 *
 * @returns A component with a failure message and an action button(only if type="add")
 */
function SuccessMessage({ message }: SuccessMessageProps): JSX.Element {
  return (
    <div className={styles.successMessage}>
      <FontAwesomeIcon icon="check-circle" />
      <h1>{message}</h1>
    </div>
  );
}

export default SuccessMessage;
