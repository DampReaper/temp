import { IconProp } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { MouseEventHandler } from "react";
import Button from "../../FormElements/Button";
import styles from "./errormessagewithaction.module.scss";

type ErrorMessageWithActionProps = {
  message: string;
  buttonType: "primary" | "secondary";
  buttonId: string;
  buttonText: string;
  buttonIcon: IconProp;
  buttonClickHandler: MouseEventHandler<HTMLButtonElement>;
};

function ErrorMessageWithAction({
  message,
  buttonType,
  buttonId,
  buttonText,
  buttonIcon,
  buttonClickHandler,
}: ErrorMessageWithActionProps) {
  return (
    <div className={styles.errorMessage}>
      <div>
        <FontAwesomeIcon icon="exclamation-circle" />
        <h1>{message}</h1>
      </div>

      <Button
        id={buttonId}
        type={buttonType}
        handleClick={buttonClickHandler}
        text={buttonText}
        icon={buttonIcon}
      />
    </div>
  );
}

export default ErrorMessageWithAction;
