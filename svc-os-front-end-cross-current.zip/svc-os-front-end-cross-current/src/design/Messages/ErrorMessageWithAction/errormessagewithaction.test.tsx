import React from "react";
import { render, screen } from "@testing-library/react";
import ErrorMessageWithAction from ".";

describe("Test the ErrorMessageWithAction component", () => {
  test("should first", () => {
    render(
      <ErrorMessageWithAction
        message="Error"
        buttonType="primary"
        buttonText="Click"
        buttonClickHandler={() => {
          console.log("");
        }}
        buttonId="errorbutton"
        buttonIcon="search"
      />
    );

    const errorMessage = screen.getByText("Error");
    const errorButton = screen.getByText("Click");

    expect(errorMessage).toBeInTheDocument();
    expect(errorButton).toBeInTheDocument();
  });
});
