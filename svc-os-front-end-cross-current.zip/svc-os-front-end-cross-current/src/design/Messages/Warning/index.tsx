import React from "react";
import styles from "warningmessage.module.scss";

type WarningMessageProps = {
  message: string;
};

function WarningMessage({ message }: WarningMessageProps) {
  return <div className={styles.warningMessage}>{message}</div>;
}

export default WarningMessage;
