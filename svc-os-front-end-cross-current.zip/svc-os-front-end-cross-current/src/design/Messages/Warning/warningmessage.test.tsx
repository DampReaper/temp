import React from "react";
import { render, screen } from "@testing-library/react";
import WarningMessage from ".";

describe("Test the WarningMessage component", () => {
  test("should render a warning message", () => {
    render(<WarningMessage message="Warning" />);

    const warningMessage = screen.getByText("Warning");
    expect(warningMessage).toBeInTheDocument();
  });
});
