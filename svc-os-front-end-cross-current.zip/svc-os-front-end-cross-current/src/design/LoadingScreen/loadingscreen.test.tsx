import { render, screen } from "@testing-library/react";
import React from "react";
import LoadingScreen from ".";

describe("Test the LoadingScreen compoennt", () => {
  test("should render the message", () => {
    render(<LoadingScreen message="Loading" />);

    const loadingScreen = screen.getByText("Loading...");
    expect(loadingScreen).toBeInTheDocument();
  });

  test("should apply styles according to type prop", () => {
    render(<LoadingScreen message="Loading" type="fullscreen" />);

    const loadingScreen = screen.getByText("Loading...");
    expect(loadingScreen.parentNode).toHaveClass("loadingScreenFull");
  });
});
