import React from "react";
import styles from "./loadingscreen.module.scss";

function LoadingScreen({
  message,
  type = "regular",
}: {
  message: string;
  type?: string;
}) {
  return (
    <div
      className={
        type === "fullscreen" ? styles.loadingScreenFull : styles.loadingScreen
      }
    >
      <h1>{message}...</h1>
    </div>
  );
}

export default LoadingScreen;
