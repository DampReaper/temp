import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { ReactNode, useEffect, useRef } from "react";

import styles from "./popup.module.scss";

export type PopupProps = {
  /** id for the popup */
  id: string;

  /** specifies the type of popup. default is regular */
  type?: "success" | "error" | "regular";

  /** decides if the popup is visible or not */
  isOpen: boolean;

  /** children nodes to be rendered in the popup */
  children: ReactNode;

  /** boolean to whether show the close 'x' button or not. default is true */
  showCloseButton: boolean;

  /** callback function to call when the popup is closed */
  handleClose: () => void;
};

/**
 * a wrapper that wraps the children and renders them as a popup
 */
function Popup({
  id,
  type = "regular",
  isOpen,
  children,
  showCloseButton = true,
  handleClose,
}: PopupProps) {
  const popupRef = useRef<HTMLDialogElement>(null);

  // will toggle the popup whenever isOpen changes clas
  useEffect(() => {
    if (popupRef.current) {
      isOpen ? popupRef.current.showModal() : popupRef.current.close();
    }
  }, [isOpen]);

  return (
    <dialog className={styles[`${type}Container`]} ref={popupRef}>
      <div className={styles.popup}>
        {showCloseButton && (
          <button
            aria-label={`Close ${id} Popup`}
            onClick={handleClose}
            className={styles.popupButton}
          >
            <FontAwesomeIcon icon="times" />
          </button>
        )}
        {children}
      </div>
    </dialog>
  );
}

export default Popup;
