import React from "react";
import styles from "./buttonsgrid.module.scss";

type ButtonsGridProps = {
  children: React.ReactNode;
  alignWithInputs?: boolean;
  additionalStyles?: string;
};

function ButtonsGrid({
  children,
  alignWithInputs = false,
  additionalStyles,
}: ButtonsGridProps) {
  return (
    <div
      className={`${
        alignWithInputs
          ? styles.buttonsGridContainerAligned
          : styles.buttonsGridContainer
      } ${additionalStyles}`}
    >
      {children}
    </div>
  );
}

export default ButtonsGrid;
