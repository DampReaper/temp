import React from "react";
import { render, screen } from "@testing-library/react";
import Section from ".";
import ButtonsGrid from ".";
import Button from "../Button";

describe("test the Buttons Grid component", () => {
  test("should render the children correctly", () => {
    render(
      <ButtonsGrid>
        <Button
          id="primaryButton"
          text="Primary"
          type="primary"
          handleClick={() => {}}
        />
        <Button
          id="secondaryButton"
          text="Secondary"
          type="secondary"
          handleClick={() => {}}
        />
      </ButtonsGrid>
    );

    const primaryButton = screen.getByText("Primary");
    const secondaryButton = screen.getByText("Secondary");

    expect(primaryButton).toBeInTheDocument();
    expect(secondaryButton).toBeInTheDocument();
  });

  test("should align the button with Inputs", () => {
    render(
      <ButtonsGrid alignWithInputs>
        <Button
          id="primaryButton"
          text="Primary"
          type="primary"
          handleClick={() => {}}
        />
        <Button
          id="secondaryButton"
          text="Secondary"
          type="secondary"
          handleClick={() => {}}
        />
      </ButtonsGrid>
    );

    const primaryButton = screen.getByText("Primary");
    const parent = primaryButton.parentElement;

    expect(parent).toHaveClass("buttonsGridContainerAligned");
  });
});
