import { IconProp } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { MouseEventHandler } from "react";
import styles from "./button.module.scss";

type ButtonProps = {
  id: string;
  handleClick: MouseEventHandler<HTMLButtonElement>;
  disabled?: boolean;
  text: string;
  type?: "primary" | "secondary";
  icon?: IconProp;
  hidden?: boolean;
  iconClassName?: string;
};

function Button({
  id,
  handleClick,
  disabled = false,
  text,
  type = "primary",
  icon,
  hidden = false,
  iconClassName,
}: ButtonProps) {
  return (
    <button
      id={id}
      className={`${
        hidden
          ? "appearance-none"
          : type === "primary"
          ? styles.buttonPrimary
          : styles.buttonSecondary
      }`}
      onClick={handleClick}
      disabled={disabled}
      hidden={hidden}
    >
      {text}
      {icon && (
        <FontAwesomeIcon icon={icon} className={`ml-3 ${iconClassName}`} />
      )}
    </button>
  );
}

export default Button;
