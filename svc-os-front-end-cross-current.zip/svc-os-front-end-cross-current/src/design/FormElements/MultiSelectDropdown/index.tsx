import React, { ChangeEventHandler } from "react";
import Select, { ActionMeta, MultiValue, Theme } from "react-select";
import styles from "./dropdown.module.scss";

export interface dropdownOption {
  label: string;
  value: string;
}

export type MultiSelectDropdownProps = {
  /** ID for the element */
  id: string;

  /** Label to display on top of the element */
  label: string;

  /** Default values selected in the multi select dropdown */
  value: MultiValue<dropdownOption>;

  /** Handler for changes in the value */
  onChange: (
    newValue: MultiValue<dropdownOption>,
    actionMeta: ActionMeta<dropdownOption>
  ) => void;

  /** Error message to display if any */
  error?: string;

  /** Handler to check for errors */
  errorHandler?: ChangeEventHandler;

  /** Dropdown menu to display */
  options: dropdownOption[];

  /** Placeholder for the field */
  placeholder?: string;

  /** Indicates if the field is required or optional */
  required?: boolean;

  defaultMenuOpen?: boolean;

  /** Additional tailwind classes to style the input */
  additionalStyles?: string;
};

const MultiSelectDropdown = ({
  id,
  label,
  value,
  onChange,
  error,
  errorHandler,
  options,
  placeholder = "",
  required,
  defaultMenuOpen = false,
  additionalStyles,
}: MultiSelectDropdownProps) => {
  const theme = (theme: Theme) => ({
    ...theme,
    borderRadius: 6,
    border: "1px",
    boxShadow: "none",
    colors: {
      ...theme.colors,
      primary25: "rgb(249,250,251)",
      primary50: "#f5f9f9",
      primary: "rgb(4, 120, 87)",
    },
  });

  return (
    <div className={`${styles.interactionInputWrapper} ${additionalStyles}`}>
      <label htmlFor={id} className={styles.interactionInputLabel}>
        {label}
        {required && <i className={styles.required}>*</i>}
      </label>
      <div className={styles.errorWrapper}>
        <Select
          classNamePrefix={error ? "react-select-error" : "react-select"}
          className={styles.interactionInputSelect}
          options={options}
          name={id}
          id={id}
          placeholder={placeholder ? placeholder : `Select ${label}`}
          theme={theme}
          onChange={onChange}
          onBlur={(e) => errorHandler && errorHandler(e)}
          maxMenuHeight={180}
          components={{
            IndicatorSeparator: () => <></>,
          }}
          styles={{
            control: (base) => {
              return {
                ...base,
                outline: "none",
                minHeight: "2.5rem",
                border: error
                  ? "1px solid hsl(0, 66%, 49%)"
                  : "1px solid hsl(0, 0%, 73%)",
                boxShadow: "none",
                ":focus-within": {
                  borderColor: error
                    ? "hsl(0, 66%, 49%)"
                    : "hsl(158, 100%, 26%)",
                },
                fontSize: "0.875rem",
                ":hover": {
                  borderColor: error ? "hsl(0, 66%, 49%)" : "",
                },
              };
            },
            option: (provided) => ({
              ...provided,
              fontSize: "0.875rem",
            }),
          }}
          isMulti
          value={value}
          aria-invalid={error && error?.length > 0 ? true : false}
          aria-errormessage={`${id}-error`}
          openMenuOnClick
          openMenuOnFocus
          defaultMenuIsOpen={defaultMenuOpen}
        ></Select>
        <label
          htmlFor={id}
          className={
            error ? styles.errorLabel : "pointer-events-none opacity-0"
          }
        >
          {error ? `${label} is required` : "noerror"}
        </label>
      </div>
    </div>
  );
};

export default MultiSelectDropdown;
