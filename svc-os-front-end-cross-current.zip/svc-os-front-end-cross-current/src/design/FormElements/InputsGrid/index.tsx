import React from "react";
import styles from "./inputsgrid.module.scss";

type InputsGridProps = {
  children: React.ReactNode;
};

function InputsGrid({ children }: InputsGridProps) {
  return <div className={styles.inputsGridContainer}>{children}</div>;
}

export default InputsGrid;
