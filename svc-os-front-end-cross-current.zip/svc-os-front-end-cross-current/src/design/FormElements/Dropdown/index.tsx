import React, { ChangeEventHandler } from "react";
import Select, { ActionMeta, SingleValue, Theme } from "react-select";
import styles from "./dropdown.module.scss";

export interface dropdownOption {
  label: string;
  value: string;
}

export type DropdownProps = {
  /** ID for the element */
  id: string;

  /** Label to display on top of the element */
  label: string;

  /** Handler for changes in the value */
  onChange: (
    newValue: SingleValue<dropdownOption>,
    actionMeta: ActionMeta<dropdownOption>
  ) => void;

  /** Error message to display if any */
  error?: string;

  /** Handler to check for errors */
  errorHandler?: ChangeEventHandler;

  /** Value to display in the element */
  value: dropdownOption | null;

  /** Dropdown menu to display */
  options: dropdownOption[];

  /** Placeholder for the field */
  placeholder?: string;

  /** Indicates if the field is required or optional */
  required?: boolean;

  defaultMenuOpen?: boolean;

  /** Additional tailwind classes to style the input */
  additionalStyles?: string;
};

export const theme = (theme: Theme) => ({
  ...theme,
  borderRadius: 6,
  border: "1px",
  boxShadow: "none",
  colors: {
    ...theme.colors,
    primary25: "rgb(249,250,251)",
    primary50: "#f5f9f9",
    primary: "rgb(4, 120, 87)",
  },
});

const Dropdown = ({
  id,
  label,
  onChange,
  error,
  errorHandler,
  value,
  options,
  placeholder = "",
  required,
  defaultMenuOpen = false,
  additionalStyles,
}: DropdownProps) => {
  return (
    <div className={`${styles.interactionInputWrapper} ${additionalStyles}`}>
      <label htmlFor={id} className={styles.interactionInputLabel}>
        {label}
        {required && <i className={styles.required}>*</i>}
      </label>
      <div className={styles.errorWrapper}>
        <Select
          classNamePrefix={error ? "react-select-error" : "react-select"}
          value={value}
          className={styles.interactionInputSelect}
          options={options}
          name={id}
          id={id}
          placeholder={placeholder ? placeholder : `Select ${label}`}
          theme={theme}
          onChange={onChange}
          onBlur={(e) => errorHandler && errorHandler(e)}
          maxMenuHeight={180}
          components={{
            IndicatorSeparator: () => <></>,
          }}
          styles={{
            option: (provided, state) => {
              return {
                ...provided,
                cursor: "pointer",
                background: state.isSelected ? "#hsl(158, 100%, 26%)" : "",
                ":hover": {
                  background: state.isSelected ? "" : "rgba(0, 133, 84,0.1)",
                  backgroundOpacity: "50%",
                },
              };
            },
            control: (styles) => {
              return {
                ...styles,
                outline: "none",
                height: "2.5rem",
                border: error
                  ? "1px solid hsl(0, 66%, 49%)"
                  : "1px solid hsl(0, 0%, 73%)",
                boxShadow: "none",
                ":focus-within": {
                  borderColor: error
                    ? "hsl(0, 66%, 49%)"
                    : "hsl(158, 100%, 26%)",
                },
                ":hover": {
                  borderColor: error ? "hsl(0, 66%, 49%)" : "",
                },
              };
            },
            singleValue: (provided) => {
              const opacity = 1;
              const transition = "opacity 300ms";
              return { ...provided, opacity, transition };
            },
          }}
          aria-invalid={error && error?.length > 0 ? true : false}
          aria-errormessage={`${id}-error`}
          openMenuOnClick
          openMenuOnFocus
          defaultMenuIsOpen={defaultMenuOpen}
        ></Select>
        <label
          htmlFor={id}
          className={
            error ? styles.errorLabel : "pointer-events-none opacity-0"
          }
        >
          {error ? `${label} is required` : "noerror"}
        </label>
      </div>
    </div>
  );
};

export default Dropdown;
