import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import Dropdown from ".";

const dropdownOptions = [
  {
    label: "hello",
    value: "hello",
  },
  {
    label: "hi",
    value: "hi",
  },
];

describe("Test the Dropdown component", () => {
  test("should render the Dropdown component", () => {
    render(
      <Dropdown
        options={[]}
        id="dropdown"
        label="Dropdown"
        onChange={() => {
          console.log("input changed");
        }}
        value={null}
      />
    );

    const input = screen.getByRole("combobox");
    expect(input).toBeInTheDocument();
  });

  test("should have the placeholder", () => {
    render(
      <Dropdown
        options={[]}
        id="dropdown"
        label="Dropdown"
        onChange={() => {
          console.log("input changed");
        }}
        value={null}
      />
    );

    const input = screen.getByText("Select Dropdown");
    expect(input).toBeInTheDocument();

    render(
      <Dropdown
        options={[]}
        id="dropdown"
        label="Dropdown"
        onChange={() => {
          console.log("input changed");
        }}
        value={null}
        placeholder="Hello"
      />
    );

    const input1 = screen.getByText("Hello");
    expect(input1).toBeInTheDocument();
  });

  test("should fire the onBlur handler", () => {
    const mockHandler = jest.fn();
    render(
      <Dropdown
        options={[]}
        id="dropdown"
        label="Dropdown"
        onChange={mockHandler}
        value={null}
        errorHandler={mockHandler}
      />
    );

    const input = screen.getByRole("combobox");
    fireEvent.blur(input);
    expect(mockHandler.mock.calls.length).toEqual(1);
  });

  test("should render the menu", () => {
    const mockHandler = jest.fn();
    const { container } = render(
      <Dropdown
        options={dropdownOptions}
        id="dropdown"
        label="Dropdown"
        onChange={mockHandler}
        value={dropdownOptions[0]}
        defaultMenuOpen
      />
    );

    const menu = container.getElementsByClassName("react-select__menu-list")[0];
    expect(menu.children.length).toBe(2);
  });

  test("should show error message", () => {
    const mockHandler = jest.fn();
    render(
      <Dropdown
        options={dropdownOptions}
        id="dropdown"
        label="Dropdown"
        onChange={mockHandler}
        value={dropdownOptions[0]}
        error="error"
      />
    );
    const errorMessage = screen.getByText("Dropdown is required");
    expect(errorMessage).toBeInTheDocument();
  });

  test("should show * if field is required", () => {
    const mockHandler = jest.fn();
    render(
      <Dropdown
        options={dropdownOptions}
        id="dropdown"
        label="Dropdown"
        onChange={mockHandler}
        value={dropdownOptions[0]}
        required
      />
    );
    const asterik = screen.getByText("*");
    expect(asterik).toBeInTheDocument();
  });
});
