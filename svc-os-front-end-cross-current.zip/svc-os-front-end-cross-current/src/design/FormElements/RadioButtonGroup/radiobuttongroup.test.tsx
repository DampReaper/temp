import { render, screen } from "@testing-library/react";
import React, { ChangeEvent, useState } from "react";
import RadioButtonGroup from ".";
import RadioButton from "../RadioButton";

const RadioGroup = () => {
  const [checked, setChecked] = useState("no");

  const handleRadioChange = (e: ChangeEvent<HTMLInputElement>) => {
    setChecked(e.target.id);
  };
  return (
    <RadioButtonGroup>
      <RadioButton
        id="yes"
        text="Yes"
        value={checked === "yes"}
        onChangeHandler={handleRadioChange}
      />
      <RadioButton
        id="no"
        text="No"
        value={checked === "no"}
        onChangeHandler={handleRadioChange}
      />

      <RadioButton
        id="maybe"
        text="Maybe"
        value={checked === "maybe"}
        onChangeHandler={handleRadioChange}
      />
    </RadioButtonGroup>
  );
};

describe("Test the RadioButtonGroup component", () => {
  test("should render radio buttons as children", () => {
    render(<RadioGroup />);

    const radioGroup = screen.getByRole("radiogroup");
    expect(radioGroup).toBeInTheDocument();
    expect(radioGroup.children.length).toEqual(3);
  });
});
