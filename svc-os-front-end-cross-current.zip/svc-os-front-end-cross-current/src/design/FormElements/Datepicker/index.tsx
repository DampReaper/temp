import React, { ChangeEvent, ChangeEventHandler } from "react";
import styles from "./input.module.scss";
import "./datepicker.scss";

// @ts-ignore
import ReactDatePicker, {
  ReactDatePickerCustomHeaderProps,
} from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export type DatepickerProps = {
  /** ID for the element */
  id: string;

  /** Label to display on top of the element */
  label: string;

  /** Handler for changes in the value */
  onChange: (date: Date) => void;

  /** Error message to display if any */
  error?: string;

  /** Handler to check for errors */
  errorHandler?: ChangeEventHandler;

  /** Value to display in the element */
  value: string;

  /** Indicates if the field is required or optional */
  required?: boolean;

  minDate: Date;

  maxDate: Date;

  onChangeRaw?: (e: ChangeEvent<HTMLInputElement>) => void;
};

const Datepicker = ({
  id,
  label,
  onChange,
  error,
  errorHandler,
  value,
  minDate,
  maxDate,
  required,
  onChangeRaw,
}: DatepickerProps) => {
  const getRange = (start: number, end: number) => {
    return Array.from(Array(end - start + 1).keys()).map((x) => x + start);
  };

  const years = getRange(minDate?.getFullYear(), maxDate?.getFullYear());
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  return (
    <div className={`${styles.interactionInputWrapper}`}>
      <label htmlFor={id} className={styles.interactionInputLabel}>
        {label}
        {required && <i className={styles.required}>*</i>}
      </label>
      <div className={styles.errorWrapper}>
        <ReactDatePicker
          renderCustomHeader={({
            date,
            changeYear,
            changeMonth,
            decreaseMonth,
            increaseMonth,
            prevMonthButtonDisabled,
            nextMonthButtonDisabled,
          }: ReactDatePickerCustomHeaderProps) => (
            <div className={styles.monthYearSelector}>
              <button
                aria-label="Previous Month"
                onClick={(e) => {
                  e.preventDefault();
                  decreaseMonth();
                }}
                disabled={prevMonthButtonDisabled}
                className={prevMonthButtonDisabled ? styles.disabledArrow : ""}
              >
                <FontAwesomeIcon icon="arrow-left" title="prevMonthButton" />
              </button>

              <select
                data-testid="monthSelector"
                value={months[date.getMonth()]}
                onChange={({ target: { value } }) =>
                  changeMonth(months.indexOf(value))
                }
                className="p-1"
              >
                {months.map((option) => (
                  <option
                    data-testid="monthOptions"
                    key={option}
                    value={option}
                  >
                    {option}
                  </option>
                ))}
              </select>

              <select
                data-testid="yearSelector"
                value={date.getFullYear()}
                onChange={({ target: { value } }) =>
                  changeYear(parseInt(value))
                }
                className="p-1"
              >
                {years.map((option) => (
                  <option data-testid="yearOptions" key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>

              <button
                aria-label="Next Month"
                onClick={(e) => {
                  e.preventDefault();
                  increaseMonth();
                }}
                disabled={nextMonthButtonDisabled}
                className={nextMonthButtonDisabled ? styles.disabledArrow : ""}
              >
                <FontAwesomeIcon icon="arrow-right" title="nextMonthButton" />
              </button>
            </div>
          )}
          id={id}
          selected={value === "" ? null : new Date(value)}
          onChange={onChange}
          onBlur={errorHandler}
          placeholderText="mm/dd/yyyy"
          minDate={minDate}
          maxDate={maxDate}
          strictParsing
          onChangeRaw={onChangeRaw}
          showPopperArrow={false}
          closeOnScroll
          popperClassName={error ? "datepicker__popper--error" : ""}
          className={
            error
              ? styles.interactionInputTextError
              : styles.interactionInputText
          }
        />
        <label
          htmlFor={id}
          className={
            error ? styles.errorLabel : "pointer-events-none opacity-0"
          }
        >
          {error ? error : "noerror"}
        </label>
      </div>
    </div>
  );
};

export default Datepicker;
