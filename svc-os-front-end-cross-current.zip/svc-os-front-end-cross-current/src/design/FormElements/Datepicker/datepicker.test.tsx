import {
  act,
  cleanup,
  fireEvent,
  render,
  screen,
} from "@testing-library/react";
import React from "react";
import Datepicker from ".";

describe("Test the datepicker component", () => {
  test("should render the datepicker correctly", () => {
    const mockHandler = jest.fn();
    const { container } = render(
      <Datepicker
        id="date"
        label="Pick Date"
        maxDate={new Date()}
        minDate={new Date(0)}
        onChange={mockHandler}
        value=""
      />
    );

    const datepicker = container.getElementsByClassName(
      "react-datepicker-wrapper"
    )[0];

    expect(datepicker).toBeInTheDocument();
  });

  test("should render the prev and next month buttons correctly", async () => {
    const mockHandler = jest.fn();
    const { container } = render(
      <Datepicker
        id="date"
        label="Pick Date"
        maxDate={new Date()}
        minDate={new Date(0)}
        onChange={mockHandler}
        value=""
      />
    );

    const datepicker = container.getElementsByClassName(
      "interactionInputText"
    )[0];

    fireEvent.focusIn(datepicker);
    await act(async () => await Promise.resolve());

    const prev = screen.getByTitle("prevMonthButton");
    expect(prev).toBeInTheDocument();

    const next = screen.getByTitle("nextMonthButton");
    expect(next).toBeInTheDocument();

    expect(next.parentElement?.parentElement).toHaveAttribute("disabled");

    fireEvent.click(prev);
    fireEvent.click(next);

    const monthSelector = screen.getByTestId("monthSelector");
    const monthOptions: HTMLOptionElement[] =
      screen.getAllByTestId("monthOptions");

    fireEvent.change(monthSelector, {
      target: { value: "April" },
    });

    expect(monthOptions[3].selected).toBeTruthy();

    const yearSelector = screen.getByTestId("yearSelector");
    const yearOptions: HTMLOptionElement[] =
      screen.getAllByTestId("yearOptions");

    fireEvent.change(yearSelector, {
      target: { value: "1969" },
    });

    expect(yearOptions[0].selected).toBeTruthy();
  });

  test("should show * if field is required", () => {
    const mockHandler = jest.fn();
    render(
      <Datepicker
        id="date"
        label="Pick Date"
        maxDate={new Date()}
        minDate={new Date(0)}
        onChange={mockHandler}
        value=""
        required
      />
    );
    const asterik = screen.getByText("*");
    expect(asterik).toBeInTheDocument();
  });

  test("should have selected value", () => {
    const mockHandler = jest.fn();
    render(
      <Datepicker
        id="date"
        label="Pick Date"
        maxDate={new Date()}
        minDate={new Date(0)}
        onChange={mockHandler}
        value="01/01/2022"
      />
    );

    const input = screen.getByLabelText("Pick Date");
    expect(input).toHaveValue("01/01/2022");
  });

  test("should have error styles and show error message", () => {
    const mockHandler = jest.fn();
    render(
      <Datepicker
        id="date"
        label="Pick Date"
        maxDate={new Date()}
        minDate={new Date(0)}
        onChange={mockHandler}
        value="01/01/2022"
        error="Error"
      />
    );

    const errorMessage = screen.getByText("Error");
    expect(errorMessage).toBeInTheDocument();
  });
});
