import React, { useState } from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import Checkbox from ".";

const CheckboxComponent = () => {
  const [checked, setChecked] = useState(false);
  return (
    <Checkbox
      id="radioYes"
      text="Yes"
      value={checked}
      onChangeHandler={() => setChecked(!checked)}
    />
  );
};

describe("Test the Checkbox component", () => {
  test("should render the Checkbox", () => {
    render(<CheckboxComponent />);
    const checkbox = screen.getByLabelText("Yes");
    expect(checkbox).toBeInTheDocument();
  });

  test("should fire the onChangeHandler", () => {
    render(<CheckboxComponent />);
    const checkbox = screen.getByLabelText("Yes");
    fireEvent.click(checkbox);
    expect(checkbox).toBeChecked();
  });
});
