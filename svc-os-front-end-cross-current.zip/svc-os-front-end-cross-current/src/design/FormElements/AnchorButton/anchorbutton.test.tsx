import React from "react";
import { render, screen } from "@testing-library/react";
import AnchorButton from ".";

describe("Test the Anchor Button component", () => {
  test("should render correctly", () => {
    render(<AnchorButton href="" text="hello" id="hello" icon="search" />);
    const anchorButton = screen.getByText(/hello/i);
    expect(anchorButton).toBeInTheDocument();
    expect(anchorButton).toHaveTextContent("hello");
  });

  test("should apply type prop styles correctly", () => {
    render(<AnchorButton href="" text="hello" id="hello" type="primary" />);
    const anchorButton = screen.getByText(/hello/i);
    expect(anchorButton).toBeInTheDocument();
    expect(anchorButton).toHaveClass("anchorButtonPrimary");

    render(
      <AnchorButton href="" text="secondary" id="hello" type="secondary" />
    );
    const anchorButton2 = screen.getByText(/secondary/i);
    expect(anchorButton2).toBeInTheDocument();
    expect(anchorButton2).toHaveClass("anchorButtonSecondary");
  });
});
