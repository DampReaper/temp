import { fireEvent, render, screen } from "@testing-library/react";
import React, { useState } from "react";
import RadioButton from ".";

const RadioButtonComponent = () => {
  const [checked, setChecked] = useState(false);
  return (
    <RadioButton
      id="radioYes"
      text="Yes"
      value={checked}
      onChangeHandler={() => setChecked(!checked)}
    />
  );
};

describe("Test the RadioButton component", () => {
  test("should render the Radio Button", () => {
    render(<RadioButtonComponent />);
    const radio = screen.getByLabelText("Yes");
    expect(radio).toBeInTheDocument();
  });

  test("should fire the onChangeHandler", () => {
    render(<RadioButtonComponent />);
    const radio = screen.getByLabelText("Yes");
    fireEvent.click(radio);
    expect(radio).toBeChecked();
  });
});
