import React, { ChangeEventHandler } from "react";
import styles from "./radiobutton.module.scss";

export type RadioButtonProps = {
  id: string;
  onChangeHandler: ChangeEventHandler<HTMLInputElement>;
  text: string;
  value: boolean;
};

function RadioButton({ id, onChangeHandler, text, value }: RadioButtonProps) {
  return (
    <div className={styles.radioWrapper}>
      <label className={styles.radioButton} id={id}>
        <input
          className={styles.radioInput}
          type="radio"
          id={id}
          checked={value ? true : false}
          onChange={onChangeHandler}
        />

        <span className={value ? "font-medium text-ctz-green-100" : ""}>
          {text}
        </span>
      </label>
    </div>
  );
}

export default RadioButton;
