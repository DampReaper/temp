import { IconProp } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { KeyboardEvent } from "react";

import styles from "./tabs.module.scss";

export interface tab {
  /** Name of the tab */
  name: string;

  /** Icon for the tab */
  icon: IconProp;
}

export type TabsProps = {
  /** List of tabs to render */
  tabList: tab[];

  /** Current Active Tab */
  activeTab: string;

  /** Handler to change tabs using mouse */
  handleTabChange: (newtab: tab) => void;
};

const Tabs = ({ tabList, activeTab, handleTabChange }: TabsProps) => {
  const handleKeyDownEvent = (e: KeyboardEvent<HTMLUListElement>) => {
    if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
      let tabToBeActivated = tabList.findIndex(
        (t: tab) => t.name === activeTab
      );
      tabToBeActivated =
        tabToBeActivated === 0 ? tabList.length - 1 : tabToBeActivated - 1;
      handleTabChange(tabList[tabToBeActivated]);
      document.getElementById(tabList[tabToBeActivated].name)?.focus();
    }
    if (e.key === "ArrowRight" || e.key === "ArrowDown") {
      let tabToBeActivated = tabList.findIndex(
        (t: tab) => t.name === activeTab
      );
      tabToBeActivated =
        tabToBeActivated === tabList.length - 1 ? 0 : tabToBeActivated + 1;
      handleTabChange(tabList[tabToBeActivated]);
      document.getElementById(tabList[tabToBeActivated].name)?.focus();
    }
  };

  return (
    <ul className={styles.tabs} role="tablist" onKeyDown={handleKeyDownEvent}>
      {tabList.map((tab) => {
        return (
          <li
            className={`${
              activeTab === tab.name ? styles.tabActive : styles.tab
            }`}
            id={tab.name}
            role="tab"
            tabIndex={activeTab === tab.name ? 0 : -1}
            key={tab.name}
          >
            <div
              onClick={() => handleTabChange(tab)}
              role="button"
              className={`${
                activeTab === tab.name
                  ? styles.tabWrapperActive
                  : styles.tabWrapper
              }`}
            >
              <h1
                className={`${
                  activeTab === tab.name ? styles.tabTextActive : styles.tabText
                }`}
              >
                <FontAwesomeIcon icon={tab.icon} className={styles.tabIcon} />
                {tab.name}
              </h1>
            </div>
          </li>
        );
      })}
    </ul>
  );
};

export default Tabs;
