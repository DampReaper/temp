import { fireEvent, render, screen } from "@testing-library/react";
import React, { useState } from "react";
import Tabs, { tab } from ".";

const ComponentWithTabs = () => {
  const [activeTab, setActiveTab] = useState("Search");
  const tabOptions: tab[] = [
    {
      icon: "search",
      name: "Search",
    },
    {
      icon: "book",
      name: "Book",
    },
  ];
  return (
    <Tabs
      activeTab={activeTab}
      tabList={tabOptions}
      handleTabChange={(tab) => setActiveTab(tab.name)}
    />
  );
};

describe("Test the Tabs component", () => {
  beforeEach(() => render(<ComponentWithTabs />));

  test("should render the tabs correctly", () => {
    const searchTab = screen.getByText("Search");
    const bookTab = screen.getByText("Book");
    expect(searchTab).toBeInTheDocument();
    expect(bookTab).toBeInTheDocument();
  });

  test("should apply styles to active tab", () => {
    const searchTab = screen.getByText("Search");
    expect(searchTab).toHaveClass("tabTextActive");
  });

  test("should switch the active tab when clicked", () => {
    const tabs = screen.getAllByRole("button");
    expect(tabs[1]).not.toHaveClass("tabWrapperActive");
    fireEvent.click(tabs[1]);
    expect(tabs[1]).toHaveClass("tabWrapperActive");
  });

  test("should switch tabs on keydown events", () => {
    const tabsParent = screen.getByRole("tablist");
    const searchTab = screen.getByText("Search");
    expect(searchTab).toHaveClass("tabTextActive");

    // arrow right click
    fireEvent.keyDown(tabsParent, {
      key: "ArrowRight",
    });
    expect(searchTab).toHaveClass("tabText");

    // arrow right click
    fireEvent.keyDown(tabsParent, {
      key: "ArrowRight",
    });
    expect(searchTab).toHaveClass("tabTextActive");

    // arrow left click
    fireEvent.keyDown(tabsParent, {
      key: "ArrowLeft",
    });
    expect(searchTab).toHaveClass("tabText");

    // arrow left click
    fireEvent.keyDown(tabsParent, {
      key: "ArrowLeft",
    });
    expect(searchTab).toHaveClass("tabTextActive");

    // arrow up click
    fireEvent.keyDown(tabsParent, {
      key: "ArrowUp",
    });
    expect(searchTab).toHaveClass("tabText");
  });
});
