import applicationReducer from './slices/applicationSlice';
import { configureStore } from '@reduxjs/toolkit';

/**
 * Store
 *
 * Redux store.
 */

export const storeInstance = configureStore({
  reducer: {
    application: applicationReducer,
 
  }
});

export type AppDispatch = typeof storeInstance.dispatch;
export type RootState = ReturnType<typeof storeInstance.getState>;
