import { createBrowserHistory } from 'history';

/**
 * History
 *
 * Common code for History.
 */

const history = createBrowserHistory();
export default history;
