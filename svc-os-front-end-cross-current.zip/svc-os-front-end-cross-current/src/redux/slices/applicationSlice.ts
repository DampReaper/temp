import { PayloadAction, createSlice } from '@reduxjs/toolkit';

import { LOG_STYLE } from 'utils';

/**
 * applicationSlice
 *
 * Contains TrackIt page states.
 * Whether to display Contact Details or Contact History.
 * If ticket has been validated.
 */

export const YesNoUndefined = {
  Yes: true,
  No: false,
  Undefined: 'Undefined'
} as const;

export interface ErrorType {
  errorControl: string;
  errorMessage: string;
}
export type YesNoUndefined = typeof YesNoUndefined[keyof typeof YesNoUndefined];

export interface Application {
  applicationId: string;
  branchNum: string;
  originator: string;
  referralId: string;
  reviewedOverdraftChoices: YesNoUndefined;
  salesId: string;
  error?: ErrorType[];
}

const initialState: Application = {
  applicationId: '',
  reviewedOverdraftChoices: YesNoUndefined.Undefined,
  branchNum: '',
  originator: '',
  referralId: '',
  salesId: '',
  error: [] as ErrorType[]
};

export const applicationSlice = createSlice({
  name: 'application',
  initialState,
  reducers: {
    setApplicationId: (state, action: PayloadAction<string>) => {
      console.log(...LOG_STYLE.REDUX, 'applicationSlice.setApplicationId', action.payload);
      state.applicationId = action.payload;
    },
    // setBranchNum: (state, action: PayloadAction<string>) => {
    //   console.log(...LOG_STYLE.REDUX, 'applicationSlice.setBranchNum', action.payload);
    //   state.branchNum = action.payload;
    // },
    // setOriginator: (state, action: PayloadAction<string>) => {
    //   console.log(...LOG_STYLE.REDUX, 'applicationSlice.setOriginator', action.payload);
    //   state.originator = action.payload;
    // },
    // setReferralId: (state, action: PayloadAction<string>) => {
    //   console.log(...LOG_STYLE.REDUX, 'applicationSlice.setReferralId', action.payload);
    //   state.referralId = action.payload;
    // },
    // setReviewedOverdraftChoices: (state, action: PayloadAction<YesNoUndefined>) => {
    //   console.log(...LOG_STYLE.REDUX, 'applicationSlice.setReviewedOverdraftChoices', action.payload);
    //   state.reviewedOverdraftChoices = action.payload;
    // },
    // setSalesId: (state, action: PayloadAction<string>) => {
    //   console.log(...LOG_STYLE.REDUX, 'applicationSlice.setSalesId', action.payload);
    //   state.salesId = action.payload;
    // },
    validateBankInfo: (state) => {
      console.log(...LOG_STYLE.REDUX, 'applicationSlice.validateBankInfo');
      let errors: ErrorType[] = [];
      if (state.branchNum === null || state.branchNum === undefined) {
        errors.push({ errorControl: 'branchNum', errorMessage: 'branchNum is required' });
      }
      
      state.error = errors;
    },
    updateFormData: (state, action) => {
      console.log(...LOG_STYLE.REDUX, 'applicationSlice.updateFormData', action.payload);
      Object.assign(state, action.payload);
    },

    clearApplication: (state) => {
      console.log(...LOG_STYLE.REDUX, 'applicationSlice.clearApplication');
      Object.assign(state, initialState);
    }
  }
});

export const {
  clearApplication,
  updateFormData,
  setApplicationId
  //  setBranchNum,setOriginator, setReferralId, setReviewedOverdraftChoices, setSalesId
} = applicationSlice.actions;

export default applicationSlice.reducer;
