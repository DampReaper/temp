declare module "*.module.scss";
declare module "globalStore/*";
