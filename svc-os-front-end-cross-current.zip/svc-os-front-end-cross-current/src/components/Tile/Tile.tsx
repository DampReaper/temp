import PropTypes from 'prop-types';
import React from 'react';
import { useNavigate } from 'react-router-dom';

const Tile = ({ color, label, to }) => {
  const navigate = useNavigate();
  
  const handleClick = () => {
    navigate(to);
  };

  const tileStyle = {
    backgroundColor: '#white',
    height: '100px',
    width: '200px',
    margin: '10px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    fontSize: '24px',
    color: '#black',
    cursor: 'pointer',
    border: '5px solid black',
   
  };

  return (
    <div style={tileStyle} onClick={handleClick}>
      {label}
    </div>
  );
};
Tile.propTypes = {
  color: PropTypes.string.isRequired,
  label: PropTypes.string.isRequired,
  to: PropTypes.string.isRequired,
};
export default Tile;