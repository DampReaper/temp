import { AUTHENTICATION_METHOD, CONTACT_TYPE, SEARCH_TYPE, SHOW_TICKET } from 'definitions';
import { Company, Customer, Employee, TicketService } from 'services';
import { ITicketSearchState, setHasData, setSearchByBranch, setSearchByContactId, setSearchType } from 'reduxStore/slices/ticketSearchSlice';
import React, { useEffect } from 'react';
import { clearContact, setContact, setTicket } from 'reduxStore/slices/contactSlice';
import { clearTrackItApp, pushBreadCrumb, setShowTicket } from 'reduxStore/slices/trackItAppSlice';
import { useAppDispatch, useAppSelector } from 'reduxStore/hooks';

import { AgentSearch } from 'components/Custom/Search/AgentSearch';
import { BranchSearch } from 'components/Custom/Search/BranchSearch';
import { CompanySearch } from 'components/Custom/Search/CompanySearch';
import { ContactHistoryList } from '../Contact/ContactHistoryList/ContactHistoryList';
import CustomerSearch from 'components/Custom/Search/CustomerSearch';
import Dropdown from 'components/Reusable/Dropdown';
import { EmployeeDetail } from '../Contact/ContactDetail/EmployeeDetail/EmployeeDetail';
import { EmployeeSearch } from '../Search/EmployeeSearch';
import { EmployeeService } from 'services/EmployeeService';
import InputsGrid from 'components/Reusable/InputsGrid';
import { LOG_STYLE } from 'utils';
import { SearchFilterRow } from 'components/Custom/Search/SearchFilterRow';
import Section from 'components/Reusable/Section';
import { TicketSearch } from 'components/Custom/Search/TicketSearch';
import { TicketSearchList } from 'components/Custom/Contact/ContactHistoryList/TicketSearchList';
import { ViewContactTicket } from 'pages/ViewContactTicket';
import { clearContactHistory } from 'reduxStore/slices/contactHistorySlice';
import { setAuthenticationMethod } from 'reduxStore/slices/interactionSlice';

const searchTypeOptions = [
  { value: SEARCH_TYPE.EMPLOYEE, label: SEARCH_TYPE.EMPLOYEE },
  { value: SEARCH_TYPE.CUSTOMER, label: SEARCH_TYPE.CUSTOMER },
  { value: SEARCH_TYPE.COMPANY, label: SEARCH_TYPE.COMPANY }
];

//TODO : Change Search type to be based on available agent options determined by entitlement.

/**
 * Renders an 'Search' Component.
 * containing a type-a-head search input box and a contact search type dropdown.
 * User chooses which Contact type to search for.
 * Upon selecting a contact, progresses to ContactItem view.
 */
export default function CreateNewTicket() {
  console.debug(...LOG_STYLE.RENDER1, 'CreateNewTicket');

  const dispatch = useAppDispatch();

  const organization = useAppSelector((state) => state.agent.organization);

  const currentContact = useAppSelector((state) => state.contact.currentContact);
  const currentContactId = useAppSelector((state) => state.contact.currentContact.id);
  const currentContactType = useAppSelector((state) => state.contact.currentContact.type);
  const ticketSearchData: ITicketSearchState = useAppSelector((state) => state.ticketSearch);
  const authenticationMethod = useAppSelector((state) => state.interaction.authenticationMethod);
  const searchType = ticketSearchData.searchType;

  /**
   * Event fired when search dropdown selection is made.
   *
   * @param e results of search selection.
   */
  const onSearchSelect = (e) => {
    console.debug(...LOG_STYLE.ACTION1, 'onSearchSelect');

    dispatch(setSearchType(e.value));
  };

  /**
   * Event fired when a typeAhead component has selected one Employee.
   * ** Used for finding an Employee and viewing/creating new tickets **
   *
   *    Get the full Employee data from database.
   *    Save Employee data in redux.
   *    Transition to view.
   *
   * @param {string} id
   */
  const onSelectEmployee = async (id: string) => {
    console.log(...LOG_STYLE.ACTION1, 'onSelectEmployee');
    console.debug(...LOG_STYLE.DEBUG1, `Search Contact Selected: ${id}`);
    
    // TODO: Do we need to clear redux data?

    // Look up the rest of the employee data.
    const employee: Employee = (await EmployeeService.shared.getEmployee(id)).data;

    dispatch(setContact(employee));
    dispatch(setAuthenticationMethod(AUTHENTICATION_METHOD.UNKNOWN));
    // dispatch(pushBreadCrumb('Search/Employee'));

    // Transition to view.
    // navigate('/ViewContactTicket');
  };

  /**
   * Event fired when a typeAhead component has selected one Customer.
   * ** Used for finding a Customer and viewing/creating new tickets **
   *
   *    Save Customer data in redux.
   *    Transition to view.
   *
   * @param {Customer} customer
   */
  const onSelectCustomer = (customer: Customer) => {
    console.log(...LOG_STYLE.ACTION1, 'onSelectCustomer', customer);

    // TODO: Do we need to clear redux data?

    dispatch(setContact(customer || ({} as Customer)));
    dispatch(setAuthenticationMethod(AUTHENTICATION_METHOD.UNKNOWN));

    // Transition to view.
   // navigate('/ViewContactTicket');
  };

  /**
   * Event fired when a typeAhead component has selected one Company.
   * ** Used for finding a Company and viewing/creating new tickets **
   *
   *    Save Company data in redux.
   *    Transition to view.
   *
   * @param {Company} company
   */
  const onSelectCompany = (company: Company) => {
    console.log(...LOG_STYLE.ACTION1, 'onSelectCompany', company);

    // TODO: Do we need to clear redux data?

    dispatch(setContact(company || ({} as Company)));
    dispatch(setAuthenticationMethod(AUTHENTICATION_METHOD.UNKNOWN));

    // Transition to view.
   // navigate('/ViewContactTicket');
  };

  /**
   * Handles the button search event.
   * ** Used to search for tickets. **
   *
   *    On a unique search like 'ByTicketId' then navigates to view the ticket.
   *    On non-unique search results show/display table.
   */

  useEffect(() => {
    console.debug(...LOG_STYLE.EFFECT1, 'CreateNewTicket');

    // Clear Redux data when a search page loads.
    dispatch(clearTrackItApp());
    dispatch(clearContactHistory());
    dispatch(clearContact());
  }, []);

  return (
    <>
      {!currentContactType && (
        <Section name={'Search'}>
          <InputsGrid>
            <Dropdown id={'ddlSearchBy'} label={'Search Type'} onChange={onSearchSelect} value={{ value: searchType, label: searchType }} options={searchTypeOptions} />
            <div className={'col-span-3'}>
              {searchType == SEARCH_TYPE.EMPLOYEE && <EmployeeSearch onSelectEmployee={onSelectEmployee} />}
              {searchType == SEARCH_TYPE.CUSTOMER && <CustomerSearch onSelectCustomer={onSelectCustomer} />}
              {searchType == SEARCH_TYPE.COMPANY && <CompanySearch onSelectCompany={onSelectCompany} />}
            </div>
          </InputsGrid>
        </Section>
      )}
      <ViewContactTicket />
      {/* {currentContactType == CONTACT_TYPE.EMPLOYEE && <EmployeeDetail contact={currentContact} />}
      {currentContactType == CONTACT_TYPE.CUSTOMER && <div>CUSTOMER</div>}
      {currentContactType == CONTACT_TYPE.COMPANY && <div>COMPANY</div>} */}
      {/* {currentContactId && currentContactId.length > 0 && authenticationMethod != AUTHENTICATION_METHOD.UNKNOWN && <ViewContactTicket />} */}

        
    </>
  );
}

/**
 * 
ContactType - Emp/Cust/Cpy
hasContact - ShowContactDetails | Show Search 
isAuthenticated & hasContactData => show CallHistory.
 */
