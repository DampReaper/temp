import { Agent, Branch, Company, Customer, Employee, TicketService } from 'services';
import { ITicketSearchState, setHasData, setSearchByBranch, setSearchByContactId, setSearchType } from 'reduxStore/slices/ticketSearchSlice';
import React, { useEffect } from 'react';
import { SEARCH_TYPE, SHOW_TICKET } from 'definitions';
import { clearContact, setContact, setTicket } from 'reduxStore/slices/contactSlice';
import { clearTrackItApp, pushBreadCrumb, setShowTicket } from 'reduxStore/slices/trackItAppSlice';
import { useAppDispatch, useAppSelector } from 'reduxStore/hooks';

import { AgentSearch } from 'components/Custom/Search/AgentSearch';
import { BranchSearch } from 'components/Custom/Search/BranchSearch';
import { CompanySearch } from 'components/Custom/Search/CompanySearch';
import CustomerSearch from 'components/Custom/Search/CustomerSearch';
import Dropdown from 'components/Reusable/Dropdown';
import { EmployeeSearch } from '../Search/EmployeeSearch';
import { EmployeeService } from 'services/EmployeeService';
import InputsGrid from 'components/Reusable/InputsGrid';
import { LOG_STYLE } from 'utils';
import { SearchFilterRow } from 'components/Custom/Search/SearchFilterRow';
import Section from 'components/Reusable/Section';
import { TicketSearch } from 'components/Custom/Search/TicketSearch';
import { TicketSearchList } from 'components/Custom/Contact/ContactHistoryList/TicketSearchList';
import { clearContactHistory } from 'reduxStore/slices/contactHistorySlice';

const searchTypeOptions = [
  { value: SEARCH_TYPE.BY_TICKET_ID, label: SEARCH_TYPE.BY_TICKET_ID },
  { value: SEARCH_TYPE.BY_WORKFLOW_CASE, label: SEARCH_TYPE.BY_WORKFLOW_CASE },
  { value: SEARCH_TYPE.BY_TICKET_EMPLOYEE, label: SEARCH_TYPE.BY_TICKET_EMPLOYEE },
  { value: SEARCH_TYPE.BY_TICKET_AGENT, label: SEARCH_TYPE.BY_TICKET_AGENT },
  { value: SEARCH_TYPE.BY_TICKET_BRANCH, label: SEARCH_TYPE.BY_TICKET_BRANCH },
  { value: SEARCH_TYPE.BY_TICKET_CUSTOMER, label: SEARCH_TYPE.BY_TICKET_CUSTOMER },
  { value: SEARCH_TYPE.BY_TICKET_COMPANY, label: SEARCH_TYPE.BY_TICKET_COMPANY },
  { value: SEARCH_TYPE.MY_OPEN_ISSUES, label: SEARCH_TYPE.MY_OPEN_ISSUES },
  { value: SEARCH_TYPE.MY_TICKETS, label: SEARCH_TYPE.MY_TICKETS }
];

//TODO : Change Search type to be based on available agent options determined by entitlement.

/**
 * Renders an 'Search' Component.
 * containing a type-a-head search input box and a contact search type dropdown.
 * User chooses which Contact type to search for.
 * Upon selecting a contact, progresses to ContactItem view.
 */
export default function SearchForExistingTicket() {
  console.debug(...LOG_STYLE.RENDER1, 'SearchForExistingTicket');

  const dispatch = useAppDispatch();

  const organization = useAppSelector((state) => state.agent.organization);
  const ticketSearchData: ITicketSearchState = useAppSelector((state) => state.ticketSearch);
  const searchByTicketId = useAppSelector((state) => state.ticketSearch.searchCriteria.searchByTicketId);
  const searchType = ticketSearchData.searchType;

  const showFilterRow = searchType == SEARCH_TYPE.EMPLOYEE || searchType == SEARCH_TYPE.CUSTOMER || searchType == SEARCH_TYPE.COMPANY ? false : true;
  const showFilterButton = searchType == SEARCH_TYPE.BY_WORKFLOW_CASE || searchType == SEARCH_TYPE.BY_TICKET_ID ? false : true;

  /**
   * Event fired when search dropdown selection is made.
   *
   * @param e results of search selection.
   */
  const onSearchSelect = (e) => {
    console.debug(...LOG_STYLE.ACTION1, 'onSearchSelect');

    dispatch(setSearchType(e.value));
  };
 
  /**
   * Event fired when a typeAhead component has selected one Branch.
   * ** Used to search for tickets. **
   *    Save as search by branch data in redux.
   *
   * @param branches
   */
  const onSelectBranch = async (branches: Branch[]) => {
    console.log(...LOG_STYLE.ACTION1, 'onSelectBranch', branches);

    const branchIds = branches.map((b: Branch) => {
      return b.branchId;
    });

    dispatch(setSearchByBranch(branchIds));
  };

  /**
   * Event fired when a typeAhead component has selected one Contact.
   * ** Used to search for tickets. **
   *    Save as search by Contact data in redux.
   *
   * @param contactId
   */
  const onSearchContact = async (contactId: string) => {
    console.log(...LOG_STYLE.ACTION1, 'onSelectContact2', contactId);

    dispatch(setSearchByContactId(contactId));
  };

  /**
   * Event fired when a typeAhead component has selected one Agent.
   * ** Used to search for tickets. **
   *    Save as search by Agent data in redux.
   *
   * @param _agents
   */
  const onSelectAgent = async (_agents: Agent[]) => {
    // TODO: Finish this.
    console.log(...LOG_STYLE.ACTION1, 'onSelectAgent', _agents);
  };

  /**
   * Handles the button search event.
   * ** Used to search for tickets. **
   *
   *    On a unique search like 'ByTicketId' then navigates to view the ticket.
   *    On non-unique search results show/display table.
   */
  const handleSearch = async () => {
    console.debug(...LOG_STYLE.ACTION1, 'handleSearch');

    if (searchType == SEARCH_TYPE.BY_TICKET_ID) {
      if (searchByTicketId) {
        // Set show mode so we view details.
        dispatch(setShowTicket(SHOW_TICKET.DETAIL));
        const ticket = await TicketService.shared.getTicket(organization, searchByTicketId);
        dispatch(setTicket(ticket));
        dispatch(pushBreadCrumb('Search/Ticket'));
      }
    } else {
      dispatch(setHasData(true));
    }
  };

  useEffect(() => {
    console.debug(...LOG_STYLE.EFFECT1, 'Search');

    // Clear Redux data when a search page loads.
    dispatch(clearTrackItApp());
    dispatch(clearContactHistory());
    dispatch(clearContact());
  }, []);

  return (
    <>
      <Section name={'Search'}>
        <InputsGrid>
          <Dropdown id={'ddlSearchBy'} label={'Search Type'} onChange={onSearchSelect} value={{ value: searchType, label: searchType }} options={searchTypeOptions} />
          <div className={'col-span-3'}>
            {searchType == SEARCH_TYPE.BY_TICKET_AGENT && <AgentSearch onSelect={onSelectAgent} />}
            {searchType == SEARCH_TYPE.BY_TICKET_BRANCH && <BranchSearch onSelect={onSelectBranch} />}
            {searchType == SEARCH_TYPE.BY_TICKET_COMPANY && <div>BY_TICKET_COMPANY</div>}

            {searchType == SEARCH_TYPE.BY_TICKET_CUSTOMER && <CustomerSearch onSearchContact={onSearchContact} />}

            {searchType == SEARCH_TYPE.BY_TICKET_EMPLOYEE && <EmployeeSearch onSelectEmployee={onSearchContact} />}
            {searchType == SEARCH_TYPE.BY_WORKFLOW_CASE && <TicketSearch />}
            {searchType == SEARCH_TYPE.BY_TICKET_ID && <TicketSearch />}

            {searchType == SEARCH_TYPE.MY_OPEN_ISSUES && <div>Should just setup an agent search with a date range.</div>}
            {searchType == SEARCH_TYPE.MY_TICKETS && <div>Should just setup an agent search with a date range.</div>}
          </div>
          {showFilterRow && (
            <SearchFilterRow
              showFilter={showFilterButton}
              onReset={function (): void {
                // TODO: finish this.
                throw new Error('Function not implemented.');
              }}
              handleSearch={handleSearch}
            />
          )}
        </InputsGrid>
      </Section>
      {ticketSearchData.hasSearchSubmitted && (
        <Section name={'TicketSearch'}>
          <TicketSearchList />
        </Section>
      )}
    </>
  );
}
