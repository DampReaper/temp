import * as React from 'react';

import { Avatar, Drawer } from 'antd';
import Dropdown, { dropdownOption } from 'components/Reusable/Dropdown';
import { clearAgent, setAgentLogon, setNewOrganization } from 'reduxStore/slices/agentSlice';
import { useAppDispatch, useAppSelector } from 'reduxStore/hooks';

import Button from 'design/FormElements/Button';
import Input from 'design/FormElements/Input';
import { LOG_STYLE } from 'utils';
import Section from 'components/TrackItReusable/Section/Section';
import { TicketTypeDto } from 'services';
import { TicketTypeService } from 'services/TicketTypeService';
import testingAgents from './testingAgents.json';

// import useLocalStorageState from 'use-local-storage-state'

//import React, { useEffect, useState } from 'react';











export function Logon() {
  console.debug(...LOG_STYLE.RENDER1, 'Logon');
  const dispatch = useAppDispatch();

  const organizationOptions = useAppSelector((state) => state.agent.organizationOptions);
  const agentEmployeeNum = useAppSelector((state) => state.agent.agentOwner.id);
  const organization = useAppSelector((state) => state.agent.organization);
  const entitlements = useAppSelector((state) => state.agent.entitlements);
  const hasData = useAppSelector((state) => state.agent.hasData);
  const agent = useAppSelector((state) => state.agent);

  /*
   * Use Okta :
   *     Set eNumber
   *
   * Use Entitlements :
   *     Set current organizationId
   *     Set available organizations
   *     Set available Contact Search Types.
   *
   *
   **/

  const currentAgent = { value: agent, label: agent.agentOwner.id + '-' + agent.agentOwner.lastName + ',' + agent.agentOwner.firstName };
  const currentOrganization = { value: organization, label: organization };
  const [visible, setVisible] = React.useState(false);

  //const [ticketTypes, setTicketTypes] = useLocalStorageState('ticketTypes', { defaultValue: null }) as TicketTypeDto;


  const agentOptions: any[] = [];
  testingAgents.forEach((elm) => {
    const newItem = { value: elm, label: elm.id + '-' + elm.lastName + ',' + elm.firstName };
    agentOptions.push(newItem);
  });

  const showDrawer = () => {
    setVisible(true);
  };

  const onClose = () => {
    setVisible(false);
  };

  const changeOrg = async (e) => {
    console.log(...LOG_STYLE.ACTION1, 'changeOrg' + e.value);

    const ticketTypeOptions: TicketTypeDto[] = await buildTicketType(e.value, entitlements);
    dispatch(setNewOrganization({ organization: e.value, ticketTypeOptions: ticketTypeOptions }));
  };

  const changeAgent = (e) => {
    console.log(...LOG_STYLE.ACTION1, 'changeAgent' + e.value);
    buildAgentLogon(e.value);
  };

  const getOrganizationFromEntitlements = (entitlementList: any[]) => {
    console.debug(...LOG_STYLE.DEBUG1, 'getOrganizationFromEntitlements');

    const organizations: string[] = [];
    if (entitlementList.indexOf('RS_ORG') != -1) {
      organizations.push('RS');
    }
    if (entitlementList.indexOf('C2C_ORG') != -1) {
      organizations.push('C2C');
    }
    return organizations;
  };

  const buildOptions = (optionList: string[]) => {
    const options: any[] = [];
    optionList.forEach((elm: string) => {
      const newItem = { value: elm, label: elm };
      options.push(newItem);
    });
    return options;
  };

  const buildTicketType = async (organizationName: string, entitlementList: string[]) => {
   
    console.log('buildTicketType', agent);
    console.log('Looking in local Storage...');
    const ticketTypeData = localStorage.getItem("ticketTypes"); 
    const ticketTypes = (ticketTypeData==null)?JSON.parse("{\"lastModifiedDate\":\"None\"}"):JSON.parse(ticketTypeData);
    if (ticketTypes.lastModifiedDate=="None") {
      console.log('Nothing found in LocalStorage');
    }else {
      console.log('LocalStorage has this version:'+ ticketTypes.lastModifiedDate);
    }
    
    const lastModifiedDate = ticketTypes.lastModifiedDate;
    console.log('Checking version against database...');
    const ticketTypeOptionRoot: TicketTypeDto = await TicketTypeService.shared.ticketTypeTree(organizationName, entitlementList, lastModifiedDate);

    if (ticketTypeOptionRoot.lastModifiedDate==lastModifiedDate) {
      console.log('Local version is current.');
      return ticketTypes.children;
    }else {
      console.log('Database has newer version :'+ ticketTypeOptionRoot.lastModifiedDate);
      console.log('Storing new version in LocalStorage');
      localStorage.setItem("ticketTypes", JSON.stringify(ticketTypeOptionRoot));
      return ticketTypeOptionRoot.children;
    }
 
  };

  const buildAgentLogon = async (newAgent: { id: any; firstName: any; lastName: any; organization: any; entitlements: any }) => {
    // Build Payload of Available TicketTypes + data for agent based on entitlements.
    console.log(...LOG_STYLE.DEBUG1, 'buildAgentLogon');
    dispatch(clearAgent());

    const ticketTypeOptions: TicketTypeDto[] = await buildTicketType(newAgent.organization, newAgent.entitlements);
    const organizations = getOrganizationFromEntitlements(newAgent.entitlements);

    const agentLogon = {
      id: newAgent.id,
      firstName: newAgent.firstName,
      lastName: newAgent.lastName,
      organizationOptions: organizations,
      ticketTypeOptions: ticketTypeOptions,
      organization: organizations[0],
      entitlements: newAgent.entitlements
    };

    dispatch(setAgentLogon(agentLogon));
  };

  React.useEffect(() => {
    console.debug(...LOG_STYLE.EFFECT1, 'Agent');
    /**
     * Gets all relevant agent data and stores in redux.
     */
    console.debug(testingAgents[0]);
    buildAgentLogon(testingAgents[0]);
  }, []);

  console.log('render' + agentEmployeeNum);
  return (
    <>
      <div onClick={showDrawer} style={{ display: 'flex', justifyContent: 'flex-end' }}>
        <Avatar style={{ backgroundColor: '#87d068' }}> {agentEmployeeNum}</Avatar>
      </div>

      <Drawer title='' closable={false} placement='top' onClose={onClose} visible={visible}>
        (FOR TESTING)
        {organization && (
          <>
            <Section>
              <div>
                {hasData && <Dropdown id={'ddlAgent'} label={'Agent'} onChange={changeAgent} value={currentAgent} options={agentOptions} />}

                <div>Entitlements: {entitlements.join(',')}</div>
                <div>Organization: {currentAgent.value.organizationOptions.join(',')}</div>
              </div>
              {hasData && <Dropdown id={'ddlOrganization'} label={'Organization'} onChange={changeOrg} value={currentOrganization} options={buildOptions(organizationOptions)} />}

              <div>
                <Button id={'btnIVRCall'} handleClick={function (event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void {
                  throw new Error('Function not implemented.');
                } } text={'IVR Call'} ></Button>
                <Input id={'txtEnumber'} label={'eNumber'} onChange={function (event: React.ChangeEvent<Element>): void {
                  throw new Error('Function not implemented.');
                } } value={'Z001196'}></Input>
              </div>
            </Section>
          </>
        )}
      </Drawer>
    </>
  );
}
