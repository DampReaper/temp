import 'react-datepicker/dist/react-datepicker.css';

import { useAppDispatch, useAppSelector } from 'reduxStore/hooks';

import Input from 'components/Reusable/Input';
import { LOG_STYLE } from 'utils';
import React from 'react';
import { setSearchByTicketId } from 'reduxStore/slices/ticketSearchSlice';

export function TicketSearch() {
  console.debug(...LOG_STYLE.RENDER1, 'TicketSearch');

  const dispatch = useAppDispatch();

  const searchByTicketId = useAppSelector((state) => state.ticketSearch.searchCriteria.searchByTicketId);

  const onChange = (e: any) => {
    console.log(e !== null && e.target.value ? e.target.value : undefined);
    dispatch(setSearchByTicketId(e !== null && e.target.value ? e.target.value : undefined));
  };

  return (
    <>
      <Input id={'txtTicket'} label={'Ticket#'} onChange={onChange} value={searchByTicketId || ''} />
    </>
  );
}
