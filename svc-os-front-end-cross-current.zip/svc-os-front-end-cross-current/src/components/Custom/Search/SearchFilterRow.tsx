import { LOG_STYLE, createOption } from 'utils';
import React, { useState } from 'react';
import { STATUS, WORKFLOW_STATUS } from 'definitions/enumerations';
import { clearTicketSearch, setSearchByEndDate, setSearchByStartDate, setSearchByStatus, setSearchByWorkflowStatus } from 'reduxStore/slices/ticketSearchSlice';
import { useAppDispatch, useAppSelector } from 'reduxStore/hooks';

import Button from 'components/Reusable/Button';
import ButtonsGrid from 'components/Reusable/ButtonsGrid';
import Datepicker from 'components/Reusable/Datepicker';
import Dropdown from 'components/Reusable/Dropdown';
import styles from './search.module.scss';

export function SearchFilterRow(props: { showFilter: boolean; onReset: () => void; handleSearch: () => void }) {
  console.debug(...LOG_STYLE.RENDER1, 'SearchFilterRow');

  const dispatch = useAppDispatch();

  const OPTION_ALL = { value: '', label: 'All' };
  const ticketStatusOptions = [OPTION_ALL, { value: STATUS.OPEN, label: STATUS.OPEN }, { value: STATUS.CLOSED, label: STATUS.CLOSED }];
  const workflowStatusOptions = [OPTION_ALL, { value: WORKFLOW_STATUS.OPEN, label: WORKFLOW_STATUS.OPEN }, { value: WORKFLOW_STATUS.CLOSED, label: WORKFLOW_STATUS.CLOSED }];

  const searchByEndDate = useAppSelector((state) => state.ticketSearch.searchCriteria.searchByEndDate);
  const searchByStartDate = useAppSelector((state) => state.ticketSearch.searchCriteria.searchByStartDate);
  const searchByStatus = useAppSelector((state) => state.ticketSearch.searchCriteria.searchByStatus);
  const searchByWorkflowStatus = useAppSelector((state) => state.ticketSearch.searchCriteria.searchByWorkflowStatus);

  const [toggleFilter, setToggleFilter] = useState(false);

  const handleStartDateChange = (e: Date) => {
    console.debug(...LOG_STYLE.ACTION1, 'handleStartDateChange');
    dispatch(setSearchByStartDate(e ? e.toLocaleDateString() : ''));
  };

  const handleEndDateChange = (e: Date) => {
    console.debug(...LOG_STYLE.ACTION1, 'handleEndDateChange');
    dispatch(setSearchByEndDate(e ? e.toLocaleDateString() : ''));
  };

  const handleStatusChange = (e: string | undefined) => {
    console.debug(...LOG_STYLE.ACTION1, 'handleEndDateChange');
    dispatch(setSearchByStatus(e));
  };

  const handleWorkflowStatusChange = (e: string | undefined) => {
    console.debug(...LOG_STYLE.ACTION1, 'handleWorkflowStatusChange');
    dispatch(setSearchByWorkflowStatus(e));
  };

  const handleReset = () => {
    console.debug(...LOG_STYLE.ACTION1, 'handleSearch');
    dispatch(clearTicketSearch());
    props.onReset();
  };

  const handleToggleFilter = () => {
    setToggleFilter(!toggleFilter);
  };

  return (
    <>
      <div className={'row-start-12 col-span-4'}>
        <div className={'grid grid-cols-1 gap-y-3 gap-x-12 sm:w-full md:grid-cols-4 lg:grid-cols-8'}>
          {toggleFilter && (
            <>
              <div className={'col-span-2'}>
                <div className={`${styles.findDateWrapper}`}>
                  <Datepicker id='startDt' label='Start Date' value={searchByStartDate ? searchByStartDate : ''} minDate={new Date(0)} maxDate={new Date()} onChange={handleStartDateChange} />
                  <Datepicker id='endDt' label='End Date' value={searchByEndDate ? searchByEndDate : ''} minDate={new Date(0)} maxDate={new Date()} onChange={handleEndDateChange} />
                </div>
              </div>
              <div className={'col-span-2'}>
                <div className={`${styles.findDateWrapper}`}>
                  <Dropdown
                    id={'ddlSearchByStatus'}
                    label={'Status'}
                    onChange={(e) => {
                      handleStatusChange(e?.value);
                    }}
                    value={searchByStatus ? createOption(searchByStatus) : OPTION_ALL}
                    options={ticketStatusOptions}
                  />
                  <Dropdown
                    id={'ddlSearchByWorkflowStatus'}
                    label={'WorkflowStatus'}
                    onChange={(e) => {
                      handleWorkflowStatusChange(e?.value);
                    }}
                    value={searchByWorkflowStatus ? createOption(searchByWorkflowStatus) : OPTION_ALL}
                    options={workflowStatusOptions}
                  />
                </div>
              </div>
            </>
          )}

          <ButtonsGrid additionalStyles={'lg:col-start-5 lg:col-span-4 sm:col-start-1'}>
            <Button id='search' text='Search' type='primary' handleClick={() => props.handleSearch()} icon='search' />
            <Button id='reset' text='Reset' type='primary' handleClick={() => handleReset()} icon='undo' />
            {props.showFilter && <Button id='filters' text='Filters' type='secondary' handleClick={handleToggleFilter} icon={!toggleFilter ? 'chevron-down' : 'chevron-up'} />}
          </ButtonsGrid>
        </div>
      </div>
    </>
  );
}
