import 'styles/tableStyles.scss';

import { Customer, CustomerService } from 'services';
import Dropdown, { dropdownOption } from 'components/Reusable/Dropdown';
import { LOG_STYLE, validateInputs } from 'utils';
import React, { ChangeEvent, useEffect, useState } from 'react';
import { areas, customerSearchColumns, defaultPaginationOptions, errors } from 'definitions';

import BootstrapTable from 'react-bootstrap-table-next';
import Button from 'components/Reusable/Button';
import ButtonsGrid from 'components/Reusable/ButtonsGrid';
import CustomerToken from 'components/Custom/Token/CustomerToken';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import Input from 'components/Reusable/Input';
import InputsGrid from 'components/Reusable/InputsGrid';
import { Label } from 'components/Reusable/Label';
import { Modal } from 'antd';
import paginationFactory from 'react-bootstrap-table2-paginator';
import { setSelectedContact } from 'reduxStore/slices/ticketSearchSlice';
import styles from './search.module.scss';
import { useAppSelector } from 'reduxStore/hooks';
import { useDispatch } from 'react-redux';
import { usePromiseTracker } from 'react-promise-tracker';

// TODO: REDO THIS IS JUST SAMPLE.

/**
 * Customer Search
 */





export enum CUSTOMER_SEARCH_BY {
  NAME = 'Name',
  TAX_ID = 'Tax ID Number'
}

const createOption = (label: string) => {
  return { value: label, label: label };
};

const searchByOptions = [createOption(CUSTOMER_SEARCH_BY.NAME), createOption(CUSTOMER_SEARCH_BY.TAX_ID)];

function CustomerSearch(props: { onSelectCustomer?: (customer: Customer) => void; onSearchContact?: (id: string) => void }) {
  console.debug(...LOG_STYLE.RENDER1, 'CustomerSearch');

  const selectedContact = useAppSelector((state) => state.ticketSearch.selectedContact) as Customer | undefined;

  const [searchBy, setSearchBy] = useState(searchByOptions[0].value);
  const [searchInput, setSearchInput] = useState('');
  const [searchInput2, setSearchInput2] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [searchInputError, setSearchInputError] = useState('');
  const [searchInput2Error, setSearchInput2Error] = useState('');
  const [promiseStatus, setPromiseStatus] = useState(0);
  const [searchResults, setSearchResults] = useState<any[]>();
  const [visible, setVisible] = useState(false);

  const dispatch = useDispatch();

  useEffect(() => {
    return () => {
      // dispatch(resetCustomer());
    };
  }, []);

  const { promiseInProgress } = usePromiseTracker({
    area: areas.searchCustomer
  });

  const handleSearchByChange = (value: any) => {
    isSubmitted && setIsSubmitted(!isSubmitted);
    setSearchInput('');
    setSearchInput2('');
    setSearchInputError('');
    setSearchInput2Error('');
    value !== null ? setSearchBy(value.label) : setSearchBy('');
  };

  const handleSearchInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    isSubmitted && setIsSubmitted(!isSubmitted);
    setSearchInputError('');

    if (searchBy === CUSTOMER_SEARCH_BY.NAME) {
      e.target.value.length > 40 ? setSearchInputError('Maximum limit 40 characters') : setSearchInput(e.target.value);
    } else if (searchBy === CUSTOMER_SEARCH_BY.TAX_ID) {
      e.target.value.length < 9 && setSearchInputError('Minimum 9 digits');
      const taxIdError = validateInputs('taxId', e.target.value);
      taxIdError ? setSearchInputError(taxIdError) : setSearchInput(e.target.value);
    } else {
      const digitRegex = /^[\d]{0,20}$/;
      const digitError = e.target.value.length > 20 ? 'Maximum length 20 digits' : digitRegex.test(e.target.value) ? '' : 'Can only be digits';

      digitError ? setSearchInputError(digitError) : setSearchInput(e.target.value);
    }
  };

  const handleSearchInput2Change = (e: ChangeEvent<HTMLInputElement>) => {
    isSubmitted && setIsSubmitted(!isSubmitted);
    setSearchInput2Error('');

    if (searchBy === CUSTOMER_SEARCH_BY.NAME) {
      e.target.value.length > 40 ? setSearchInput2Error('Maximum limit 40 characters') : setSearchInput2(e.target.value);
    }
    setSearchInput2(e.target.value);
  };

  const fetchCustomers = () => {
    console.log('fetchCustomers');
    if (searchBy === CUSTOMER_SEARCH_BY.NAME) {
      console.log('customerSearchByName', searchInput, searchInput2);
      CustomerService.shared
        .searchCustomerByName(searchInput, searchInput2)
        .then((res: any) => {
          console.log('res.data', res.data);
          console.log('res.status', res.status);
          setSearchResults(res.data);
          setPromiseStatus(res.status);
        })
        .catch((e: any) => setPromiseStatus(e.response.status));
    } else if (searchBy === CUSTOMER_SEARCH_BY.TAX_ID) {
      CustomerService.shared
        .searchCustomerByTaxId(searchInput)
        .then((res: any) => {
          setSearchResults(res.data);
          setPromiseStatus(res.status);
        })
        .catch((e: any) => (e.response ? setPromiseStatus(e.response.status) : setPromiseStatus(errors.SERVER_ERROR)));
    } else {
      CustomerService.shared
        .searchCustomerByAccount(searchBy, searchInput)
        .then((res: any) => {
          setSearchResults(res.data);
          setPromiseStatus(res.status);
        })
        .catch((e: any) => (e.response ? setPromiseStatus(e.response.status) : setPromiseStatus(errors.SERVER_ERROR)));
    }
  };

  const handleSearch = () => {
    setIsSubmitted(true);
    fetchCustomers();
  };

  const handleReset = () => {
    setIsSubmitted(false);
    setSearchBy(searchByOptions[0].label);
    setSearchInput('');
    setSearchInput2('');
    setSearchInputError('');
    setSearchInput2Error('');
    setSearchResults([{}]);
  };

  const handleTaxIdBlur = () => {
    searchBy === CUSTOMER_SEARCH_BY.TAX_ID && searchInput.length < 9 && setSearchInputError('Minimum 9 digits');
  };

  const shouldButtonBeDisabled = () => {
    if (searchBy === CUSTOMER_SEARCH_BY.NAME) {
      return searchInputError.length > 0 || searchInput2Error.length > 0 || !searchInput || !searchInput2;
    } else if (searchBy === CUSTOMER_SEARCH_BY.TAX_ID) {
      return searchInput.length < 9;
    }
    return searchInput.length === 0;
  };

  const showModal = () => {
    setVisible(true);
  };

  const handleOk = () => {
    // Complete
  };

  const handleCancel = () => {
    setVisible(false);
  };

  /**
   * Event handler for when a row is clicked.
   *
   */
  const rowEvents = {
    onClick: (_e: any, row: Customer, _rowIndex: number) => {
      console.debug(...LOG_STYLE.ACTION1, 'CustomerSearch.rowEvent.OnClick');

      if (props.onSelectCustomer) {
        props.onSelectCustomer(row);
      } else {
        setVisible(false);
        dispatch(setSelectedContact(row));
        if (props.onSearchContact) {
          props.onSearchContact(row.id);
        }
      }
    }
  };
  const removeCustomer = (e) => {
    e.preventDefault();
    e.stopPropagation();
    dispatch(setSelectedContact(undefined));
  };
  return (
    <>
      <Label label='Customer'>
        <div className={styles.myBox} onClick={showModal}>
          {selectedContact ? <CustomerToken customer={selectedContact} /> : <span>&nbsp;</span>}

          <FontAwesomeIcon onClick={showModal} className='fa-align-right fa-pull-right' icon={visible ? 'chevron-up' : 'chevron-down'} />
          <FontAwesomeIcon onClick={removeCustomer} className='fa-align-right fa-pull-right' icon={'close'} />
        </div>
      </Label>
      {visible && (
        <Modal
          transitionName=''
          maskTransitionName=''
          visible={visible}
          centered
          width={1200}
          title='Find Customer'
          onOk={handleOk}
          onCancel={handleCancel}
          footer={[<Button key='back' text='Close' handleClick={handleCancel} id={''} type={'primary'} />]}
        >
          <div>
            <InputsGrid>
              <Dropdown
                id='searchSelect'
                label='Search By'
                onChange={handleSearchByChange}
                options={searchByOptions}
                value={searchByOptions.find((f: dropdownOption) => f.label === searchBy) as dropdownOption}
                placeholder={`Search for Customer`}
              />

              <Input
                id='searchInput'
                label={searchBy ? (searchBy === CUSTOMER_SEARCH_BY.NAME ? 'First Name' : searchBy) : 'input'}
                onChange={handleSearchInputChange}
                value={searchInput}
                error={searchInputError}
                errorHandler={handleTaxIdBlur}
              />

              {searchBy === CUSTOMER_SEARCH_BY.NAME && (
                <Input
                  id='searchInput2'
                  label={searchBy ? (searchBy === CUSTOMER_SEARCH_BY.NAME ? 'Last Name' : searchBy) : 'input'}
                  onChange={handleSearchInput2Change}
                  value={searchInput2}
                  error={searchInput2Error}
                />
              )}

              <ButtonsGrid>
                <Button id='searchButton' type='primary' handleClick={handleSearch} disabled={shouldButtonBeDisabled()} text='Search' icon='search' />

                <Button id='Reset' handleClick={handleReset} type='secondary' text='Reset' icon='undo' />
              </ButtonsGrid>
            </InputsGrid>
            {isSubmitted && searchResults && (
              <BootstrapTable
                keyField='id'
                data={searchResults.map((d: any, index: any) => {
                  return { ...d, id: index };
                })}
                columns={customerSearchColumns}
                pagination={paginationFactory(defaultPaginationOptions)}
                classes={'default__table'}
                bootstrap4={true}
                striped
                hover
                condensed
                table-responsive
                rowEvents={rowEvents}
              />
            )}
          </div>
        </Modal>
      )}
    </>
  );
}

export default CustomerSearch;
