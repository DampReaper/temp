import Button from 'components/Reusable/Button';
import { CONTACT_TYPE } from 'definitions';
import { LOG_STYLE } from 'utils';
import React from 'react';
import { useAppDispatch } from 'reduxStore/hooks';

export function CompanySearch(props) {
  console.debug(...LOG_STYLE.RENDER1, 'CompanySearch');

  const fakeIt = () => {
    console.debug(...LOG_STYLE.ACTION1, 'FakeIt');

    //TODO Fill In these Values.
    props.onSelect('V0000001', CONTACT_TYPE.COMPANY);
  };
 

  return (
    <>
      <Button text='Search' handleClick={fakeIt} id={'Search'} type={'primary'} />
    </>
  );
}
