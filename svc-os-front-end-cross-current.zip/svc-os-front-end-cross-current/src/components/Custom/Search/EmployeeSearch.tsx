import 'react-bootstrap-typeahead/css/Typeahead.css';

import React, { useCallback, useState } from 'react';

import { AsyncTypeahead } from 'react-bootstrap-typeahead';
import { EmployeeService } from 'services';
import styles from './search.module.scss';

const CACHE = {};
const PER_PAGE = 50;

interface ISearchTypeAheadProps {
  onSelectEmployee: (id: string) => void;
  additionalStyles?: string;
}

async function makeAndHandleRequest(query, page = 0) {
  return EmployeeService.shared.search(query, page);
}

export function EmployeeSearch(props: ISearchTypeAheadProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [options, setOptions] = useState<any[]>([]);
  const [query, setQuery] = useState('');

  const handleInputChange = (q) => {
    setQuery(q);
  };

  const handlePagination = (_e: any, shownResults: number) => {
    const cachedQuery = CACHE[query];

    // Don't make another request if:
    // - the cached results exceed the shown results
    // - we've already fetched all possible results
    if (cachedQuery.options.length > shownResults || cachedQuery.options.length === cachedQuery.total_count) {
      return;
    }

    setIsLoading(true);

    const page = cachedQuery.page + 1;

    makeAndHandleRequest(query, page).then((resp) => {
      const options = cachedQuery.options.concat(resp.options);
      CACHE[query] = { ...cachedQuery, options, page };

      setIsLoading(false);
      setOptions(options);
    });
  };

  // `handleInputChange` updates state and triggers a re-render, so
  // use `useCallback` to prevent the debounced search handler from
  // being cancelled.
  const handleSearch = useCallback((q) => {
    if (CACHE[q]) {
      setOptions(CACHE[q].options);
      return;
    }

    setIsLoading(true);
    makeAndHandleRequest(q).then((resp) => {
      CACHE[q] = { ...resp, page: 1 };

      setIsLoading(false);
      setOptions(resp.options);
    });
  }, []);

  return (
    <div className={`  ${styles.interactionInputWrapper} ${props.additionalStyles}`}>
      <label htmlFor={'async-pagination-contact'} className={styles.interactionInputLabel}>
        Employee
      </label>
      <AsyncTypeahead
        id='async-pagination-example'
        isLoading={isLoading}
        labelKey='name'
        maxResults={PER_PAGE - 1}
        minLength={2}
        onInputChange={handleInputChange}
        onPaginate={handlePagination}
        onSearch={handleSearch}
        options={options}
        paginate
        filterBy={() => true}
        placeholder='Employee search criteria...'
        onChange={(selected: { id: string }[]) => {
          console.log(selected);
          // We only allow single select, so the selected item will be in array pos zero.
          if (selected.length === 1) {
            const id: string = selected[0].id;
            props.onSelectEmployee(id);
          }
        }}
        renderMenuItemChildren={(option: { id: React.Key | null | undefined; name: boolean | React.ReactChild | React.ReactFragment | React.ReactPortal | null | undefined }) => (
          <div key={option.id}>
            <span>{option.name}</span>
          </div>
        )}
        useCache={false}
      />
    </div>
  );
}
