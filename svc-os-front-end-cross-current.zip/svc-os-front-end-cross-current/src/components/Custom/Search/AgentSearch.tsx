import 'react-bootstrap-typeahead/css/Typeahead.css';

import { Agent, TicketService } from 'services';
import { AsyncTypeahead, Token, TypeaheadInputMulti } from 'react-bootstrap-typeahead';
import React, { useCallback, useState } from 'react';

import EmployeeToken from 'components/Custom/Token/EmployeeToken';
import styles from './search.module.scss';

const CACHE = {};
const PER_PAGE = 50;

interface ISearchTypeAheadProps {
  onSelect: (employeeId: Agent[]) => void;
  additionalStyles?: string;
}

async function makeAndHandleRequest(query: string, page = 0) {
  return TicketService.shared.searchAgent(query, page);
}

export function AgentSearch(props: ISearchTypeAheadProps) {
  const [selected, setSelected] = useState<Agent[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [options, setOptions] = useState<Agent[]>([]);
  const [query, setQuery] = useState('');

  const handleInputChange = (q: React.SetStateAction<string>) => {
    setQuery(q);
  };

  const handlePagination = (_e: any, shownResults: number) => {
    const cachedQuery = CACHE[query];

    // Don't make another request if:
    // - the cached results exceed the shown results
    // - we've already fetched all possible results
    if (cachedQuery.options.length > shownResults || cachedQuery.options.length === cachedQuery.total_count) {
      return;
    }

    setIsLoading(true);

    const page = cachedQuery.page + 1;

    makeAndHandleRequest(query, page).then((resp) => {
      const responseOptions = cachedQuery.options.concat(resp.options);
      CACHE[query] = { ...cachedQuery, responseOptions, page };

      setIsLoading(false);
      setOptions(responseOptions);
    });
  };

  // `handleInputChange` updates state and triggers a re-render, so
  // use `useCallback` to prevent the debounced search handler from
  // being cancelled.
  const handleSearch = useCallback((q: string) => {
    if (CACHE[q]) {
      setOptions(CACHE[q].options);
      return;
    }

    setIsLoading(true);
    makeAndHandleRequest(q).then((resp) => {
      CACHE[q] = { ...resp, page: 1 };
      setIsLoading(false);
      setOptions(resp.options);
    });
  }, []);

  return (
    <div className={` ${styles.interactionInputWrapper}  ${props.additionalStyles}`}>
      <label htmlFor={'async-pagination-agent'} className={styles.interactionInputLabel}>
        Agent
      </label>
      <AsyncTypeahead
        id='async-pagination-agent'
        isLoading={isLoading}
        labelKey='id'
        maxResults={PER_PAGE - 1}
        minLength={2}
        onInputChange={handleInputChange}
        onPaginate={handlePagination}
        onSearch={handleSearch}
        options={options}
        paginate
        filterBy={(filterOption: { id: string }, _props: any) => {
          // Make sure that the offered options do no contain previously selected options
          return !selected.some((s) => s.id === filterOption.id);
        }}
        placeholder='Agent search criteria...'
        onChange={(e: Agent[]) => {
          console.log(e);
          setSelected(e);
          props.onSelect(e);
        }}
        renderMenuItemChildren={(option: Agent) => <EmployeeToken employee={option} />}
        useCache={false}
        multiple
        selected={selected}
        renderInput={(inputProps: JSX.IntrinsicAttributes, tokenProps: { onRemove: any }) => (
          <TypeaheadInputMulti {...inputProps} selected={selected}>
            {selected.map((option: any, idx) => (
              <Token index={idx} key={option.id} onRemove={tokenProps.onRemove} option={option}>
                <EmployeeToken employee={option} />
              </Token>
            ))}
          </TypeaheadInputMulti>
        )}
      ></AsyncTypeahead>
    </div>
  );
}
