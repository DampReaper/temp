import { SHOW_TICKET, TICKET_STATUS_TYPE } from 'definitions/index';

import Button from 'components/Reusable/Button';
import { LOG_STYLE } from 'utils';
import React from 'react';
import { Ticket } from 'services';
import { nanoid } from 'nanoid';
import { setShowTicket } from 'reduxStore/slices/trackItAppSlice';
import { setTicket } from 'reduxStore/slices/contactSlice';
import { useAppSelector } from 'reduxStore/hooks';
import { useDispatch } from 'react-redux';

/**
 * Render ContactFooter.
 * @returns ContactFooter Component.
 */
export function ContactFooter() {
  console.debug(...LOG_STYLE.RENDER1, 'ContactFooter');

  const agent = useAppSelector((state) => state.agent);
  const contact = useAppSelector((state) => state.contact);

  const dispatch = useDispatch();

  const goBackToSearch = () => {
    console.log(...LOG_STYLE.ACTION1, 'Button:GoBackToSearch');
    //navigate('/Search');
  };

  const createNewTicket = () => {
    try {
      // Create new Ticket and add to contact.ticket
      const ticket: Ticket = {
        ticketId: nanoid(9),
        organization: agent.organization,
        contact: contact.currentContact,
        ticketType: {} as any,
        questionsAnswers: {},
        workflow:undefined,
        interaction :undefined,
        ownerAgent: agent.agentOwner,
        status: TICKET_STATUS_TYPE.OPEN
      };
      dispatch(setTicket(ticket));
      dispatch(setShowTicket(SHOW_TICKET.DETAIL));
      console.log(...LOG_STYLE.ACTION1, 'Button:createNewTicket');
    } catch {
      console.debug(LOG_STYLE.ERROR1, 'Error submitting the form');
    }
  };

  return (
    <>
      <div className='footer__controls mt-14 flex w-full flex-row items-center justify-center self-end lg:w-1/3 lg:justify-end'>
        {/* <Button handleClick={goBackToSearch} id={'btnBack'} text={'Back'} type={''} /> */}
        <Button handleClick={createNewTicket} id={'btnNew'} text={'Create New Ticket'} type={'primary'} />
      </div>
    </>
  );
}
