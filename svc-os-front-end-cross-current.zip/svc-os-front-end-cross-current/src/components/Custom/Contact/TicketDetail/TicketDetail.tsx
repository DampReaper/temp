import { FlexContainer, FlexGroup, FlexLabel, FlexRow } from 'components/TrackItReusable';

import { DynamicQuestion } from 'components/Custom/DynamicQuestion/DynamicQuestion';
import { LOG_STYLE } from 'utils';
import Loading from 'components/Reusable/Loading';
import React from 'react';
import { SectionHeader } from 'components/TrackItReusable/SectionHeader/SectionHeader';
import SubSection from 'components/TrackItReusable/SubSection/SubSection';
import { Ticket } from 'services';
import { TicketStatusBar } from './components/TicketStatusBar';
import { WorkflowStatusBar } from './components/WorkflowStatusBar';
import { useAppSelector } from 'reduxStore/hooks';

/**
 * Renders TicketDetail
 * @returns TicketDetail Component.
 */
export function TicketDetail() {
  console.debug(...LOG_STYLE.RENDER1, 'TicketDetail');

  const isContactReady = useAppSelector((state) => state.contact.isReady);
  const ticket = useAppSelector((state) => state.contact.ticket) as Ticket
  
  return (
    <>
      {isContactReady ? (
        <>
          <div className={'grid gap-y-0 gap-x-3 sm:w-full md:grid-cols-2 lg:grid-cols-2'}>
            <div className={'col-start-1 row-start-1'}>
              <SectionHeader title='Ticket:D-34e31' />
              <div className={'grid gap-y-0 gap-x-0 sm:w-full md:grid-cols-2 lg:grid-cols-4'}>
                <FlexLabel label={'Ticket#'} value={ticket.ticketId} />
                <FlexLabel label={'Status'} value={ticket.status} />
                <FlexLabel label={'Closed'} value={''} />
                <FlexLabel label={'Closed By'} value={''} />
              </div>
            </div>
            <div>
              <SectionHeader title='Workflow' />
              <div className={'grid gap-y-0 gap-x-0 sm:w-full md:grid-cols-2 lg:grid-cols-4'}>
                <FlexLabel label={'Case#'} value={'141324'} />
                <FlexLabel label={'Status'} value={'Open'} />
                <FlexLabel label={'Closed'} value={''} />
                <FlexLabel label={'Closed By'} value={''} />
              </div>
            </div>
          </div>
          <DynamicQuestion />
        </>
      ) : (
        <Loading />
      )}
    </>
  );
}
