import { LOG_STYLE, formatDate } from 'utils';

import { Label } from 'components/Reusable/Label';
import React from 'react';
import { Workflow } from 'services';
import { useAppSelector } from 'reduxStore/hooks';

/**
 * Renders WorkflowStatusBar
 * @returns WorkflowStatusBar Component.
 */
export function WorkflowStatusBar(props) {
  console.debug(...LOG_STYLE.RENDER1, 'WorkflowStatusBar');

  const workflow = useAppSelector((state) => state.contact.ticket?.workflow) as Workflow;

  return (
    <>
      {workflow != null && workflow.externalId != null && workflow.externalId.length > 0 && (
        <div className={props.className}>
          <div className='d-flex gap-5'>
            <div className='labelData-xl '>
              <Label label='Case#' value={workflow.externalId} />
            </div>
            <div className='labelData-m'>
              <Label label='Status' value={workflow.status} />
            </div>
            <div className='labelData-xl '>
              <Label label='Closed' value={formatDate(workflow.lastModifiedDate || '')} />
            </div>
          </div>
        </div>
      )}
    </>
  );
}
