import { LOG_STYLE, formatDate } from 'utils';

import { Label } from 'components/Reusable/Label';
import React from 'react';
import { useAppSelector } from 'reduxStore/hooks';

/**
 * Renders TicketStatusBar
 * @returns TicketStatusBar Component.
 */
export function TicketStatusBar(props): JSX.Element {
  console.debug(...LOG_STYLE.RENDER1, 'TicketStatusBar');

  const status = useAppSelector((state) => state.contact.ticket?.status);
  const ticketId = useAppSelector((state) => state.contact.ticket?.ticketId);
  const lastModifiedDate = useAppSelector((state) => state.contact.ticket?.lastModifiedDate);
  const lastModifiedBy = useAppSelector((state) => state.contact.ticket?.lastModifiedBy);
  const closedDate = useAppSelector((state) => state.contact.ticket?.closedDate);

  return (
    <>
      {/* <div className='d-flex'> */}
      <div className={props.className}>
        <div className='d-flex gap-5'>
          <div className='labelData-xl'>
            <Label label='Ticket#' value={ticketId} />
          </div>
          <div className='labelData-m'>
            <Label label='Status' value={status} />
          </div>
          {/* <div className='labelData-xl ml-auto'>
            <Label label='Last Modified' value={Utility.formatDate(lastModifiedDate)} />
          </div> */}
          <div className='labelData-xl '>
            <Label label='Closed' value={formatDate(closedDate||"")} />
          </div>
          <div className='labelData-xl '>
            <Label label='By' value={lastModifiedBy} />
          </div>

        </div>
      </div>
    </>
  );
}
