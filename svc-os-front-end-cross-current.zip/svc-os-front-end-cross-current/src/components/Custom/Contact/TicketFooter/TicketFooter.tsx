import { useAppDispatch, useAppSelector } from 'reduxStore/hooks';

import Button from 'components/Reusable/Button';
import { LOG_STYLE } from 'utils';
import React from 'react';
import { SHOW_TICKET } from 'definitions/index';
import { Ticket } from 'services';
import { TicketService } from 'services';
import { setShowTicket } from 'reduxStore/slices/trackItAppSlice';

/**
 * Renders TicketFooter.
 * @param props
 * @returns TicketFooter Component.
 */
export function TicketFooter() {
  console.debug(...LOG_STYLE.RENDER1, 'TicketFooter');

  const dispatch = useAppDispatch();

  const workflowId = ''; //useAppSelector((state) => state.ticket.workflowId);
  const workflowExternalId = ''; //useAppSelector((state) => state.ticket.workflowExternalId);
  const workflowExternalStatusTxt = '1'; //useAppSelector((state) => state.ticket.workflowExternalStatusTxt);
  // const callerLastNm = useAppSelector((state) => state.caller.lastNm);
  // const callerFirstNm = useAppSelector((state) => state.caller.firstNm);
  const isClosed = false; //useSelector(selectIsClosed);
  // const callerBranch = useAppSelector((state) => state.caller.branch);
  const ticket = useAppSelector((state) => state.contact.ticket) as Ticket;
  const agentEmployeeNum = useAppSelector((state) => state.agent.agentOwner.id);

  const breadCrumb = useAppSelector((state) => state.trackItApp.breadCrumb);

  // Conditions for disabling the workflow button.
  const workflowHasBeenCalledInd: boolean = workflowExternalStatusTxt && workflowExternalStatusTxt.length > 0 ? true : false;
  const workflowExistsInd: boolean = workflowId && workflowId > 0 ? true : false;

  const disableWorkflowButtonInd = () => {
    if (isClosed) {
      return true;
    }
    if (workflowExistsInd) {
      if (!workflowExternalId) {
        if (!workflowHasBeenCalledInd) {
          return false;
        }
      }
    }
    return true;
  };

  const disableCloseButtonInd = () => {
    if (isClosed) {
      return true;
    }
    if (workflowExistsInd) {
      if (workflowHasBeenCalledInd || workflowExternalId) {
        return false;
      } else {
        return true;
      }
    } else {
      return false;
    }
  };

  const back = () => {
    console.log(...LOG_STYLE.ACTION1, 'Button:BACK');
    console.debug(...LOG_STYLE.DEBUG1, 'Clear TicketOnly');
    // dispatch(clearTicketOnly());

    // console.debug(...LOG_STYLE.DEBUG1, 'Set Ticket.CallerNames to Stored Caller.CallerNames', { callerLastNm: callerLastNm, callerFirstNm: callerFirstNm, callerNameAdded: false });
    // dispatch(setCallerNames({ callerLastNm: callerLastNm, callerFirstNm: callerFirstNm, callerNameAdded: false }));

    // dispatch(setAltBranch(callerBranch));
    // console.debug(...LOG_STYLE.DEBUG1, `Store Caller.Branch to match employee.altBranch.`, callerBranch);

    if (breadCrumb =='Search/Ticket'){
      //('/Search');
    }

    dispatch(setShowTicket(SHOW_TICKET.HISTORY));
  };

  const save = () => {
    console.log(...LOG_STYLE.ACTION1, 'Button:SAVE');
    console.log(`%cSave:%s`, LOG_STYLE.SAVE, '1) TicketFooter.save()');
    TicketService.shared.save(ticket);
  };

  /**
   *  AddDuplicateTicket.
   */
  const AddDuplicateTicket = async () => {
    console.log('AddDuplicateTicket');
    // const ticketId = (await TicketService.shared.generateNewTicketId());

    // const newTicket = {
    //   ticketId: ticketId,
    //   ownerAgentEmployeeNum: agentEmployeeNum,
    //   statusTypeId: TICKET_STATUS_TYPE.OPEN
    // };
    // console.debug(...LOG_STYLE.DEBUG1, `Generated a new ticket ${ticketId} for duplicate`, newTicket);

    // // dispatch(createAddDuplicateTicket(newTicket));
    // dispatch(setTicketFormReady(true));
  };

  const addTicket = () => {
    console.log(...LOG_STYLE.ACTION1, 'Button:ADD_TICKET');
    // dispatch(setFormReady(false));
    // dispatch(setTicketFormReady(false));
    AddDuplicateTicket();
  };

  const close = () => {
    console.log(...LOG_STYLE.ACTION1, 'Button:CLOSE');
    console.log(`%cClose:%s`, LOG_STYLE.SAVE, '1) TicketFooter.close()');
    // dispatch(setTicketBarAction(TicketBarAction.CLOSE));
  };

  const workflow = () => {
    console.log(...LOG_STYLE.ACTION1, 'Button:WORKFLOW');
    console.log(`%cWorkflow:%s`, LOG_STYLE.SAVE, '1) TicketFooter.workflow()');
    // dispatch(setTicketBarAction(TicketBarAction.WORKFLOW));
  };

  return (
    <div className='footer__controls mt-14 flex w-full flex-row items-center justify-center self-end lg:w-1/3 lg:justify-end'>
      <Button id={'btnBack'} handleClick={back} text={'Back'} type={''}  />
      <Button disabled={!isClosed} id={'btnAddTicket'} handleClick={save} text={'Create New Ticket'} type={'primary'}  />
      <Button disabled={disableCloseButtonInd()} id={'btnClose'} handleClick={save} text={'Save'} type={'primary'}  />
    </div>
  );
}
