import 'react-bootstrap-table-next/dist/react-bootstrap-table2.css';
import 'styles/tableStyles.scss';

import { ITicketSearchSearch, setTicketSearch } from 'reduxStore/slices/ticketSearchSlice';
import React, { useEffect } from 'react';
import { SHOW_TICKET, ticketSearchColumns } from 'definitions';
import { Ticket, TicketService } from 'services';
import { pushBreadCrumb, setShowTicket } from 'reduxStore/slices/trackItAppSlice';
import { useAppDispatch, useAppSelector } from 'reduxStore/hooks';

import { AxiosError } from 'axios';
import { LOG_STYLE } from 'utils';
import { RemoteTable } from 'components/TrackItReusable/RemoteTable/RemoteTable';
import SubSection from 'components/TrackItReusable/SubSection/SubSection';
import { setTicket } from 'reduxStore/slices/contactSlice';

/**
 * Renders a paged table component of Employee Contacts Ticket History.
 * @returns TicketSearch Component
 */
export function TicketSearchList() {
  console.debug(...LOG_STYLE.RENDER1, 'TicketSearch');

  const dispatch = useAppDispatch();
  const organization = useAppSelector((state) => state.agent.organization);
  const searchType = useAppSelector((state) => state.ticketSearch.searchType);
  const hasSearchSubmitted = useAppSelector((state) => state.ticketSearch.hasSearchSubmitted);

  const ticketSearch = useAppSelector((state) => state.ticketSearch);

  const data: Ticket[]|undefined = useAppSelector((state) => state.ticketSearch.data);
  const totalSize  = useAppSelector((state) => state.ticketSearch.totalSize) ;

  const pageIndex  = useAppSelector((state) => state.ticketSearch.searchCriteria.pageIndex) ;

  const pageSize  = useAppSelector((state) => state.ticketSearch.searchCriteria.pageSize) ;
  const searchCriteria: ITicketSearchSearch = useAppSelector((state) => state.ticketSearch.searchCriteria);
  const sorted = [
    {
      dataField: searchCriteria?.sortField ? searchCriteria?.sortField : 'ticketId',
      order: searchCriteria?.sortOrder ? searchCriteria?.sortOrder : 'desc'
    }
  ];

  /**
   * Handles row selection event for table.
   * - Gets fresh ticket data from TicketService.
   *   - Sets retrieved ticket in redux for viewing.
   * - Changes to Detail view.
   */
  const rowEvents = {
    onClick: async (_e: any, row: { ticketId: string }, _rowIndex: any) => {
      console.debug(...LOG_STYLE.ACTION1, 'Select:SELECT_TICKET');

      console.debug(...LOG_STYLE.DEBUG1, 'TicketSearch:Set ShowTicket:DETAIL');
      dispatch(setShowTicket(SHOW_TICKET.DETAIL));

      console.debug(...LOG_STYLE.DEBUG1, 'TicketSearch:Load Ticket from TicketService');
      const result = await TicketService.shared.getTicket(organization, row.ticketId);
      dispatch(setTicket(result));
      dispatch(pushBreadCrumb("Search/Ticket"));
   //   navigate('/ViewContactTicket');
    }
  };


  /**
   * Handles table events such as Paging, filtering, sorting, pageSize change.
   */
  const onTableChange = async (_type: any, newState: { page: number; sizePerPage: number; sortField: string; sortOrder: string }) => {
    console.debug(...LOG_STYLE.ACTION1, 'onTableChangeC');
    try {
      const sc = {
        ...searchCriteria,
        pageIndex: newState.page > 0 ? newState.page - 1 : 0, // Adjust page.
        pageSize: newState.sizePerPage,
        sortField: newState.sortField,
        sortOrder: newState.sortOrder
      };

      // Retrieved new page of data from service.
      const resp = await TicketService.shared.searchForTickets(organization, sc);
      const content: Ticket[] | undefined = resp.data.content;

      // Save the newly retrieved page in Redux Store.  This will trigger the table to reload w/ the new data.
      dispatch(
        setTicketSearch({
          ...ticketSearch,
          data: content,
          searchType: searchType,
          totalSize: resp.data.totalElements as number,
          searchCriteria: sc,
          hasSearchSubmitted: true,
          hasData: true
        })
      );
    } catch (ex) {
      const axiosError = ex as AxiosError;
      if (axiosError.response?.status === 404) {
        // Ignore : Contact is new and has not been found in the ticket collection.
      } else {
        console.error(ex);
      }
    }
  };
   
  useEffect(() => {
    console.debug(...LOG_STYLE.EFFECT1, 'TicketSearch');
       onTableChange(undefined, { page: pageIndex, sizePerPage: pageSize, sortField: sorted[0].dataField, sortOrder: sorted[0].order });
  }, []);
  return (
    <>
      <SubSection>
        <RemoteTable
          keyField='ticketId'
          columns={ticketSearchColumns}
          data={data ? data : []}
          page={pageIndex}
          sizePerPage={pageSize}
          totalSize={totalSize}
          onTableChange={onTableChange}
          defaultSorted={sorted}
          rowEvents={rowEvents}
          classes={'default__table'}
        />
      </SubSection>
    </>
  );
}
