import 'react-bootstrap-table-next/dist/react-bootstrap-table2.css';
import 'styles/tableStyles.scss';

import { IContactHistoryState, setContactHistory } from 'reduxStore/slices/contactHistorySlice';
import React, { useCallback } from 'react';
import { SHOW_TICKET, contactHistoryColumns } from 'definitions';
import { useAppDispatch, useAppSelector } from 'reduxStore/hooks';

import { AxiosError } from 'axios';
import { LOG_STYLE } from 'utils';
import { RemoteTable } from 'components/TrackItReusable/RemoteTable/RemoteTable';
import { SectionHeader } from 'components/TrackItReusable/SectionHeader/SectionHeader';
import SubSection from 'components/TrackItReusable/SubSection/SubSection';
import { Ticket } from 'services';
import { TicketService } from 'services';
import { setShowTicket } from 'reduxStore/slices/trackItAppSlice';
import { setTicket } from 'reduxStore/slices/contactSlice';

/**
 * Renders a paged table component of Employee Contacts Ticket History.
 * @returns ContactHistoryList Component
 */
export function ContactHistoryList(props: { className?: string | undefined }) {
  console.debug(...LOG_STYLE.RENDER1, 'ContactHistoryList');

  const dispatch = useAppDispatch();
  const id = useAppSelector((state) => state.contact.currentContact.id);
  const organization = useAppSelector((state) => state.agent.organization);
  const contactHistoryData: IContactHistoryState = useAppSelector((state) => state.contactHistory);
  const sorted = [{ dataField: contactHistoryData.sortField ? contactHistoryData.sortField : 'ticketId', order: contactHistoryData.sortOrder ? contactHistoryData.sortOrder : 'desc' }];

  /**
   * Handles row selection event for table.
   * - Gets fresh ticket data from TicketService.
   *   - Sets retrieved ticket in redux for viewing.
   * - Changes to Detail view.
   */
  const rowEvents = {
    onClick: async (_e: any, row: { ticketId: string }, _rowIndex: any) => {
      console.debug(...LOG_STYLE.ACTION1, 'Select:SELECT_TICKET');

      console.debug(...LOG_STYLE.DEBUG1, 'ContactHistoryList:Set ShowTicket:DETAIL');
      dispatch(setShowTicket(SHOW_TICKET.DETAIL));

      console.debug(...LOG_STYLE.DEBUG1, 'ContactHistoryList:Load Ticket from TicketService');
      const result = await TicketService.shared.getTicket(organization, row.ticketId);
      dispatch(setTicket(result));
    }
  };

  /**
   * Handles table events such as Paging, filtering, sorting, pageSize change.
   */
  const onTableChange = useCallback(
    async (_type: any, newState: { page: number; sizePerPage: number; sortField: string; sortOrder: string }) => {
      try {
        const pageIndex = newState.page > 0 ? newState.page - 1 : 0; // Adjust page.

        // Retrieved new page of data from service.
        const resp = await TicketService.shared.findAllById(organization, id, pageIndex, newState.sizePerPage, newState.sortField, newState.sortOrder);
        const content: Ticket[] | undefined = resp.data.content;

        // Save the newly retrieved page in Redux Store.  This will trigger the table to reload w/ the new data.
        dispatch(
          setContactHistory({
            data: content,
            sizePerPage: resp.data.size as number,
            page: newState.page,
            totalSize: resp.data.totalElements as number,
            sortField: newState.sortField,
            sortOrder: newState.sortOrder,
            hasData: true
          })
        );
      } catch (ex) {
        const axiosError = ex as AxiosError;
        if (axiosError.response?.status === 404){
          // Ignore : Contact is new and has not been found in the ticket collection.
        } else {
          console.error(ex);
        }
        
      }
    },
    [contactHistoryData]
  );
  return (
    <>
      {/* <SectionHeader title='History' /> */}
        <RemoteTable
          keyField='ticketId'
          columns={contactHistoryColumns}
          data={contactHistoryData.data ? contactHistoryData.data : []}
          page={contactHistoryData.page}
          sizePerPage={contactHistoryData.sizePerPage}
          defaultSorted={sorted}
          totalSize={contactHistoryData.totalSize}
          onTableChange={onTableChange}
          rowEvents={rowEvents}
          classes={'default__table'}
        />
     
    </>
  );
}
