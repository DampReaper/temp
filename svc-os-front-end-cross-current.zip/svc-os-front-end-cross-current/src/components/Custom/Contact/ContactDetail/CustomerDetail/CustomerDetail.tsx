import { Contact, Customer } from 'services';

import { LOG_STYLE } from 'utils';
import React from 'react';

/**
 * Display Customer information.
 * @returns CustomerDetail Component.
 */

export interface ContactDetailProps {
  className?: string;
  contact: Contact;
}

export function CustomerDetail(props: ContactDetailProps) {
  console.debug(...LOG_STYLE.RENDER1, 'CustomerDetail');

  const customer = props.contact as Customer;

  return (
    <>
      <div className={props.className}>
        <div className='label-value'>{customer.fullName}</div>
        <div className='label-value'>{customer.taxId}</div>
        <div className='label-value'>{customer.birthDate}</div>
      </div>
    </>
  );
}
