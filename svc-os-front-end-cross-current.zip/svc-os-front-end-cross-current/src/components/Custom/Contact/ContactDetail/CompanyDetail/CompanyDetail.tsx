import { Company, Contact } from 'services';

import { LOG_STYLE } from 'utils';
import React from 'react';

/**
 * Display Company information.
 * @returns CompanyDetail Component.
 */

export interface ContactDetailProps {
  className?: string;
  contact: Contact;
}

export function CompanyDetail(props: ContactDetailProps) {
  console.debug(...LOG_STYLE.RENDER1, 'CompanyDetail');

  const company = props.contact as Company;

  return (
    <>
      <div className={props.className}>
        <div className='d-flex justify-content-between flex-row outline'>
          <div className='firstColumn outline'>
            <div className='d-flex flex-column'>
              <div className='label-wrapper outline'>
                <div className='label-value'>{company.companyName}</div>
                <span className='label-label'>Company</span>
              </div>
            </div>
          </div>
          <div className='midColum outline'></div>
          <div className='btnColumn outline'></div>
        </div>
      </div>
    </>
  );
}
