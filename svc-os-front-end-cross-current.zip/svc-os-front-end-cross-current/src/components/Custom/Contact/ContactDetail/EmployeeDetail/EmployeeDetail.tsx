import {} from 'components/TrackItReusable/FlexInput/FlexInput';

import { AUTHENTICATION_METHOD, SHOW_TICKET } from 'definitions';
import { Branch, Employee } from 'services';
import { LOG_STYLE, concatName } from 'utils';
import React, { useEffect, useState } from 'react';
import { clearContact, setContactAlias } from 'reduxStore/slices/contactSlice';
import { faCheckCircle, faCircleXmark } from '@fortawesome/free-regular-svg-icons';
import { useAppDispatch, useAppSelector } from 'reduxStore/hooks';

import { ContactDetailProps } from '../CompanyDetail/CompanyDetail';
import { FlexLabel } from 'components/TrackItReusable';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import Input from 'components/Reusable/Input';
import Section from 'components/Reusable/Section';
import { SectionHeader } from 'components/TrackItReusable/SectionHeader/SectionHeader';
import { setAuthenticationMethod } from 'reduxStore/slices/interactionSlice';
import styles from './employeeDetail.module.scss';

// import authenticationArrow from './authArrow.jpg';



/**
 * Display Employee information.
 * @returns EmployeeDetail Component.
 */
export function EmployeeDetail(props: ContactDetailProps) {
  console.debug(...LOG_STYLE.RENDER1, 'EmployeeDetail');

  const authenticationMethod = useAppSelector((state) => state.interaction.authenticationMethod);
  const showTicket = useAppSelector((state) => state.trackItApp.showTicket);

  const [visible, setVisible] = useState(false);

  const showModal = () => {
    setVisible(!visible);
  };
  const removeContact = () => {
    dispatch(clearContact());
  };

  const authenticatedContact = () => {
    dispatch(setAuthenticationMethod(AUTHENTICATION_METHOD.AGENT));
  };

  const employee = props.contact as Employee;

  const dispatch = useAppDispatch();

  //const id: string = useAppSelector((state) => state.employee?.id) as string;
  // const employee = useAppSelector((state) => state.employee) as Employee;
  // const employeeHasData = true;
  // const callerAuthenticationMethodId = useAppSelector((state) => state.ticket?.caller?.authenticationMethod) as AUTHENTICATION_METHOD;
  // const ticketId = useAppSelector((state) => state.ticket.ticketId) as string;
  // const isClosed: boolean = useAppSelector(selectIsClosed);
  const employeeFullNm = concatName(employee.lastName, employee.firstName);
  const employeeAddress = employee.streetAddress ? employee.streetAddress : '' + employee.city + employee.stateCd + employee.zip;

  const onAliasChange = (e) => {
    dispatch(setContactAlias(e.target.value));
  };
  useEffect(() => {
    console.debug(...LOG_STYLE.EFFECT1, 'EmployeeDetail');
  }, []);
  return (
    <>

{showTicket === SHOW_TICKET.DETAIL &&
        <>
        <div className={'grid gap-y-0 gap-x-0 sm:w-full md:grid-cols-2 lg:grid-cols-3'}>
            <FlexLabel label={'e-number'} value={employee.id} />
            <FlexLabel label={'Email'} value={employee.emailAddress} />
            <FlexLabel label={'Address'} value={employeeAddress} />
            <FlexLabel label={'Department'} value={employee.departmentName} />
            <FlexLabel label={'Status'} value={employee.recordStatusCd} />
            <FlexLabel label={'ManagerTitle'} value={employee.managerTitle} />
          </div>
          <div>
            <SectionHeader title={'Branch: "Express Services - RI'} onClick={showModal} icon={visible ? 'chevron-up' : 'chevron-down'} buttonText='Change' />

            {visible && (
              <div className={'grid gap-y-0 gap-x-0 sm:w-full md:grid-cols-2 lg:grid-cols-3'}>
                <FlexLabel label={'Name'} value={'Express Services - RI'} />
                <FlexLabel label={'Site'} value={'RI0'} />
                <FlexLabel label={'Phone'} value={'(401)734-5175'} />
                <FlexLabel label={'Manager'} value={'Doe, John'} />

                <FlexLabel label={'Address'} value={'100 Sockanosset Crossroad, Cranston, RI , 02920'} />
                <FlexLabel label={'Location'} value={'074'} />
                <FlexLabel label={'Fax'} value={'(401)944-6861'} />
                <FlexLabel label={'MarketDistrict'} value={'Rhode Island'} />

                <FlexLabel label={''} value={''} />
                <FlexLabel label={'Bank'} value={'001'} />
                <FlexLabel label={''} value={''} />
                <FlexLabel label={'ManagerWork'} value={'(401)944-6861'} />
              </div>
            )}
          </div>
        </>}

        {showTicket === SHOW_TICKET.HISTORY &&        
      <div className={styles.employeeDetailContainer}>
        <div className={`${styles.employeeDetailItem} ${'col-start-1 row-start-1'}`}>
          <label className={'font-medium'}>{employeeFullNm}</label>
          {/* <Section name={'employee'}> */}
          <div className={`${styles.section} ${''}`}>
            <div className={'grid gap-y-0 gap-x-0 sm:w-full md:grid-cols-2 lg:grid-cols-4'}>
              <FlexLabel label={'e-number'} value={employee.id} />
              <FlexLabel label={'Alias'} value={employee.alias} />
              <FlexLabel label={'Phone Number'} value={employee.phoneNum} />
              <FlexLabel label={'Status?'} value={employee.recordStatusCd} />
            </div>
          </div>
        </div>
        {authenticationMethod == AUTHENTICATION_METHOD.UNKNOWN && (
          <>
            {/* <img src={authenticationArrow} className={`${styles.employeeDetailItem} ${'col-start-2 row-start-1'}`} /> */}
            <div className={`${styles.employeeDetailItem} ${'col-start-2 row-start-1'}`} ></div>
            <div className={`${styles.employeeDetailItem} ${'col-start-3 row-start-1'}`}>
              <label className={`${styles.shadowText} ${''}`}>Authenticate using the following: </label>

              <div className={`${styles.section} ${''}`}>
                <div className={`${styles.authorizationContainer} `}>
                  <div className={`${styles.authorizationItem}`}>
                    <Input additionalStyles={styles.XXX} label={'Date of Birth'} value={'mm/dd'} id={'txtDOB'} onChange={onAliasChange} />
                    <div className={`${styles.authorizationIconContainer}`}>
                      <FontAwesomeIcon className={`${styles.authorizationIconItem}`} onClick={authenticatedContact} size='2x' shake icon={faCheckCircle} />
                      <FontAwesomeIcon className={`${styles.authorizationIconItem}`} onClick={removeContact} size='2x' icon={faCircleXmark} />
                    </div>
                  </div>
                  <div className={`${styles.authorizationItem} ${styles.center}`}>Or</div>
                  <div className={`${styles.authorizationItem}`}>
                    <Input additionalStyles={''} label={'TIN/PIN'} value={'****'} id={'txtTIN'} onChange={onAliasChange} />
                    <div className={`${styles.authorizationIconContainer}`}>
                      <FontAwesomeIcon className={`${styles.authorizationIconItem}`} onClick={authenticatedContact} size='2x' icon={faCheckCircle} />
                      <FontAwesomeIcon className={`${styles.authorizationIconItem}`} onClick={removeContact} size='2x' icon={faCircleXmark} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
        <div className={`${styles.employeeDetailItem} ${'col-start-4 row-start-1'}`}>
          <FontAwesomeIcon onClick={removeContact} className='fa-align-right fa-pull-right' size='2x' border icon={'close'} />
        </div>
      </div>
}

      {/* {employeeHasData ? <BranchSelector className='trackItContainer' /> : <Loading />} */}
    </>
  );
}
