import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';

import BootstrapTable, { ColumnDescription, SortOrder } from 'react-bootstrap-table-next';
import React, { useCallback, useEffect, useState } from 'react';
import filterFactory, { textFilter } from 'react-bootstrap-table2-filter';

import { Branch } from 'services';
import { BranchService } from 'services';
import Button from 'components/Reusable/Button';
import { LOG_STYLE } from 'utils';
import PropTypes from 'prop-types';
import paginationFactory from 'react-bootstrap-table2-paginator';

// import { Button, Modal } from 'react-bootstrap';

/**
 * Modal form for displaying a filterable list of branches.
 */
const columns: ColumnDescription[] = [
  {
    dataField: 'branchNm',
    text: 'Branch',
    sort: true,
    filter: textFilter(),
    formatter: (col, row) => {
      return <span style={{ display: 'block', width: 200, overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis' }}>{col}</span>;
    },
    headerStyle: { width: '200px', textAlign: 'left' }
  },
  {
    dataField: 'address1Txt',
    text: 'Address',
    sort: true,
    filter: textFilter(),
    formatter: (col, row) => {
      return <span style={{ display: 'block', width: 200, overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis' }}>{col}</span>;
    },
    headerStyle: { width: '200px', textAlign: 'left' }
  },
  {
    dataField: 'cityNm',
    text: 'City',
    filter: textFilter(),
    sort: true,
    formatter: (col, row) => {
      return <span style={{ display: 'block', whiteSpace: 'nowrap' }}>{col}</span>;
    },
    headerStyle: { width: '150px', textAlign: 'left' }
  },
  {
    dataField: 'stateCd',
    text: 'State',
    filter: textFilter(),
    sort: true,
    formatter: (col, row) => {
      return <span style={{ display: 'block', whiteSpace: 'nowrap' }}>{col}</span>;
    },
    headerStyle: { width: '50px', textAlign: 'left' }
  },
  {
    dataField: 'siteId',
    text: 'Site',
    filter: textFilter(),
    sort: true,
    formatter: (col, row) => {
      return <span style={{ display: 'block', whiteSpace: 'nowrap' }}>{col}</span>;
    },
    headerStyle: { width: '100px', textAlign: 'left' }
  },
  {
    dataField: 'branchCd',
    text: 'BranchCode',
    filter: textFilter(),
    sort: true,
    formatter: (col, row) => {
      return <span style={{ display: 'block', whiteSpace: 'nowrap' }}>{col}</span>;
    },
    headerStyle: { width: '100px', textAlign: 'left' }
  },
  {
    dataField: 'locationCd',
    text: 'Location',
    filter: textFilter(),
    sort: true,
    formatter: (col, row) => {
      return <span style={{ display: 'block', whiteSpace: 'nowrap' }}>{col}</span>;
    },
    headerStyle: { width: '100px', textAlign: 'left' }
  }
];

const defaultSorted: [{ dataField: any; order: SortOrder }] = [
  {
    dataField: 'branchId',
    order: 'desc'
  }
];

const RemoteAll = ({ data, page, sizePerPage, onTableChange, totalSize, rowEvents }) => (
  <div>
    <BootstrapTable
      bootstrap4={true}
      remote
      striped
      hover
      condensed
      table-responsive
      keyField='branchId'
      data={data}
      columns={columns}
      defaultSorted={defaultSorted}
      pagination={paginationFactory({ page, sizePerPage, totalSize })}
      filter={filterFactory()}
      onTableChange={onTableChange}
      rowEvents={rowEvents}
    />
  </div>
);

RemoteAll.propTypes = {
  //data: PropTypes.array.isRequired,
  page: PropTypes.number.isRequired,
  totalSize: PropTypes.number.isRequired,
  sizePerPage: PropTypes.number.isRequired,
  onTableChange: PropTypes.func.isRequired
};

/**
 * Modal form for displaying a filterable list of branches.
 *
 * @param onSave event called when save button pressed.
 * @param show boolean to hide/show the modal form.
 * @param onHide event to trigger hiding when modal close button pressed.
 */
export function BranchModal(props: { onSave: (row: Branch) => void; show: boolean; onHide: React.MouseEventHandler<HTMLButtonElement> }) {
  console.debug(...LOG_STYLE.RENDER1, 'BranchModal');

  const [contactHistoryData, setContactHistoryData] = useState({
    data: [] as Branch[] | undefined,
    branchIncoming: {} as Branch,
    page: 0 as number,
    sizePerPage: 0 as number,
    totalSize: 0 as number,
    hasData: false
  });

  /**
   * Event handler for when a row is clicked.
   *
   */
  const rowEvents = {
    onClick: (e: any, row: Branch, rowIndex: number) => {
      props.onSave(row);
    }
  };

  /**
   * Callback function that handles tables events such as Paging, Sorting, filtering...
   *
   * @param page page of data to display.
   * @param sizePerPage number of rows in a page.
   * @param filters column filters applied.
   */
  const HandleTableChange = useCallback(
    async (type, { page, sizePerPage, filters, sortField, sortOrder, cellEdit }) => {
      console.log('Render:ContactDetailItem Component.HandleTableChange');

      // Fix pageIndex discrepancies between server and client.
      const pageIndex = page > 0 ? page - 1 : 0;

      // Build outgoing packet.
      const branchIncoming = {
        branchCd: filters?.branchCd?.filterVal,
        locationCd: filters?.locationCd?.filterVal,
        bankCd: filters?.bankCd?.filterVal,
        branchNm: filters?.branchNm?.filterVal,
        address1Txt: filters?.address1Txt?.filterVal,
        cityNm: filters?.cityNm?.filterVal,
        stateCd: filters?.stateCd?.filterVal,
        zipCd: filters?.zipCd?.filterVal,
        areaCd: filters?.areaCd?.filterVal,
        siteId: filters?.siteId?.filterVal,
        activeInd: true
      } as Branch;

      // Get branch data from web service.
      const resp = await BranchService.shared.findAllPaged(branchIncoming, pageIndex, sizePerPage === 0 ? 10 : sizePerPage);
      const content: Branch[] | undefined = resp.data.content;

      // Save data returned so it can be displayed.
      setContactHistoryData({
        ...contactHistoryData,
        data: content,
        sizePerPage: resp.data.size as number,
        page: page as number,
        totalSize: resp.data.totalElements as number,
        hasData: true
      });
    },
    [contactHistoryData]
  );

  useEffect(() => {
    console.debug(...LOG_STYLE.EFFECT1, 'BranchModal');

    // Setup data for EmployeeTicketHistory component.
    HandleTableChange(null, { page: 0, sizePerPage: 5, filters: null, sortField: null, sortOrder: null, cellEdit: null });
  }, []);

  return (
    <>
      {props.show && (
        <div>
          <div className='table-responsive'>
            <RemoteAll
              data={contactHistoryData.data}
              page={contactHistoryData.page}
              sizePerPage={contactHistoryData.sizePerPage}
              totalSize={contactHistoryData.totalSize}
              onTableChange={HandleTableChange}
              rowEvents={rowEvents}
            />
          </div>

          <Button handleClick={props.onHide} id={'btnClose'} text={'Close'} type={'primary'}  />
        </div>
      )}
    </>
  );
}
