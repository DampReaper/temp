import { Branch } from 'services';
import { Label } from 'components/Reusable/Label';
import Loading from 'components/Reusable/Loading';
import React from 'react';

/**
 * Renders Branch address information.
 * @param props
 * @returns Address Component.
 */
export function Address(props: { branch: Branch | undefined }) {
  const branch = props.branch;
  if (branch) {
    return (
      <>
        {/* // <address data-testid='address'> */}
        <Label value={branch.address1Txt} label='Address' />
        <Label value={branch.cityNm + ', ' + branch.stateCd} label='City/State' />
        <Label value={branch.zipCd} label='Zip' />
        {/* // </address> */}
      </>
    );
  } else {
    return (
      <address data-testid='address'>
        <Loading />
      </address>
    );
  }
}
