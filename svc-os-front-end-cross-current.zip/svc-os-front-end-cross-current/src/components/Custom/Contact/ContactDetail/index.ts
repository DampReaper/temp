export * from './CompanyDetail/CompanyDetail';
// export * from './CustomerDetail/CustomerDetail';
export * from './EmployeeDetail/branchSelector/Address';
export * from './EmployeeDetail/branchSelector/BranchModal';
// export * from './EmployeeDetail/branchSelector/BranchSelector';
// export * from './EmployeeDetail/EmployeeDetail';
// export * from '../../../../view/journey/trackIt/contactForm/contactDetail/employeeDetail/Secrets';

