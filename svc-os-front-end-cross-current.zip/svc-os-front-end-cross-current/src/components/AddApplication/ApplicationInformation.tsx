import ActionBar from './ActionBar';
import React from 'react';

const ApplicationInformation = ({ nextStep, prevStep }) => {
  return (
    <>
      <div>ApplicationInformation</div>
      <ActionBar nextStep={nextStep} prevStep={prevStep} />
    </>
  );
};

export default ApplicationInformation;
