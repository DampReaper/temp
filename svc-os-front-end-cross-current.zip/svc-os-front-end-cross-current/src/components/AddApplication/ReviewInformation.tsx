import ActionBar from './ActionBar';
import React from 'react';

const ReviewInformation = ({ nextStep, prevStep }) => {
  return (
    <>
      <div>ReviewInformation</div>
      <ActionBar nextStep={nextStep} prevStep={prevStep} />
      
    </>
  );
};

export default ReviewInformation;
