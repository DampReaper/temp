import { LOG_STYLE } from 'utils/logStyle';
import { YesNoUndefined } from 'reduxStore/slices/applicationSlice';

console.debug(...LOG_STYLE.RENDER1, 'validateBankInfo');

export const validateBankInfo = (application) => {
  console.log(...LOG_STYLE.DEBUG1, 'validation.validateBankInfo');

  const validBranchNum = ['98', '10'];

  let errors: { hasErrors: boolean; branchNum?: string; salesId?: string; originator?: string; reviewedOverdraftChoices?: string } = { hasErrors: false };
  if (!application.branchNum) {
    errors.branchNum = 'BranchNum is required';
    errors.hasErrors = true;
  }

  if (!application.salesId) {
    errors.salesId = 'Sales Id is required';
    errors.hasErrors = true;
  }

  if (!application.originator) {
    errors.originator = 'Originator is required';
    errors.hasErrors = true;
  }

  if (!application.reviewedOverdraftChoices || application.reviewedOverdraftChoices === YesNoUndefined.Undefined) {
    errors.reviewedOverdraftChoices = 'Some long text about reviewedOverdraftChoices being required';
    errors.hasErrors = true;
  }

  if (application.branchNum&&validBranchNum.indexOf(application.branchNum) === -1) {
      errors.branchNum = 'BranchNum is invalid';
      errors.hasErrors = true;
    }

  return errors;
};
