import React, { useState } from 'react';
import { YesNoUndefined, updateFormData } from 'reduxStore/slices/applicationSlice';
import { useAppDispatch, useAppSelector } from 'reduxStore/hooks';

import ActionBar from './ActionBar';
import Dropdown from 'components/Reusable/Dropdown';
import Header from 'components/TrackItReusable/Header/Header';
import Input from 'components/Reusable/Input';
import { LOG_STYLE } from 'utils/logStyle';
import { PatternFormat } from 'react-number-format';
import { validateBankInfo } from './Validation';

const BankInformation = ({ nextStep }) => {
  console.debug(...LOG_STYLE.RENDER1, 'BankInformation');

  const [errors, setErrors] = useState({});
  const dispatch = useAppDispatch();
  const application = useAppSelector((state) => state.application);
  
  const triChoice = (value: string | boolean) => {
    if (value == YesNoUndefined.Yes) {
      return { label: 'Yes', value: 'true' };
    }
    if (value == YesNoUndefined.No) {
      return { label: 'No', value: 'false' };
    }
    return { label: '', value: '' };
  };

  const handleInputChange = (e: any) => {
    const { name, value } = e.target;
    dispatch(updateFormData({ [name]: value }));
  };
   
  const onChangeReviewedOverdraftChoices = (e: any) => {
    console.log(e !== null && e.value ? e.value : undefined);
    if (e != null) {
      dispatch(updateFormData({ reviewedOverdraftChoices: e.value === 'true'?YesNoUndefined.Yes:YesNoUndefined.No }));
      // if (e.value == 'true') {
      //   dispatch(updateFormData({ reviewedOverdraftChoices: YesNoUndefined.Yes }));
      // }
      // if (e.value == 'false') {
      //   dispatch(updateFormData({ reviewedOverdraftChoices: YesNoUndefined.No }));
      // }
    }
    //dispatch(setReviewedOverdraftChoices(YesNoUndefined.Undefined);
  };
 
  const validateBeforeNextStep = () => {
    const err = validateBankInfo(application);
    if (!err.hasErrors) {
      nextStep();
    } else {
      setErrors(err);
    }
  };

  return (
    <>
      <Header title={'Bank Information'} />
      <Dropdown
        additionalStyles={` ${'col-start-1 col-span-2 row-start-1'}`}
        id={'reviewedOverdraftChoices'}
        label={'Have you reviewed all Overdraft Choices with your customer using either the Overdraft Choices Compare Chart or Video?'}
        onChange={onChangeReviewedOverdraftChoices}
        value={triChoice(application.reviewedOverdraftChoices)}
        required={true}
        error={errors.reviewedOverdraftChoices}
        options={[
          { label: 'Yes', value: 'true' },
          { label: 'No', value: 'false' }
        ]}
      />
      <div className={'grid gap-y-0 gap-x-0 sm:w-full md:grid-cols-2 lg:grid-cols-2'}>
        <Input id={'branchNum'} required={true} label={'Branch #'} onChange={handleInputChange} value={application.branchNum || ''} error={errors.branchNum} />
        <PatternFormat
          id={'salesId'}
          customInput={Input}
          onValueChange={(values, sourceInfo) => {
            dispatch(updateFormData({ salesId: values.value }));
            console.log(values, sourceInfo);
          }}
          required={true}
          error={errors.salesId} 
          label={'SalesId (Your SSN)'}
          value={application.salesId}
          valueIsNumericString
          format='#### #### #### ####'
          mask='_'
        />
        <Input id={'originator'} label={'Originator'} onChange={handleInputChange} value={application.originator || ''} error={errors.originator} required={true}/>
        <Input id={'referralId'} label={'Referral Id'} onChange={handleInputChange} value={application.referralId || ''} />
      </div>
      <ActionBar nextStep={validateBeforeNextStep} />
    </>
  );
};
export default BankInformation;
