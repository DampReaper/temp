import ActionBar from './ActionBar';
import React from 'react';

const OtherInformation = ({ nextStep, prevStep }) => {
  return (
    <>
      <div>OtherInformation</div>
      <ActionBar nextStep={nextStep} prevStep={prevStep} />
      
    </>
  );
};

export default OtherInformation;
