import ActionBar from './ActionBar';
import React from 'react';

const SubmissionInformation = ({ nextStep }) => {
  return (
    <>
      <div>SubmissionInformation</div>
      <ActionBar nextStep={nextStep} />
    </>
  );
};

export default SubmissionInformation;
