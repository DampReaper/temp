import React, { MouseEventHandler } from 'react';

import Button from 'components/Reusable/Button';
import { useNavigate } from 'react-router-dom';

export type ActionBarProps = {
  /** Error message to display if any */
  prevStep?: MouseEventHandler<HTMLButtonElement>;

  /** Indicated the type of field (text, password, etc) */
  nextStep?: MouseEventHandler<HTMLButtonElement>;

  nextStepDisabled?:boolean;
};

const ActionBar = ({ nextStep, prevStep,nextStepDisabled }: ActionBarProps) => {
  const navigate = useNavigate();

  const handleCancel = () => {
    navigate('/');
  };
  return (
    <>
      <div className='footer__controls mt-14 flex w-full flex-row items-center justify-center self-end lg:w-1/3 lg:justify-end'>
        {prevStep && <Button id={'btnBack'} handleClick={prevStep} text={'Back'} type={''} />}
        <Button id={'btnCancel'} handleClick={handleCancel} text={'Cancel'} type={''} />
        {nextStep && <Button id={'btnNext'} handleClick={nextStep} text={'Next'} type={'primary'} disabled={nextStepDisabled} />}
      </div>
    </>
  );
};

export default ActionBar;
