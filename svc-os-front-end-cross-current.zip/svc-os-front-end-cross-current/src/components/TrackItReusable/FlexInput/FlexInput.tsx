import React, { ChangeEventHandler } from "react";

import styles from "./input.module.scss";

export type FlexInputProps = {
  /** ID for the element */
  id: string;

  /** Label to display on top of the element */
  label: string;

  /** Handler for changes in the value */
  onChange: ChangeEventHandler;

  /** Error message to display if any */
  error?: boolean | string;

  /** Handler to check for errors */
  errorHandler?: ChangeEventHandler;

  /** Value to display in the element */
  value: string | undefined;

  /** Determines if the element is rendered in a popup component */
  isPopup?: boolean;

  /** Indicates if the field is required or optional */
  required?: boolean;

  /** Indicated the type of field (text, password, etc) */
  type?: string;
};

export const FlexInput = ({
  id,
  label,
  onChange,
  error,
  errorHandler,
  value,
  required,
  type = "text",
}: FlexInputProps) => {
  return (

    <div className={`${styles.interactionInputWrapper}`}>
      <label htmlFor={id} className='font-medium'>
        {label}
        {required && <i className={styles.required}>*</i>}
      </label>
      <div className={styles.errorWrapper}>
        <input
          className={`${
            error
              ? styles.interactionInputTextError
              : styles.interactionInputText
          }`}
          type={type}
          name={id}
          id={id}
          value={value}
          onChange={onChange}
          onBlur={(e) => errorHandler && errorHandler(e)}
          placeholder={`Enter ${label}`}
          autoComplete="off"
        />
        <label
          htmlFor={id}
          className={
            error ? styles.errorLabel : "pointer-events-none opacity-0"
          }
        >
          {error ? error : "noerror"}
        </label>
      </div>
    </div>
  );
};
