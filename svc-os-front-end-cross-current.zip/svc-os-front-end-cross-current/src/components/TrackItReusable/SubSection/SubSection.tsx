import PropTypes from 'prop-types';
import React from 'react';
import styles from './subSection.module.scss';

export default function SubSection({ children, title }) {
  return (
    <>
      <div className={styles.subSectionHeader}>
      {title &&  <h1 className={styles.subSectionTitle}>{title}</h1>}
        <div className={styles.subSectionBody}>{children}</div>
      </div>
    </>
  );
}

SubSection.propTypes = {
  children: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.node), PropTypes.node.isRequired]),
  title: PropTypes.string
};
