import PropTypes from 'prop-types';
import React from 'react';

export function FlexGroup({ children, title, buttonText, icon, onClick }) {
  return (
    <>
      <div>
        <div className='trackIt-flex-container-header'>
          {title && <span className='font-medium'>{title}</span>}
          {buttonText && (
            <button onClick={onClick} className='select-none rounded-2xl bg-ctz-orange px-3 text-sm leading-6 text-white'>
              {buttonText}
            </button>
          )}
          {icon && <button onClick={onClick} className={`${icon} text-lg text-ctz-green-100`}></button>}
        </div>
        {children}
      </div>
    </>
  );
}

FlexGroup.propTypes = {
  children: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.node),PropTypes.node ]),
  title: PropTypes.string.isRequired,
  icon: PropTypes.string,
  buttonText: PropTypes.string,
  onClick: PropTypes.func
};
