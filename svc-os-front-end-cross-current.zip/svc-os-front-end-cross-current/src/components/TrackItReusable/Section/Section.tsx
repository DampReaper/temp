import PropTypes from 'prop-types';
import React from 'react';

// Todo : Why problem w/ className='section'?
export default function Section({ children, title }) {
  return (
    <>
      <div className='section'>
        {title && <h1 className='interaction__label'>{title}</h1>}
        {children}
      </div>
    </>
  );
}

Section.propTypes = {
  children: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.node), PropTypes.node.isRequired]),
  title: PropTypes.string
};
