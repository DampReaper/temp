import PropTypes from 'prop-types';
import React from 'react';

export const FlexRow =  ({ children }) =>{
  return (
    <>
     <div className='trackIt-flex-container-row'>
        {children}
      </div>
    </>
  );
}

FlexRow.propTypes = {
  children: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.node), PropTypes.node.isRequired])
};
