import PropTypes from 'prop-types';
import React from 'react';

export const FlexContainer = ({ children })=> {
  return (
    <>
      <div className='trackIt-flex-container'>
        {children}
      </div>
    </>
  );
}

FlexContainer.propTypes = {
  children: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.node), PropTypes.node.isRequired])
};
