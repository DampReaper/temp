import 'react-bootstrap-table-next/dist/react-bootstrap-table2.css';

import { pageButtonRenderer, sizePerPageRenderer } from 'utils/TablePageRender';

import BootstrapTable from 'react-bootstrap-table-next';
import { LOG_STYLE } from 'utils';
import PropTypes from 'prop-types';
import React from 'react';
import paginationFactory from 'react-bootstrap-table2-paginator';
import { sizePerPageList } from 'definitions/index';

RemoteTable.propTypes = {
  data: PropTypes.array.isRequired,
  page: PropTypes.number.isRequired,
  totalSize: PropTypes.number.isRequired,
  sizePerPage: PropTypes.number.isRequired,
  onTableChange: PropTypes.func.isRequired,
  rowEvents: PropTypes.object.isRequired,
  defaultSorted: PropTypes.array.isRequired,
  keyField: PropTypes.string.isRequired,
  classes: PropTypes.string.isRequired
};

/**
 * Renders a Remote paged table component.
 * @returns ContactHistoryList Component
 */
export function RemoteTable({ data, page, sizePerPage, onTableChange, totalSize, rowEvents, columns, defaultSorted, keyField, classes }) {
  console.debug(...LOG_STYLE.RENDER1, 'RemoteTable');

   const defaultPaginationOptions = {
    pageStartIndex: page,
    disablePageTitle: true,
    paginationSize: sizePerPage,
    sizePerPageList: sizePerPageList,
    showTotal: true,
    pageButtonRenderer: pageButtonRenderer,
    sizePerPageRenderer: sizePerPageRenderer,
  };

  return (
    <>
      <BootstrapTable
        remote
        bootstrap4={true}
        striped
        bordered={true}
        hover
        condensed
        table-responsive
        keyField={keyField}
        data={data}
        columns={columns}
        defaultSorted={defaultSorted}
        pagination={paginationFactory(defaultPaginationOptions)}
        onTableChange={onTableChange}
        rowEvents={rowEvents}
        classes={classes}
      />
    </>
  );
}
