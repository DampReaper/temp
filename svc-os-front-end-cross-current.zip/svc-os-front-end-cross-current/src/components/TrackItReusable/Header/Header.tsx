import React from "react";

function Header(props: { title: string; } ) {
  return (
    <>
      <div className="header mx-auto flex flex-row w-full pl-3 pt-7 pb-5">
        <h1 className="text-xl font-medium">{props.title}</h1>
      </div>
      <div className="interaction__header p-3">
      </div>
    </>
  );
}

export default Header;