import React from 'react';

export type FlexLabelProps = {
  /** Label to display on top of the element */
  label: string;

  /** Value to display in the element */
  value: string | undefined;

  /** Determines if the element is rendered in a popup component */
  isPopup?: boolean;

  /** Row start number for grid */
  rowStart?: string;

  /** Column start number for grid */
  columnStart?: string;
};

export const FlexLabel = ({ label, value, rowStart, columnStart }: FlexLabelProps) => {
  return (
    <div style={{ gridColumnStart: columnStart, gridRowStart: rowStart }}>
      <div><label className='font-medium'>{label}</label></div>
      <label>{value ?? ''}</label>
      <div>&nbsp;</div>
    </div>
  );
};
