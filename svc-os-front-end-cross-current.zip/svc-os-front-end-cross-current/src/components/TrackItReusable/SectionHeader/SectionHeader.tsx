import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import PropTypes from 'prop-types';
import React from 'react';
import styles from '../trackItReusable.module.scss';

export function SectionHeader({ children, title, buttonText, icon, onClick, onButtonClick, additionalStyles }) {
  return (
    <>
      <div>
        <div className={` ${styles.sectionHeader}  ${additionalStyles}`}>
          {title && <span className='font-medium'>{title}</span>}
          {icon && <FontAwesomeIcon onClick={onClick} className='fa-align-right fa-pull-right' icon={icon} />}
          {buttonText && (
            <button onClick={onButtonClick} className='select-none rounded-2xl bg-ctz-orange px-3 text-sm leading-6 text-white' style={{ float: 'right' }}>
              {buttonText}
            </button>
          )}
          
        </div>
        {children}
      </div>
    </>
  );
}

SectionHeader.propTypes = {
  children: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.node), PropTypes.node]),
  title: PropTypes.string.isRequired,
  additionalStyles: PropTypes.string,
  icon: PropTypes.string,
  buttonText: PropTypes.string,
  onClick: PropTypes.func,
  onButtonClick: PropTypes.func
};
