import { IconProp } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { KeyboardEventHandler } from "react";

//@ts-ignore
import styles from "./tabs.module.scss";

export interface tab {
  /** Name of the tab */
  name: string;

  /** Icon for the tab */
  icon: IconProp;
}

export type TabsProps = {
  /** List of tabs to render */
  tabList: tab[];

  /** Current Active Tab */
  activeTab: string;

  /** Handler to change tabs using mouse */
  handleTabChange: any;

  /** Handlers to change tab using keyboard */
  handleKeyDown?: KeyboardEventHandler;
};

export const Tabs = ({
  tabList,
  activeTab,
  handleTabChange,
  handleKeyDown,
}: TabsProps) => {
  return (
    <ul className={styles.tabs} role="tablist" onKeyDown={handleKeyDown}>
      {tabList.map((tab) => {
        return (
          <li
            className={`${styles.tab} ${
              activeTab === tab.name ? "bg-gray-100" : ""
            }`}
            id={tab.name}
            role="tab"
            tabIndex={activeTab === tab.name ? 0 : -1}
            key={tab.name}
          >
            <div
              onClick={() => handleTabChange(tab)}
              role="button"
              className={`${styles.tabWrapper} ${
                activeTab === tab.name ? styles.tabWrapperActive : ""
              } flex h-12 min-w-fit flex-col items-center`}
            >
              <h1
                className={`${styles.tabText} ${
                  activeTab === tab.name ? styles.tabTextActive : "tab--text"
                }`}
              >
                <FontAwesomeIcon icon={tab.icon} className="mr-3" />
                {tab.name}
              </h1>
            </div>
          </li>
        );
      })}
    </ul>
  );
};
