import React, { ChangeEventHandler } from "react";
import styles from "./checkbox.module.scss";

export type Checkboxprops = {
  id: string;
  onChangeHandler: ChangeEventHandler<HTMLInputElement>;
  text: string;
  value: boolean;
};

function Checkbox({ id, onChangeHandler, text, value }: Checkboxprops) {
  return (
    <div className={styles.checkboxWrapper}>
      <input
        type="checkbox"
        id={id}
        checked={value ? true : false}
        onChange={onChangeHandler}
        className={styles.customCheckbox}
      />
      <label
        htmlFor={id}
        className={value ? styles.checkboxLabelChecked : styles.checkboxLabel}
      >
        {text}
      </label>
    </div>
  );
}

export default Checkbox;
