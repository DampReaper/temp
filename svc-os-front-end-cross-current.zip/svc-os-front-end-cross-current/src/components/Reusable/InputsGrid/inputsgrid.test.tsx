import React from "react";
import { render, screen } from "@testing-library/react";
import Button from "../Button";
import InputsGrid from ".";
import Input from "../Input";

describe("test the Inputs Grid component", () => {
  test("should render the children correctly", () => {
    render(
      <InputsGrid>
        <Input id="input1" label="Input1" onChange={() => {}} value="" />
        <Input id="input2" label="Input2" onChange={() => {}} value="" />
        <Input id="input3" label="Input3" onChange={() => {}} value="" />
        <Input id="input4" label="Input4" onChange={() => {}} value="" />
      </InputsGrid>
    );

    const inputs = screen.getAllByLabelText(/Input/i);

    expect(inputs).toHaveLength(4);
  });
});
