import React from 'react';
import styles from './inputsgrid.module.scss';

type InputsGridProps = {
  children: React.ReactNode;
  additionalStyles?: string;
};

function InputsGrid({ children, additionalStyles }: InputsGridProps) {
  return <div className={`${styles.inputsGridContainer} ${additionalStyles}`}>{children}</div>;
}

export default InputsGrid;
