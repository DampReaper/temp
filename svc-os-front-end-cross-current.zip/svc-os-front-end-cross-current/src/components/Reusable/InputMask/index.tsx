import React, { ChangeEventHandler } from "react";

import { PatternFormat } from 'react-number-format';
import styles from "./inputMask.module.scss";

export type InputMaskProps = {
  /** ID for the element */
  id: string;

  /** Label to display on top of the element */
  label: string;

  /** Handler for changes in the value */
  onChange: ChangeEventHandler;

  /** Error message to display if any */
  error?: string;

  /** Handler to check for errors */
  errorHandler?: ChangeEventHandler;

  /** Value to display in the element */
  value: string;

  /** Indicates if the field is required or optional */
  required?: boolean;

  /** Indicated the type of field (text, password, etc) */
  type?: 'text' | 'tel' | 'password';

  /** Additional tailwind classes to style the input */
  additionalStyles?: string;
  
  format: string;

  valueIsNumericString?: boolean;
};

const InputMask = ({
  id,
  label,
  onChange,
  error,
  errorHandler,
  value,
  required,
  format,
  type = "text",
  additionalStyles,
  valueIsNumericString,
}: InputMaskProps) => {
  return (
    <div className={`${styles.interactionInputWrapper} ${additionalStyles}`}>
      <label htmlFor={id} className={styles.interactionInputLabel}>
        {label}
        {required && <i className={styles.required}>*</i>}
      </label>
      <div className={styles.errorWrapper}>
        <PatternFormat
          className={`${
            error
              ? styles.interactionInputTextError
              : styles.interactionInputText
          }`}
          type={type}
          format={format}
          name={id}
          id={id}
          value={value}
          onChange={onChange}
          valueIsNumericString={valueIsNumericString}
          onBlur={(e) => errorHandler && errorHandler(e)}
          placeholder={`Enter ${label}`}
          autoComplete="off"
          aria-invalid={error && error?.length > 0 ? true : false}
          aria-errormessage={`${id}-error`}
        />
        <label
          htmlFor={id}
          id={`${id}-error`}
          className={
            error ? styles.errorLabel : "pointer-events-none opacity-0"
          }
        >
          {error ? error : "noerror"}
        </label>
      </div>
    </div>
  );
};

export default InputMask;
