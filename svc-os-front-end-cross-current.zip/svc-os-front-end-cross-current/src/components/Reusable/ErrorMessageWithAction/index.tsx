import { IconProp } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import Button from "../Button";
import styles from "./errormessagewithaction.module.scss";

type ErrorMessageWithActionProps = {
  message: string;
  buttonType: string;
  buttonId: string;
  buttonText: string;
  buttonIcon: IconProp;
  buttonClickHandler: any;
};

function ErrorMessageWithAction({
  message,
  buttonType,
  buttonId,
  buttonText,
  buttonIcon,
  buttonClickHandler,
}: ErrorMessageWithActionProps) {
  return (
    <div className={styles.errorMessage}>
      <h1>
        <FontAwesomeIcon icon="exclamation-circle" /> {message}
      </h1>

      <Button
        id={buttonId}
        type={buttonType}
        handleClick={buttonClickHandler}
        text={buttonText}
        icon={buttonIcon}
      />
    </div>
  );
}

export default ErrorMessageWithAction;
