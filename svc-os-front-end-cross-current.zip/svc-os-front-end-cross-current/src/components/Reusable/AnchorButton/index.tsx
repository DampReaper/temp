import { IconProp } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import styles from "./anchorbutton.module.scss";

type AnchorButtonProps = {
  id: string;
  href: string;
  text: string;
  type: string;
  icon?: IconProp;
};

function AnchorButton({ id, href, text, type, icon }: AnchorButtonProps) {
  return (
    <a
      id={id}
      className={`${
        type === "primary"
          ? styles.anchorButtonPrimary
          : styles.anchorButtonSecondary
      }`}
      href={href}
    >
      {text} {icon && <FontAwesomeIcon icon={icon} className="ml-3" />}
    </a>
  );
}

export default AnchorButton;
