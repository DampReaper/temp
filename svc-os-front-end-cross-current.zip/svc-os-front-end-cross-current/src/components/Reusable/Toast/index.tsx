import React from "react";
import { toast, ToastContainer } from "react-toastify";
import ErrorToast, { errorToastStyles } from "./ErrorToast";
import PendingToast from "./PendingToast";
import SuccessToast, { successToastStyles } from "./SuccessToast";
import styles from "./toast.module.scss";
import "react-toastify/dist/ReactToastify.css";

export const useToast = (
  functionWithPromise: any,
  pendingMessage: string,
  successMessage: string,
  failureMessage: string
) => {
  return toast.promise(functionWithPromise, {
    pending: {
      render() {
        return <PendingToast message={pendingMessage} />;
      },
      style: {
        border: "1px solid hsl(220, 14%, 96%)",
        borderRadius: "0.375rem",
      },
    },
    success: {
      render() {
        return <SuccessToast message={successMessage} />;
      },
      ...successToastStyles,
      style: {
        border: "1px solid hsl(158, 100%, 26%)",
        borderRadius: "0.375rem",
      },
    },

    error: {
      render() {
        return <ErrorToast message={failureMessage} />;
      },
      ...errorToastStyles,
      style: {
        border: "1px solid hsl(0, 66%, 49%)",
        borderRadius: "0.375rem",
      },
    },
  });
};

function Toast() {
  return (
    <ToastContainer
      className={styles.toast}
      pauseOnHover={true}
      autoClose={2500}
      toastStyle={{
        border: "1px solid hsl(0, 66%, 49%)",
        borderLeftWidth: "4px",
        borderRadius: "0.375rem",
      }}
    />
  );
}

export default Toast;
