import React, { useEffect, useRef, useState } from "react";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import ReactToPrint from "react-to-print";
import { mapConductorToAPIObject } from "utils/Helpers";
import { selectConductor } from "reduxStore/slices/conductorSlice";
import { selectMappedId } from "reduxStore/slices/helperSlice";
import styles from "./toast.module.scss";
import { transaction } from "../../../utils/interfaces";
import transactionService from "services/transactionService";
import { useParams } from "react-router-dom";
import { useReduxSelector } from "reduxStore/hooks";

export const errorToastStyles = {
  icon: <FontAwesomeIcon icon="exclamation-circle" />,
  bodyClassName: styles.errorToast,
  progressClassName: styles.errorProgress,
};

const Section = ({ heading, data }: { heading: string; data: any[] }) => {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
      <h1 className="font-medium">{heading}</h1>
      {data.map((m, index) => (
        <div key={index} style={{ display: "flex", gap: "1rem" }}>
          <p style={{ width: "25%", textAlign: "right" }}>{m[0]}</p>
          <p>{m[1]}</p>
        </div>
      ))}
    </div>
  );
};

const PrintMicroReport = React.forwardRef<HTMLDivElement>((props, ref) => {
  const conductor = mapConductorToAPIObject(useReduxSelector(selectConductor));
  const mappedId = useReduxSelector(selectMappedId);
  if (mappedId !== null) conductor.identifications = [mappedId];
  const [transactionDetails, setTransactionDetails] = useState<transaction>();
  const params = useParams();

  useEffect(() => {
    params.transactionId &&
      transactionService
        .getTransactionDetails(params.transactionId)
        .then((res) => setTransactionDetails(res.data));
  }, []);

  return (
    <div
      ref={ref}
      style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
    >
      <span style={{ display: "flex", justifyContent: "space-between" }}>
        <h1 className="text-xl font-medium">
          AML MICRO REPORT - OFFLINE REPORT
        </h1>
        <p>{transactionDetails?.colleague.userId}</p>
        <p>{new Date().toLocaleString()}</p>
      </span>
      <div style={{ display: "flex", flexDirection: "column", gap: "2rem" }}>
        <div style={{ display: "flex", gap: "2rem" }}>
          <p>Account Number: {transactionDetails?.deposit.accountNumber}</p>
          <p>Amount: {transactionDetails?.deposit.amount}</p>
          <p>Date: {transactionDetails?.transactionDetails.transactionDate}</p>
        </div>
        <Section
          heading="Personal Information"
          data={Object.entries(conductor).filter(
            (f) => f[0] !== "addresses" && f[0] !== "identifications"
          )}
        />
        <Section
          heading="Address"
          data={Object.entries(conductor.addresses[0])}
        />
        <Section
          heading="Identification"
          data={Object.entries(conductor.identifications[0])}
        />
        <h1>
          IMPORTANT: Upon entering this information into the AML Micro Report,
          immediately place this into the Iron Mountain Bin.
        </h1>
      </div>
    </div>
  );
});

function ErrorToast({ message }: any) {
  const componentRef = useRef(null);
  const pageStyle = `
  @page {
    margin: 2rem;
  }
`;

  return (
    <>
      <h1>{message}</h1>

      <ReactToPrint
        trigger={() => (
          <button className="mt-2">
            Click here to print the conductor information.
          </button>
        )}
        content={() => componentRef.current}
        pageStyle={pageStyle}
      />
      <div className="hidden">
        <PrintMicroReport ref={componentRef} />
      </div>
    </>
  );
}

export default ErrorToast;
