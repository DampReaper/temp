import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useReduxSelector } from "reduxStore/hooks";
import { selectPrev } from "reduxStore/slices/helperSlice";
import styles from "./toast.module.scss";

export const successToastStyles = {
  icon: <FontAwesomeIcon icon="check-circle" />,
  bodyClassName: styles.successToast,
  progressClassName: styles.successProgress,
};

function SuccessToast({ message }: any) {
  const prev = useReduxSelector(selectPrev);
  const navigate = useNavigate();

  useEffect(() => {
    setTimeout(() => {
      navigate(prev, { replace: true });
    }, 3000);
  }, []);

  return (
    <>
      <p>{message}</p>
      <p>Redirecting to Pending Micro Reports page.</p>
    </>
  );
}

export default SuccessToast;
