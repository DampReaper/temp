import React from "react";

function PendingToast({ message }: any) {
  return <h1>{message}</h1>;
}

export default PendingToast;
