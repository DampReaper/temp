import React from "react";
import { render, screen } from "@testing-library/react";
import Section from ".";
import ButtonsGrid from ".";
import Button from "../Button";

describe("test the Buttons Grid component", () => {
  test("should render the children correctly", () => {
    render(
      <ButtonsGrid>
        <Button
          id="primaryButton"
          text="Primary"
          type="primary"
          handleClick={() => {}}
        />
        <Button
          id="secondaryButton"
          text="Secondary"
          type="secondary"
          handleClick={() => {}}
        />
      </ButtonsGrid>
    );

    const primaryButton = screen.getByText("Primary");
    const secondaryButton = screen.getByText("Secondary");

    expect(primaryButton).toBeInTheDocument();
    expect(secondaryButton).toBeInTheDocument();
  });
});
