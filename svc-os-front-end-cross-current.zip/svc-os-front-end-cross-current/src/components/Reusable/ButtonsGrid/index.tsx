import React from "react";
import styles from "./buttonsgrid.module.scss";

type ButtonsGridProps = {
  children: React.ReactNode;
  additionalStyles?: string;
};

function ButtonsGrid({ children, additionalStyles }: ButtonsGridProps) {
  return (
    <div className={`${styles.buttonsGridContainer} ${additionalStyles}`}>
      {children}
    </div>
  );
}

export default ButtonsGrid;
