import React from "react";

type NavIconProps = {
  name: string;
  icon?: string;
  tooltip?: string;
  text?: string;
  link?: string;
};

const NavIcon = ({ name, icon, tooltip, text, link }: NavIconProps) => {
  return (
    <>
      {tooltip && <></>}
      {link ? (
        <a
          href={link}
          target="_blank"
          rel="noopener noreferrer"
          className={`nav__util--icon flex items-center justify-center`}
        >
          {text ? (
            <span className="text-sm">{text}</span>
          ) : (
            <i className={`${icon}`}></i>
          )}
        </a>
      ) : (
        <button className={`nav__util--icon ${icon}`} data-tip data-for={name}>
          <span className="text-sm">{text}</span>
        </button>
      )}
    </>
  );
};

export default NavIcon;
