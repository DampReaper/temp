import React, { useEffect, useRef } from "react";
import styles from "./tooltip.module.scss";

type TooltipProps = {
  id: string;
  position: string;
  width: string;
  children: React.ReactNode;
};

function Tooltip({
  id,
  position,
  width = "fit-content",
  children,
}: TooltipProps) {
  let parent: HTMLElement | undefined | null;
  const tooltipRef = useRef<null | HTMLDivElement>(null);

  const eventsEnter = ["mouseenter", "focusin"];
  const eventsExit = ["mouseleave", "focusout", "click"];

  useEffect(() => {
    parent = document.getElementById(id + "tooltip")?.parentElement;
    window.addEventListener("keydown", (e) => {
      if (tooltipRef.current) {
        if (e.key === "Escape") tooltipRef.current.style.visibility = "hidden";
      }
    });
  }, []);

  const showTooltip = () => {
    if (tooltipRef.current) {
      tooltipRef.current.setAttribute(
        "style",
        "visibility: visible; display: flex !important"
      );
      tooltipRef.current.style.opacity = "1";
    }
  };

  const hideTooltip = () => {
    if (tooltipRef.current) {
      tooltipRef.current.style.opacity = "0";
      tooltipRef.current.style.visibility = "hidden";
    }
  };

  useEffect(() => {
    eventsEnter.forEach((event) =>
      parent?.addEventListener(event, showTooltip)
    );

    eventsExit.forEach((event) => parent?.addEventListener(event, hideTooltip));

    return () => {
      eventsEnter.forEach((event) =>
        parent?.removeEventListener(event, showTooltip)
      );

      eventsExit.forEach((event) =>
        parent?.removeEventListener(event, hideTooltip)
      );
    };
  }, [parent]);

  const getTooltipStyle = () => {
    switch (position) {
      case "top":
        return styles.tooltipTop;

      case "right":
        return styles.tooltipRight;

      case "bottom":
        return styles.tooltipBottom;

      case "left":
        return styles.tooltipLeft;

      default:
        break;
    }
  };

  return (
    <div
      hidden
      id={id + "tooltip"}
      className={getTooltipStyle()}
      ref={tooltipRef}
      role={"tooltip"}
      style={{ width: width }}
    >
      {children}
    </div>
  );
}

export default Tooltip;
