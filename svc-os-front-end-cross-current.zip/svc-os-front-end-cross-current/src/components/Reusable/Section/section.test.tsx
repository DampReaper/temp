import React from "react";
import { render, screen } from "@testing-library/react";
import Section from ".";

describe("test the section component", () => {
  test("should render the children correctly", () => {
    render(
      <Section name={"hello"}>
        <h1>Hello</h1>
      </Section>
    );
    const section = screen.getByTestId("hello-section");
    const heading = screen.getByText("Hello");

    expect(section).toBeInTheDocument();
    expect(heading).toBeInTheDocument();
  });

  test("should have the styles applied correctly", () => {
    render(
      <Section name={"regular"}>
        <h1>Hello</h1>
      </Section>
    );
    const section = screen.getByTestId("regular-section");
    expect(section).toHaveClass("regular");

    render(
      <Section type="borderedWithBg" name="styled">
        <h1>Hello</h1>
      </Section>
    );

    const section1 = screen.getByTestId("styled-section");
    expect(section1).toHaveClass("borderedWithBg");
  });
});
