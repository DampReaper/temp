import React, { ChangeEventHandler } from "react";

import Select from "react-select";
import styles from "./dropdown.module.scss";

export type MultiSelectInputProps = {
  /** ID for the element */
  id: string;

  /** Label to display on top of the element */
  label: string;

  /** Default values selected in the multi select dropdown */
  value: any[];

  /** Handler for changes in the value */
  onChange: (e: any) => void;

  /** Error message to display if any */
  error?: boolean | string;

  /** Handler to check for errors */
  errorHandler?: ChangeEventHandler;

  /** Dropdown menu to display */
  options: any[];

  /** Determines if the element is rendered in a popup component */
  isPopup?: boolean;

  /** Row start number for grid */
  rowStart?: string;

  /** Column start number for grid */
  columnStart?: string;

  /** Placeholder for the field */
  placeholder?: string;

  /** Error message to display when there's an error */
  errorMessage?: string;

  /** Indicates if the field is required or optional */
  required?: boolean;

  additionalStyles?:string;
};

export const MultiSelectInput = ({
  id,
  label,
  value,
  onChange,
  error,
  errorHandler,
  options,
  placeholder = "",
  errorMessage = "",
  rowStart,
  columnStart,
  required,
  additionalStyles,
}: MultiSelectInputProps) => {
  const theme = (theme: any) => ({
    ...theme,
    borderRadius: 6,
    border: "1px",
    boxShadow: "none",
    colors: {
      ...theme.colors,
      primary25: "rgb(249,250,251)",
      primary50: "#f5f9f9",
      primary: "rgb(4, 120, 87)",
    },
  });

  const customStyles = {
    option: (provided: any, state: any) => {
      return {
        ...provided,
        cursor: "pointer",
        background: state.isSelected ? "#hsl(158, 100%, 26%)" : "",
        ":hover": {
          background: state.isSelected ? "" : "rgba(0, 133, 84,0.1)",
          backgroundOpacity: "50%",
        },
      };
    },
    control: (styles: any) => {
      return {
        ...styles,
        outline: "none",
        border: error
          ? "1px solid hsl(0, 66%, 49%)"
          : "1px solid hsl(0, 0%, 73%)",
        boxShadow: "none",
        ":focus-within": {
          borderColor: error ? "hsl(0, 66%, 49%)" : "hsl(158, 100%, 26%)",
        },
        ":hover": {
          borderColor: error ? "hsl(0, 66%, 49%)" : "",
        },
      };
    },
    singleValue: (provided: any, state: any) => {
      const opacity = state.isDisabled ? 0.5 : 1;
      const transition = "opacity 300ms";
      return { ...provided, opacity, transition };
    },
  };

  return (
    <div
      className={`${styles.interactionInputWrapper} ${additionalStyles} `}
      style={{ gridColumnStart: columnStart, gridRowStart: rowStart }}
    >
      <label htmlFor={id} className={styles.interactionInputLabel}>
        {label}
        {required && <i className={styles.required}>*</i>}
      </label>
      <div className={styles.errorWrapper}>
        <Select
          classNamePrefix={error ? "react-select-error" : "react-select"}
          className={styles.interactionInputSelect}
          options={options}
          name={id}
          id={id}
          placeholder={placeholder ? placeholder : `Select ${label}`}
          theme={theme}
          onChange={onChange}
          onBlur={(e) => errorHandler && errorHandler(e)}
          maxMenuHeight={180}
          components={{
            IndicatorSeparator: () => <></>,
          }}
          styles={customStyles}
          isMulti
          value={value}
        ></Select>
        <label
          htmlFor={id}
          className={
            error ? styles.errorLabel : "pointer-events-none opacity-0"
          }
        >
          {errorMessage
            ? errorMessage
            : error
            ? `${label} is required`
            : "noerror"}
        </label>
      </div>
    </div>
  );
};
