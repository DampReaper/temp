import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import Button from ".";

describe("Test the Button component", () => {
  test("should render correctly", () => {
    render(
      <Button
        text="hello"
        id="hello"
        handleClick={() => {}}
        type="primary"
        icon="search"
      />
    );
    const button = screen.getByText(/hello/i);
    expect(button).toBeInTheDocument();
    expect(button).toHaveTextContent("hello");
  });

  test("should be hidden when hidden prop is true", () => {
    render(
      <Button
        text="hello"
        id="hello"
        handleClick={() => {}}
        type="primary"
        hidden
      />
    );
    const button = screen.getByText(/hello/i);
    expect(button).toBeInTheDocument();
    expect(button).toHaveAttribute("hidden");
  });

  test("should be disabled when disabled prop is true", () => {
    const mockHandler = jest.fn();
    render(
      <Button
        text="hello"
        id="hello"
        handleClick={() => {}}
        type="primary"
        disabled
      />
    );
    const button = screen.getByText(/hello/i);
    expect(button).toBeInTheDocument();
    fireEvent.click(button);
    expect(mockHandler.mock.calls.length).toBe(0);
    expect(button).toHaveAttribute("disabled");
  });

  test("should apply type prop styles correctly", () => {
    render(
      <Button text="hello" id="hello" handleClick={() => {}} type="primary" />
    );
    const button = screen.getByText(/hello/i);
    expect(button).toBeInTheDocument();
    expect(button).toHaveClass("buttonPrimary");

    render(
      <Button
        text="secondary"
        id="hello"
        handleClick={() => {}}
        type="secondary"
      />
    );
    const button2 = screen.getByText(/secondary/i);
    expect(button2).toBeInTheDocument();
    expect(button2).toHaveClass("buttonSecondary");
  });

  test("should fire onClick event", () => {
    const mockHandler = jest.fn();
    render(
      <Button
        text="hello"
        id="testButton"
        handleClick={mockHandler}
        type="primary"
      />
    );
    const button = screen.getByRole("button");
    fireEvent.click(button);
    expect(mockHandler.mock.calls.length).toEqual(1);
  });
});
