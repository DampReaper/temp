import React from 'react';
import styles from './loading.module.scss';

function Loading() {
  return (
    <div className={styles.loadingScreen}>
      <h1>Loading...</h1>
    </div>
  );
}

export default Loading;
