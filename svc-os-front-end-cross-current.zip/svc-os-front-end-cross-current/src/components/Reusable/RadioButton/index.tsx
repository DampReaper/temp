import React from "react";
import styles from "./radiobutton.module.scss";

export type RadioButtonProps = {
  id: string;
  name?: string;
  value: string | boolean | undefined;
  onChangeHandler: any;
  text: string;
  checked?: boolean;
};

function RadioButton({
  id,
  name,
  value,
  onChangeHandler,
  text,
}: RadioButtonProps) {
  return (
    <div className={styles.radioWrapper}>
      <label className={styles.radioButton} tabIndex={value ? 0 : -1} id={id}>
        <input
          className={styles.radioInput}
          type="radio"
          name={name}
          id={id}
          checked={value ? true : false}
          onChange={onChangeHandler}
        />

        <span className={value ? "font-medium text-ctz-green-100" : ""}>
          {text}
        </span>
      </label>
    </div>
  );
}

export default RadioButton;
