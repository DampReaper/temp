import PropTypes from 'prop-types';
import React from 'react';
import styles from './label.module.scss';

// export type LabelProps = {
//   /** Label to display on top of the element */
//   label: string;

//   /** Value to display in the element */
//   value: string | undefined;

//   /** Determines if the element is rendered in a popup component */
//   isPopup?: boolean;

//   /** Row start number for grid */
//   rowStart?: string;

//   /** Column start number for grid */
//   columnStart?: string;
 
// };

export const Label = ({ label, value, rowStart, columnStart, children }) => {
  return (
    <div className={`${styles.interactionLabelWrapper}`} style={{ gridColumnStart: columnStart, gridRowStart: rowStart }}>
      <label className={styles.interactionLabelLabel}>{label}</label>
      <div>
        {children}
        {!children && <label className={styles.interactionLabelText}>{value??''}</label>}
      </div>
    </div>
  );
};


Label.propTypes = {
  children: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.node), PropTypes.node.isRequired]),
   /** Label to display on top of the element */
   label: PropTypes.string,

   /** Value to display in the element */
   value:  PropTypes.any,
 
   /** Determines if the element is rendered in a popup component */
   isPopup: PropTypes.bool,
 
   /** Row start number for grid */
   rowStart: PropTypes.string,
 
   /** Column start number for grid */
   columnStart: PropTypes.string
  
};
