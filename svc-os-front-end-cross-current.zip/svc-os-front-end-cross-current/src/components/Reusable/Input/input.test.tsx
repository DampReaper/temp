import React, { ChangeEvent, useState } from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import Input from ".";

function InputValueTest() {
  const [value, setValue] = useState("");

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    setValue(e.target.value);
  };

  return (
    <Input id="input" label="Input" onChange={handleChange} value={value} />
  );
}

const setup = () => {
  const utils = render(<InputValueTest />);
  const input = utils.getByLabelText("Input");
  return {
    input,
    ...utils,
  };
};

describe("Test the Input Component", () => {
  test("should render the input element", () => {
    render(
      <Input
        id="input"
        label="Input"
        onChange={() => {
          console.log("input changed");
        }}
        value=""
      />
    );

    const input = screen.getByLabelText("Input");
    expect(input).toBeInTheDocument();
  });

  test("should have the placeholder", () => {
    render(
      <Input
        id="input"
        label="Input"
        onChange={() => {
          console.log("input changed");
        }}
        value=""
      />
    );

    const input = screen.getByPlaceholderText("Enter Input");
    expect(input).toBeInTheDocument();
    expect(input).toHaveAttribute("placeholder", "Enter Input");
  });

  test("should fire the onChange handler", () => {
    const { input } = setup();
    fireEvent.change(input, { target: { value: "hello" } });
    expect(input).toHaveValue("hello");
  });

  test("should fire the onBlur handler", () => {
    const mockHandler = jest.fn();
    render(
      <Input
        id="input"
        label="Input"
        onChange={mockHandler}
        value=""
        errorHandler={mockHandler}
      />
    );

    const input = screen.getByLabelText("Input");
    fireEvent.blur(input);
    expect(mockHandler.mock.calls.length).toEqual(1);
  });

  test("should show error message and change style when input is invalid", () => {
    render(
      <Input
        id="input"
        label="Input"
        onChange={() => {
          console.log("input changed");
        }}
        value=""
        error="Error"
      />
    );

    const input = screen.getByLabelText("Input");
    expect(input).toHaveErrorMessage("Error");

    render(
      <Input
        id="input"
        label="Input1"
        onChange={() => {
          console.log("input changed");
        }}
        value=""
        error="Error"
      />
    );

    const input1 = screen.getByLabelText("Input1");
    expect(input1).toHaveAttribute("aria-invalid", "true");
  });

  test("should show * if field is required", () => {
    const mockHandler = jest.fn();
    render(
      <Input
        id="input"
        label="Input"
        onChange={mockHandler}
        value=""
        required
      />
    );
    const asterik = screen.getByText("*");
    expect(asterik).toBeInTheDocument();
  });
});
