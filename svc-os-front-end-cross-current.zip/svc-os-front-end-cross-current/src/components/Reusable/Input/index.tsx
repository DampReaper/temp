import React, { ChangeEventHandler } from "react";

import styles from "./input.module.scss";

export type InputProps = {
  /** ID for the element */
  id: string;

  /** Label to display on top of the element */
  label: string;

  /** Handler for changes in the value */
  onChange: ChangeEventHandler;

  /** Error message to display if any */
  error?: string;

  /** Handler to check for errors */
  errorHandler?: ChangeEventHandler;

  /** Value to display in the element */
  value: string;

  /** Indicates if the field is required or optional */
  required?: boolean;

  /** Indicated the type of field (text, password, etc) */
  type?: string;

  /** Additional tailwind classes to style the input */
  additionalStyles?: string;
};

const Input = ({
  id,
  label,
  onChange,
  error,
  errorHandler,
  value,
  required,
  type = "text",
  additionalStyles,
}: InputProps) => {
  return (
    <div className={`${styles.interactionInputWrapper} ${additionalStyles}`}>
      <label htmlFor={id} className={styles.interactionInputLabel}>
        {label}
        {required && <i className={styles.required}>*</i>}
      </label>
      <div className={styles.errorWrapper}>
        <input
          className={`${
            error
              ? styles.interactionInputTextError
              : styles.interactionInputText
          }`}
          type={type}
          name={id}
          id={id}
          value={value}
          onChange={onChange}
          onBlur={(e) => errorHandler && errorHandler(e)}
          placeholder={`Enter ${label}`}
          autoComplete="off"
          aria-invalid={error && error?.length > 0 ? true : false}
          aria-errormessage={`${id}-error`}
        />
        <label
          htmlFor={id}
          id={`${id}-error`}
          className={
            error ? styles.errorLabel : "pointer-events-none opacity-0"
          }
        >
          {error ? error : "noerror"}
        </label>
      </div>
    </div>
  );
};

export default Input;
