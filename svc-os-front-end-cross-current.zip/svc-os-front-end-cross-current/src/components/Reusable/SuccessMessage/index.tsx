import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import styles from "./successmessage.module.scss";

type SuccessMessageProps = {
  message: string;
};

/**
 *
 * @returns A component with a failure message and an action button(only if type="add")
 */
function SuccessMessage({ message }: SuccessMessageProps): JSX.Element {
  return (
    <h1 className={styles.successMessage}>
      <FontAwesomeIcon icon="check-circle" />
      {message}
    </h1>
  );
}

export default SuccessMessage;
