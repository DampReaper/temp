import React from 'react';
import styles from './label.module.scss';

export type LabelProps = {
  /** Label to display on top of the element */
  label: string;

  /** Value to display in the element */
  value: string | undefined;

  /** Determines if the element is rendered in a popup component */
  isPopup?: boolean;

  /** Row start number for grid */
  rowStart?: string;

  /** Column start number for grid */
  columnStart?: string;
};

export const Label = ({ label, value, rowStart, columnStart }: LabelProps) => {
  return (
    <div className={`${styles.interactionLabelWrapper}`} style={{ gridColumnStart: columnStart, gridRowStart: rowStart }}>
      <label className={styles.interactionLabelLabel}>{label}</label>
      <div>
        <label className={styles.interactionLabelText}>{value??''}</label>
      </div>
    </div>
  );
};
