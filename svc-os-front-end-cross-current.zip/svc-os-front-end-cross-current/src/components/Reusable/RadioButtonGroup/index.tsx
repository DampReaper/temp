import React from "react";
import styles from "./radiobuttongroup.module.scss";

type RadioButtonGroupProps = {
  children: React.ReactNode;
};

function RadioButtonGroup({ children }: RadioButtonGroupProps) {
  return (
    <fieldset role={"radiogroup"} className={styles.radioGroup}>
      {children}
    </fieldset>
  );
}

export default RadioButtonGroup;
