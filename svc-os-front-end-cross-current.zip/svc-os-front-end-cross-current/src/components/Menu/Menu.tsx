import { Link } from 'react-router-dom';
import React from 'react';
import Tile from '../Tile/Tile';

const tiles = [
  { color: '#e74c3c', label: 'Add', to: '/AddApplication' },
  { color: '#2ecc71', label: 'View', to: '/SearchApplication' },
  { color: '#3498db', label: 'Failed', to: '/tile3' },
  { color: '#f1c40f', label: 'Incomplete', to: '/tile4' },
];

const Menu = () => {
  const menuStyle = {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'center',
  };

  return (
    <div style={menuStyle}>
      {tiles.map((tile, index) => (
        <Link key={index} to={tile.to}>
          <Tile color={tile.color} label={tile.label} to={tile.to} />
        </Link>
      ))}
    </div>
  );
};

export default Menu;