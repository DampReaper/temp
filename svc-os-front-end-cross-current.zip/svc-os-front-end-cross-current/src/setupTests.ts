import "@testing-library/jest-dom";
import registerFontAweseomeIcons from "./utils/fontAwesomeHelper";
registerFontAweseomeIcons();
