
/**
 * Service Base class.
 *
 * Service Layer BaseClass.
 */
export default abstract class ServiceBase {
  protected handleServiceError(e: any) {
    console.error(e);
  }
}
