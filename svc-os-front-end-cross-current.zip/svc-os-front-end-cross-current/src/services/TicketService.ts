import { Agent, PageTicket, Ticket, TicketsApiFactory } from './apiClient';
import { AgentSearchResultDto, EmployeeSearchResultDto } from 'utils';

import { AxiosPromise } from 'axios';
import { ITicketSearchSearch } from 'reduxStore/slices/ticketSearchSlice';
import { LOG_STYLE } from 'utils';
import ServiceBase from './ServiceBase';

/**
 * Ticket Service
 *
 * Service Layer for ticketsApi.
 */

export class TicketService extends ServiceBase {
  // Share Instance
  private static instance: TicketService;
  protected ticketsApi = TicketsApiFactory();

  public static get shared(): TicketService {
    return this.instance || (this.instance = new this());
  }

  /**
   * Get Ticket.
   * @param ticketId
   * @returns Ticket.
   */
  public async getTicket(organization: string, ticketId: string): Promise<Ticket> {
    try {
      console.log(...LOG_STYLE.SERVICE, `TicketService.getTicket(${organization},${ticketId})`);

      const response = await this.ticketsApi.byTicketId(organization, ticketId);

      const { data } = response;

      return data;
    } catch (ex) {
      this.handleServiceError(ex);
      throw ex;
    }
  }
  /**
   * Saves a Ticket.
   * @param tickets
   * @returns a Ticket.
   */
  public save = (tickets: Ticket): AxiosPromise<Ticket> | null => {
    try {
      console.log(...LOG_STYLE.SERVICE, `TicketService.save()`, tickets);
      return this.ticketsApi.save(tickets);
    } catch (ex) {
      this.handleServiceError(ex);
      throw ex;
    }
  };

  /**
   * findAllByContactId
   *
   * Gets sorted page of tickets belonging to a contact.
   *
   * @param organization
   * @param contactId
   * @param pageIndex
   * @param sizePerPage
   * @param sortField
   * @param sortOrder
   * @returns A sorted page of tickets belonging to a contact.
   */
  public findAllById(organization: string, contactId: string, pageIndex: number, sizePerPage: number, sortField: string, sortOrder: string): AxiosPromise<PageTicket> {
    try {
      console.log(...LOG_STYLE.SERVICE, `TicketService.findAllById(${contactId},${pageIndex},${sizePerPage},${sortField},${sortOrder})`);
      return this.ticketsApi.findAllByContactId(organization, contactId, pageIndex, sizePerPage, sortField, sortOrder);
    } catch (ex) {
      this.handleServiceError(ex);
      throw ex;
    }
  }

  /**
   * searchForTickets
   *
   * Searches for paged/sorted/filtered tickets by various criteria.
   *
   * @param organization
   * @param searchCriteria
   * @returns A sorted/filtered page of tickets.
   */
  public searchForTickets(organization: string, searchCriteria: ITicketSearchSearch): AxiosPromise<PageTicket> {
    // status?: string, ownerAgentEmployeeNum?: string, branchId?: string, workflowStatus?: string, workflowExternalId?: string, startDate?: string, endDate?: string, pageIndex?: number, sizePerPage?: number, sortField?: string, sortOrder?: string): AxiosPromise<PageTicketDto> {
    try {
      console.log(...LOG_STYLE.SERVICE, `TicketService.findAllByStatus(${organization},{})`, searchCriteria);
      return this.ticketsApi.findAllByStatus(
        organization,
        searchCriteria.searchByStatus,
        searchCriteria.searchByOwnerAgentEmployeeNum,
        searchCriteria.searchByContactId,
        searchCriteria.searchByBranch,
        searchCriteria.searchByWorkflowStatus,
        searchCriteria.searchByWorkflowExternalId,
        searchCriteria.searchByStartDate,
        searchCriteria.searchByEndDate,
        searchCriteria.pageIndex,
        searchCriteria.pageSize,
        searchCriteria.sortField,
        searchCriteria.sortOrder
      );
    } catch (ex) {
      this.handleServiceError(ex);
      throw ex;
    }
  }

  /**
   * searchAgent
   *
   * Searches for agents based on criteria.
   *
   * @param searchCriteria
   * @param pageIndex
   * @param pageSize
   * @returns a page of Agents.
   */
  public async searchAgent(searchCriteria: string, pageIndex?: number, pageSize?: number): Promise<AgentSearchResultDto> {
    try {
      const searchCriteriaArray = searchCriteria.split(' ');
      console.log(...LOG_STYLE.SERVICE, `TicketService.searchAgent(${pageIndex},${pageSize})`);

      const response = await this.ticketsApi.searchAgent(searchCriteriaArray, pageIndex, pageSize);

      const data = response.data;
      const totalCount = data.totalElements as number;
      const options = data.content as Agent[];

      return { options, totalCount };
    } catch (ex) {
      this.handleServiceError(ex);
      throw ex;
    }
  }

  // public launchWorkflow = (ticketId: number): AxiosPromise<WorkflowLaunchDto> | null => {
  //   try {
  //     if (this.debugInd) {
  //       console.log(`TicketService.launchWorkflow(${ticketId})`);
  //     }
  //     return this.ticketsApi.launchWorkflow(ticketId);
  //   } catch (ex) {
  //     this.handleServiceError(ex);
  //     throw ex;
  //   }
  // };

  //
  //
  //
}
