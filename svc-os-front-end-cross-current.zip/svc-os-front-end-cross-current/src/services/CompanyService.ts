import { CompaniesApiFactory, Company } from './apiClient';

import { AxiosPromise } from 'axios';
import { LOG_STYLE } from 'utils';
import ServiceBase from './ServiceBase';

/**
 * Company Service
 *
 * Service Layer for companiesApi.
 */
export class CompanyService extends ServiceBase {
  // Share Instance
  private static instance: CompanyService;
  protected companiesApi = CompaniesApiFactory();

  public static get shared(): CompanyService {
    return this.instance || (this.instance = new this());
  }

  /**
   * Get Company.
   * @param companyId
   * @returns Company.
   */
  public getCompany(companyId: string): AxiosPromise<Company> {
    try {
      console.log(...LOG_STYLE.SERVICE, `CompanyService.getCompany(${companyId})`);

      return this.companiesApi.findById(companyId);
    } catch (ex) {
      this.handleServiceError(ex);
      throw ex;
    }
  }

  //
  //
  //
}
