import { Employee, EmployeeApiFactory } from './apiClient';

import { AxiosPromise } from 'axios';
import { EmployeeSearchResult } from 'utils';
import { LOG_STYLE } from 'utils';
import ServiceBase from './ServiceBase';
import { trackPromise } from 'react-promise-tracker';

/**
 * Employee Service
 *
 * Service Layer for employeeApi.
 */
export class EmployeeService extends ServiceBase {
  // Share Instance
  private static instance: EmployeeService;
  protected employeeApi = EmployeeApiFactory();

  public static get shared(): EmployeeService {
    return this.instance || (this.instance = new this());
  }

  /**
   * Get Employee.
   * @param employeeId
   * @returns Employee.
   */
  public getEmployee(employeeId: string): AxiosPromise<Employee> {
    try {
      console.log(...LOG_STYLE.SERVICE, `EmployeeService.getEmployee(${employeeId})`);
      return trackPromise(this.employeeApi.getEmployee(employeeId), 'searchCustomer');
    } catch (ex) {
      this.handleServiceError(ex);
      throw ex;
    }
  }

  // public search(searchCriteria: string, searchCriteria2?: string, pageIndex?: number, pageSize?: number): AxiosPromise<Employee> {
  public async search(query: string, pageIndex = 0, pageSize = 50): Promise<EmployeeSearchResult> {
    try {
      console.log(...LOG_STYLE.SERVICE, `EmployeeService.search(${query})`);

      // Remove comma, doubleSpace and Split Criteria so we have two.
      // TODO: Fix this so it splits and searches more cases.
      const ra = query.replace(',', ' ').replace('  ', ' ').split(' ');
      const searchCriteria = ra[0];
      const searchCriteria2 = ra[1] || undefined;

      const response = await trackPromise(this.employeeApi.search(searchCriteria, searchCriteria2, pageIndex, pageSize), 'searchCustomer');

      const data = response.data;
      const totalCount = data.totalElements as number;
      const content = data.content;
      let options = [];
      if (content) {
        options = content.map((i) => ({
          id: i.employeeNum,
          name: i.lastName + ', ' + i.firstName + ', (' + i.employeeNum + ')'
        })) as any;
      }

      return { options, totalCount };
    } catch (ex) {
      this.handleServiceError(ex);
      throw ex;
    }
  }

  // /**
  //  * Find all Employees by organizationId​.
  //  * @param organizationId​
  //  * @returns Employees.
  //  */
  // public findAllByOrganization(organizationId: number): AxiosPromise<Employee[]> {
  //   try {
  //     if (this.debugInd) {
  //       console.log(`EmployeeService.findAllByOrganization(${organizationId})`);
  //     }
  //     return this.employeeApi.findAllByOrganization(organizationId);
  //   } catch (ex) {
  //     this.handleServiceError(ex);
  //     throw ex;
  //   }
  // }

  // /**
  //  * Get Paged Employee by organization
  //  * @param organizationId
  //  * @param pageIndex
  //  * @param pageSize
  //  * @returns employee list.
  //  */
  // public findAllByOrganizationPaged(organizationId: number, pageIndex?: number, pageSize?: number): AxiosPromise<Page> {
  //   try {
  //     if (this.debugInd) {
  //       console.log(`EmployeeService.findAllByOrganizationPaged(${organizationId},${pageIndex},${pageSize})`);
  //     }
  //     return this.employeeApi.findAllByOrganizationPaged(organizationId, pageIndex, pageSize);
  //   } catch (ex) {
  //     this.handleServiceError(ex);
  //     throw ex;
  //   }
  // }

  /**
   * Save list of Employees.
   * @param employee
   * @returns Employees.
   */
  // public save(employee: EmployeeIncoming[]): AxiosPromise<Array<Employee>> | null {
  //   try {
  //     if (this.debugInd) {
  //       console.log(`EmployeeService.save(${JSON.stringify(employee)})`);
  //     }
  //     return this.employeeApi.save(employee);
  //   } catch (ex) {
  //     this.handleServiceError(ex);
  //     throw ex;
  //   }
  // }

  // public updateAlias(id: number, alias: string): AxiosPromise<boolean> {
  //   try {
  //     const employeeAliasIncoming = { id: id, alias: alias } as EmployeeAliasIncoming;

  //     if (this.debugInd) {
  //       console.log(`EmployeeService.updateAlias()`, employeeAliasIncoming);
  //     }
  //     return this.employeeApi.updateAlias(employeeAliasIncoming);
  //   } catch (ex) {
  //     this.handleServiceError(ex);
  //     throw ex;
  //   }
  // }

  // public tiraByEmployeeNum(employeeNum: string): AxiosPromise<Tira> {
  //   try {
  //     if (this.debugInd) {
  //       console.log(`EmployeeService.tiraByEmployeeNum()`, employeeNum);
  //     }
  //     return this.employeeApi.getTiraByEmployeeNum(employeeNum);
  //   } catch (ex) {
  //     this.handleServiceError(ex);
  //     throw ex;
  //   }
  // }

  //
  //
  //
}
