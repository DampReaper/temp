import { Customer, CustomerApiFactory } from './apiClient';

import { AxiosPromise } from 'axios';
import { LOG_STYLE } from 'utils';
import ServiceBase from './ServiceBase';
import { trackPromise } from 'react-promise-tracker';

/**
 * Customer Service
 *
 * Service Layer for customerApi.
 */
export class CustomerService extends ServiceBase {
  // Share Instance
  private static instance: CustomerService;
  protected customerApi = CustomerApiFactory();

  public static get shared(): CustomerService {
    return this.instance || (this.instance = new this());
  }

  /**
   * Get Customer.
   * @param customerId
   * @returns Customer.
   */
  public getCustomer(customerId: string): AxiosPromise<Customer> {
    try {
      console.log(...LOG_STYLE.SERVICE, `CustomerService.getCustomer(${customerId})`);

      return this.customerApi.getCustomer(customerId);
    } catch (ex) {
      this.handleServiceError(ex);
      throw ex;
    }
  }

  public searchCustomerByAccount(searchBy: any, searchInput: string): AxiosPromise<Customer[]> {
    // return trackPromise(
    //   this.customerApi.searchCustomerByAccount(searchBy,searchInput),
    //   "searchCustomer"
    // );

    throw new Error('Method not implemented.');
  }

  public searchCustomerByTaxId(searchInput: string): AxiosPromise<Customer> {
    throw new Error('Method not implemented.');
  }
  
  public searchCustomerByName(searchInput: string, searchInput2: string): AxiosPromise<Array<Customer>> {
    try {
      console.log(...LOG_STYLE.SERVICE, `CustomerService.searchCustomerByName(${searchInput},${searchInput2})`);

      return this.customerApi.searchCustomerByName(searchInput, searchInput2);
    } catch (ex) {
      this.handleServiceError(ex);
      throw ex;
    }
  }

  //
  //
  //
}
