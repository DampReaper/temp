import { TicketType, TicketTypeDto, TicketTypesApiFactory } from './apiClient';

import { AxiosPromise } from 'axios';
import { LOG_STYLE } from 'utils';
import ServiceBase from './ServiceBase';

/**
 * Ticket Service
 *
 * Service Layer for ticketTypeApi.
 */

export class TicketTypeService extends ServiceBase {
  // Share Instance
  private static instance: TicketTypeService;
  protected ticketTypesApi = TicketTypesApiFactory();

  public static get shared(): TicketTypeService {
    return this.instance || (this.instance = new this());
  }

  /**
   * Get Ticket.
   * @param ticketId
   * @returns Ticket.
   */
  public async ticketTypeTree(organization: string, role: Array<string>, lastModifiedDate:string): Promise<TicketTypeDto> {
    try {
      console.log(...LOG_STYLE.SERVICE, `TicketTypeService.getFullTree()${organization}`, role);
      const response = await this.ticketTypesApi.ticketTypeTree(organization, role, lastModifiedDate);
      const { data } = response;

      return data;
    } catch (ex) {
      this.handleServiceError(ex);
      throw ex;
    }
  }

  /**
   * Save list of Tickets.
   * @param tickets
   * @returns Tickets.
   */
  public save = (ticketType: TicketType): AxiosPromise<TicketType> | null => {
    try {
      console.log(...LOG_STYLE.SERVICE,`TicketTypeService.save()`,ticketType);
      
      return this.ticketTypesApi.save(ticketType);
    } catch (ex) {
      this.handleServiceError(ex);
      throw ex;
    }
  };

  //
  //
  //
}
