import { Branch, BranchApiFactory, PageBranch } from './apiClient';

import { AxiosPromise } from 'axios';
import { BranchSearchResult } from 'utils';
import { LOG_STYLE } from 'utils';
import ServiceBase from './ServiceBase';

/**
 * Branch Service
 *
 * Service Layer for branchApi.
 */
export class BranchService extends ServiceBase {
  // Share Instance
  private static instance: BranchService;
  protected branchApi = BranchApiFactory();

  public static get shared(): BranchService {
    return this.instance || (this.instance = new this());
  }

  /**
   * Get Branch.
   * @param branchId
   * @returns Branch.
   */
  public getBranch(branchId: string): AxiosPromise<Branch> {
    try {
      console.log(...LOG_STYLE.SERVICE, `BranchService.getBranch(${branchId})`);

      return this.branchApi.getById(branchId);
    } catch (ex) {
      this.handleServiceError(ex);
      throw ex;
    }
  }

  /**
   * Find all Branches by organizationId​.
   * @param organizationId​
   * @returns Branches.
   */
  // public findAll(): AxiosPromise<Branch[]> {
  //   try {
  //       console.log(`BranchService.findAll()`);
  //     return this.branchApi.findAll();
  //   } catch (ex) {
  //     this.handleServiceError(ex);
  //     throw ex;
  //   }
  // }

  /**
   * Get Paged Branch by organization
   * @param organizationId
   * @param pageIndex
   * @param pageSize
   * @returns branch list.
   */
  public findAllPaged(branchIncoming: Branch, pageIndex?: number, pageSize?: number): AxiosPromise<PageBranch> {
    try {
      console.log(...LOG_STYLE.SERVICE, `BranchService.findAllPaged(${pageIndex},${pageSize})`);

      return this.branchApi.findByPaged(
        pageIndex,
        pageSize,
        branchIncoming.bankCd,
        branchIncoming.branchNm,
        branchIncoming.address1Txt,
        branchIncoming.cityNm,
        branchIncoming.stateCd,
        branchIncoming.zipCd,
        branchIncoming.activeInd
      );
    } catch (ex) {
      this.handleServiceError(ex);
      throw ex;
    }
  }

  public async search(searchCriteria: string, pageIndex?: number, pageSize?: number): Promise<BranchSearchResult> {
    try {
      const searchCriteriaArray = searchCriteria.split(' ');
      console.log(...LOG_STYLE.SERVICE, `BranchService.search(${pageIndex},${pageSize})`);

      const response = await this.branchApi.search(searchCriteriaArray, pageIndex, pageSize);

      const data = response.data;
      const totalCount = data.totalElements as number;
      const options = data.content as Branch[];

      return { options, totalCount };
    } catch (ex) {
      this.handleServiceError(ex);
      throw ex;
    }
  }

  //
  //
  //
}
