const presets = [
  "@babel/preset-typescript",
  "@babel/preset-react",
  "@babel/preset-env",
];

const plugins = [["@babel/transform-runtime"], ["macros"]];

module.exports = { presets, plugins };
