const path = require("path");
const HtmlWebPackPlugin = require("html-webpack-plugin");
const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const CssMinimizerPlugin = require("css-minimizer-webpack-plugin");
const TerserPlugin = require("terser-webpack-plugin");
const ESLintPlugin = require("eslint-webpack-plugin");
const webpack = require("webpack");

const deps = require("./package.json").dependencies;

module.exports = (env) => {
  const ENV_NAME = env.ENV_NAME && JSON.parse(env.ENV_NAME);
  const APP_INDEX_PATH = "/trackit";
  const APP_PORT = 3333;

  let publicPath = `http://localhost:${APP_PORT + APP_INDEX_PATH}`;

  let globalStoreRemote =
    "globalStore@http://localhost:3001/store/remoteEntry.js";

  if (ENV_NAME) {
    publicPath = ENV_NAME.baseurl + APP_INDEX_PATH; // suffix should match the index in devServer below

    if (!ENV_NAME.baseurl?.includes("local")) {
      globalStoreRemote = `globalStore@${ENV_NAME.baseurl}/store/remoteEntry.js`;
    }
  }

  return {
    entry: path.resolve(__dirname, "src/index.ts"),

    module: {
      rules: [
        {
          test: /\.(ts|js)x?$/,
          exclude: /node_modules/,
          use: {
            loader: "babel-loader",
            options: {
              presets: [
                "@babel/preset-env",
                "@babel/preset-react",
                "@babel/preset-typescript",
              ],
            },
          },
        },
        {
          test: /\.module\.s?css$/,
          use: [
            MiniCssExtractPlugin.loader,
            {
              loader: "css-loader",
              options: {
                modules: {
                  localIdentName: "[local]--[hash:base64]",
                },
                sourceMap: true,
              },
            },
            "postcss-loader",
            "sass-loader",
          ],
        },
        {
          test: /\.(css|s[ac]ss)$/i,
          exclude: /\.module\.s?css$/,
          use: [
            MiniCssExtractPlugin.loader,
            "css-loader",
            "postcss-loader",
            "sass-loader",
          ],
        },
        {
          test: /\.(png|svg|gif|ico|jpg|jpeg)$/,
          type: "asset/resource",
        },
      ],
    },

    resolve: {
      alias: {
        assets: path.resolve(__dirname, "src/assets/"),
        components: path.resolve(__dirname, "src/components/"),
        constants: path.resolve(__dirname, "src/constants/"),
        design: path.resolve(__dirname, "src/design/"),
        definitions: path.resolve(__dirname, "src/definitions/"),
        pages: path.resolve(__dirname, "src/pages/"),
        reduxStore: path.resolve(__dirname, "src/redux/"),
        services: path.resolve(__dirname, "src/services/"),
        styles: path.resolve(__dirname, "src/styles/"),
        utils: path.resolve(__dirname, "src/utils/"),
      },
      extensions: [
        ".tsx",
        ".ts",
        ".jsx",
        ".js",
        ".json",
        ".css",
        ".png",
        ".svg",
      ],
    },

    output: {
      path: path.join(__dirname, "/dist"),
      chunkFilename: "[name].js",
      publicPath:  publicPath, // will come from env variable
    },

    plugins: [
      new ModuleFederationPlugin({
        name: "trackit",
        filename: "remoteEntry.js",
        remotes: {
          globalStore: globalStoreRemote,
        }, // components that will be used by this microfe if any
        exposes: {
          "./DashBoard": "./src/pages/DashBoard"
        }, // what components will be exposed from this microfe
        shared: {
          ...deps,
          react: {
            singleton: true,
            requiredVersion: deps.react,
          },
          "react-dom": {
            singleton: true,
            requiredVersion: deps["react-dom"],
          },
          "react-router-dom": {
            singleton: true,
            requiredVersion: deps["react-router-dom"],
          },
        },
      }),

      new HtmlWebPackPlugin({
        template: "./public/index.html",
        favicon: "./public/favicon.ico",
      }),

      new MiniCssExtractPlugin(),

      // new ESLintPlugin({
      //   extensions: ["ts", "tsx"],
      // }),

      new webpack.DefinePlugin({
        ENV_NAME: env.ENV_NAME, // ENV_NAME will be a JSON in OpenShift secrets with all required variables
      }),
    ],

    optimization: {
      minimizer: [
        new TerserPlugin({
          parallel: true,
          terserOptions: {
            format: {
              comments: true,
            },
          },
          extractComments: false,
        }),
        new CssMinimizerPlugin({
          minimizerOptions: {
            preset: [
              "default",
              {
                discardComments: { removeAll: true },
              },
            ],
          },
        }),
      ],
      minimize: true,
      chunkIds: "named",
    },

 

    devServer: {
      historyApiFallback: {
        index: APP_INDEX_PATH, // this will be the index path of the microfe
      },
      // headers: {
      //   'Access-Control-Allow-Origin': '*',
      //   'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
      //   'Access-Control-Allow-Headers': 'X-Requested-With, content-type, Authorization'
      // },
      port: APP_PORT,
      allowedHosts: "all",
    },
  };
};
